<?php
/**
 * Included by loop.php
 * It is used only on page with posts list: blog, archive, search
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
} // Exit if accessed directly

global $apollo13framework_a13, $post;

?>

<div class="formatter">
    <div class="real-content">

        <?php
        $post_meta = apollo13framework_post_meta_under_content() . apollo13framework_post_meta_above_content();
        if(strlen($post_meta)){
            echo '<div class="metas">'.$post_meta.'</div>';
        }

        $title = the_title('<h2 class="post-title entry-title"><a href="'. esc_url(get_permalink()) . '">', '</a></h2>', false);
        if(strlen($title)){
            echo $title;
        }

        if($apollo13framework_a13->get_option( 'blog_excerpt_type') == 'auto'){
            if(strpos($post->post_content, '<!--more-->')){
                the_content( esc_html__( 'Read more', 'apollo13-framework' ));
            }
            else{
                the_excerpt();
            }
        }
        //manual post cutting
        else{
            the_content( esc_html__( 'Read more', 'apollo13-framework' ));
        }

        ?>

        <div class="clear"></div>

        <?php apollo13framework_under_post_content(); ?>
        
    </div>
</div>