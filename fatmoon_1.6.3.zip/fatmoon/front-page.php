<?php
/**
 * The Template for displaying front-page
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

if ( get_option( 'show_on_front' ) === 'posts' ) {
	get_template_part( 'index' );
} else {
	global $apollo13framework_a13;
	$fp_variant = $apollo13framework_a13->get_option( 'fp_variant' );

	if ( $fp_variant == 'page' ) {
		//it makes use of real page templates instead of front-page.php
		$page_template = basename( get_page_template(), '.php' );
		//below check is incorrect in WordPress 4.8, but might be true in older WP versions
		//now $page_template will never return "page.php" or "front-page"
		//however it works proper so lets keep it for few versions
		if ( $page_template !== 'page.php' && $page_template !== 'front-page' ) {
			get_template_part( $page_template );
		} else {
			get_template_part( 'page' );
		}
	}
	elseif ( $fp_variant == 'blog' ) {
		global $wp_query, $more;

		//dirty trick
		/* on front page when you set page as FP $more is set to 1, so it breaks excerpts of posts */
		$more = null;

		//fix for front page pagination
		if ( get_query_var( 'paged' ) ) {
			$paged = get_query_var( 'paged' );
		} elseif ( get_query_var( 'page' ) ) {
			$paged = get_query_var( 'page' );
		} else {
			$paged = 1;
		}

		$args = array(
			'post_type=page' => 'post',
			'paged'          => $paged
		);

		$wp_query->query( $args );

		get_template_part( 'index' );

		//    wp_reset_postdata();
	}
	elseif ( $fp_variant == 'albums_list' ) {
		get_template_part( 'albums-template' );
	}
	elseif ( $fp_variant == 'works_list' ) {
		get_template_part( 'works-template' );
	}
	elseif ( $fp_variant == 'single_album' ) {
		global $wp_query;
		//get album to show
		$fp_album = $apollo13framework_a13->get_option( 'fp_album' );
		//in case of WPML make sure to get localized version
		if(defined( 'ICL_SITEPRESS_VERSION')){
			$fp_album = apply_filters( 'wpml_object_id', $fp_album, 'album', true );
		}

		//save original query
		$original_query = $wp_query;
		//reset
		$wp_query = null;
		//make query
		$wp_query = new WP_Query( array( 'p' => $fp_album, 'post_type' => A13FRAMEWORK_CUSTOM_POST_TYPE_ALBUM ) );

		//check if album exists(it could not exist in case of predefined set with album form other install)
		if ( $wp_query->have_posts() ) {
			//brutal change of what is desired for front page (fight WordPress SEO plugin)
			$GLOBALS['wp_the_query'] = $GLOBALS['wp_query'];

			//fix title cause we customized query
			add_filter( 'document_title_parts', 'apollo13framework_cpt_as_frontpage_title_fix' );
			//show
			get_template_part( 'single', A13FRAMEWORK_CUSTOM_POST_TYPE_ALBUM );

			//return old query
			$wp_query = null;
			$wp_query = $original_query;

			// Reset Post Data
			wp_reset_postdata();
		}
		else {
			//return old query
			$wp_query = null;
			$wp_query = $original_query;

			// Reset Post Data
			wp_reset_postdata();

			//show
			get_template_part( 'single', A13FRAMEWORK_CUSTOM_POST_TYPE_ALBUM );
		}

	}
	elseif ( $fp_variant == 'single_work' ) {
		global $wp_query;
		//get work to show
		$fp_work = $apollo13framework_a13->get_option( 'fp_work' );
		//in case of WPML make sure to get localized version
		if(defined( 'ICL_SITEPRESS_VERSION')){
			$fp_work = apply_filters( 'wpml_object_id', $fp_work, 'album', true );
		}

		//save original query
		$original_query = $wp_query;
		//reset
		$wp_query = null;
		//make query
		$wp_query = new WP_Query( array( 'p' => $fp_work, 'post_type' => A13FRAMEWORK_CUSTOM_POST_TYPE_WORK ) );

		//check if album exists(it could not exist in case of predefined set with album form other install)
		if ( $wp_query->have_posts() ) {
			//brutal change of what is desired for front page (fight WordPress SEO plugin)
			$GLOBALS['wp_the_query'] = $GLOBALS['wp_query'];

			//fix title cause we customized query
			add_filter( 'document_title_parts', 'apollo13framework_cpt_as_frontpage_title_fix' );
			//show
			get_template_part( 'single', A13FRAMEWORK_CUSTOM_POST_TYPE_WORK );

			//return old query
			$wp_query = null;
			$wp_query = $original_query;

			// Reset Post Data
			wp_reset_postdata();
		}
		else {
			//return old query
			$wp_query = null;
			$wp_query = $original_query;

			// Reset Post Data
			wp_reset_postdata();

			//show
			get_template_part( 'single', A13FRAMEWORK_CUSTOM_POST_TYPE_WORK );
		}

	}
}