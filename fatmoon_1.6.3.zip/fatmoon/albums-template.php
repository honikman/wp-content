<?php
/**
Template Name: Albums list
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
} // Exit if accessed directly

get_template_part( 'albums-list' );