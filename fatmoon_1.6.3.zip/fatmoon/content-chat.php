<?php
/* Credits to http://hirizh.name/blog/styling-chat-transcript-for-custom-post-format/ */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
} // Exit if accessed directly
?>

<div class="formatter">
    <?php
    $post_meta = apollo13framework_post_meta_under_content() . apollo13framework_post_meta_above_content();;
    if(strlen($post_meta)){
        echo '<div class="metas">'.$post_meta.'</div>';
    }
    ?>
    <h2 class="post-title"><a href="<?php echo esc_url(get_permalink()); ?>"><?php the_title(); ?></a></h2>
    <div class="real-content">
        <?php echo apollo13framework_daoon_chat_post($post->post_content);?>
        <div class="clear"></div>
    </div>
</div>