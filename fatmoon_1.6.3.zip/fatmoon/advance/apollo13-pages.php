<?php
function apollo13framework_apollo13_info() {
	apollo13framework_theme_pages_header();
	do_action('apollo13framework_apollo13_info_page_content');
	apollo13framework_theme_pages_footer();
}

function apollo13framework_apollo13_import() {
	apollo13framework_theme_pages_header();

	global $apollo13framework_a13;

	$has_valid_purchase_code = $apollo13framework_a13->check_for_valid_license();

	if(!$has_valid_purchase_code){
		do_action('apollo13framework_license_is_needed_msg');
		return;
	}

	apollo13framework_get_demo_importer_content();

	apollo13framework_theme_pages_footer();
}

function apollo13framework_apollo13_help() {
	apollo13framework_theme_pages_header();
	global $apollo13framework_a13;
	?>

	<h2><?php echo esc_html__( 'Where to get help?', 'apollo13-framework' ); ?></h2>

	<h3 class="center"><a href="https://support.apollo13.eu/"><?php echo esc_html__( 'Support Forum', 'apollo13-framework' ); ?></a></h3>
	<p><?php echo sprintf( __( 'If you have question about how something works, or you feel like you have found bug please come to our <a href="%1$s">support forum</a>! It is best place, where we can work together to solve issues and explain various topics.', 'apollo13-framework' ), esc_attr('https://support.apollo13.eu/') ); ?></p>
	<p><?php echo sprintf( __( 'To access forum you will need your license code. <a href="%1$s" target="_blank">Where to find your code?</a>', 'apollo13-framework' ), esc_attr($apollo13framework_a13->get_docs_link('license-code')) ); ?></p>
	<p><?php echo esc_html__( 'We understand that most of our customers are not developers(programmers), that is why we will also help you with issues caused by other components (plugins for example) and we will provide you instructions to help fixing issues, even if it is not directly related to our theme.', 'apollo13-framework' ); ?></p>

	<h3 class="center"><a href="<?php echo esc_attr($apollo13framework_a13->get_docs_link()); ?>"><?php echo esc_html__( 'Online Documentation', 'apollo13-framework' ); ?></a></h3>
	<p><?php echo sprintf( __( '<a href="%1$s">Online documentation</a> is always most up to date if it comes to explaining how to work with theme. It will come handy as first source when you trying to work out problematic topics.', 'apollo13-framework' ), esc_attr($apollo13framework_a13->get_docs_link()) ); ?></p>

	<h3 class="center"><a href="https://apollo13themes.com/rife/help/#tutorials"><?php echo esc_html__( 'Video Tutorials', 'apollo13-framework' ); ?></a></h3>
	<p><?php echo sprintf( __( 'We have prepared some basics tutorials on how to work with theme. We are planing to do more, but for now, <a href="%1$s">check if any tutorial</a> will help you.', 'apollo13-framework' ), esc_attr('https://apollo13themes.com/rife/help/#tutorials') ); ?></p>
	<p><?php echo sprintf( __( 'If you have idea for subject that we should cover in next tutorials, please <a href="%1$s">contact us</a>.', 'apollo13-framework' ), esc_attr('https://apollo13themes.com/contact/') ); ?></p>

	<h3 class="center"><a href="https://apollo13themes.com/contact/"><?php echo esc_html__( 'Contact Apollo13 Themes', 'apollo13-framework' ); ?></a></h3>
	<p><?php echo sprintf( __( 'If you feel like none of previously described options suits your needs, then you can always try to contact us via e-mail. Just come to <a href="%1$s">our contact page</a> and say hi :-)', 'apollo13-framework' ), esc_attr('https://apollo13themes.com/contact/') ); ?></p>


	<h2><?php echo esc_html__( 'Changes log:', 'apollo13-framework' ); ?></h2>
	<iframe class="change-log" src="http://www.apollo13.eu/themes_update/apollo13_framework_theme/index.html#change-log"></iframe>

	<h2><?php echo esc_html__( 'Theme requirements:', 'apollo13-framework' ); ?></h2>
	<div class="feature-section one-col">
		<div class="col">
			<?php apollo13framework_theme_requirements_table(); ?>
		</div>
	</div>

	<?php
	apollo13framework_theme_pages_footer();
}

function apollo13framework_theme_pages_header(){
	if(!current_user_can('install_plugins')){
		wp_die(esc_html__('Sorry, you are not allowed to access this page.', 'apollo13-framework'));
	}
	$pages = array(
		'apollo13_info' => esc_html__( 'License & Info', 'apollo13-framework' ),
		'apollo13_import' => esc_html__( 'Design Importer', 'apollo13-framework' ),
		'apollo13_help' => esc_html__( 'Get Help', 'apollo13-framework' ),
	);
	$tabs = '';
	foreach($pages as $page => $title){
		$tabs .= '<a href="'.esc_attr( admin_url( 'themes.php?page='.$page) ).'" class="nav-tab'.esc_attr($_GET['page'] === $page ? ' nav-tab-active' : '').'">'.$title.'</a>';
	}
?>
<div class="wrap apollo13-page <?php echo esc_attr($_GET['page']); ?> about-wrap">
	<h1><?php echo sprintf( esc_html__( 'Welcome to %s Theme', 'apollo13-framework' ), A13FRAMEWORK_OPTIONS_NAME_PART); ?></h1>

	<div class="about-text">
		<?php echo esc_html__( 'On these pages you can check what is new, import designs and get help if you will ever need it.', 'apollo13-framework' ); ?><br />
		<?php echo esc_html__( 'Thanks for being with us!', 'apollo13-framework' ); ?>
		<p class="socials"><a class="on-facebook" href="https://www.facebook.com/apollo13themes" target="_blank">Apollo13 on Facebook</a> | <a class="on-twitter" href="https://twitter.com/apollo13themes" target="_blank">Apollo13 on Twitter</a></p>
	</div>
	<div class="wp-badge"><?php echo esc_html__( 'Version', 'apollo13-framework' ).' '.A13FRAMEWORK_THEME_VER; ?></div>
	<h2 class="nav-tab-wrapper wp-clearfix">
		<?php echo $tabs; ?>
	</h2>
	<?php
}

function apollo13framework_theme_pages_footer(){
	echo '</div>';
}