<?php

/**
 * Framework class, to keep all settings encapsulated
 * Access to this singleton is via global $apollo13framework_a13
 */
class Apollo13Framework
{

    /**
     * current theme settings
     * @var array
     */
    private $theme_options = array();

    /**
     * Array of meta fields that depends on global settings
     * @var array
     */
    private $parents_of_meta = array();

    /**
     * Array of default values of meta fields on current screen
     * @var array
     */
    public $defaults_of_meta = array();

    /**
     * groups of options that will appear in Appearance menu
     * @var array
     */
    public $options_groups = array(
        'import',
    );

    private $reset_user_css = false;

    /**
     * kind of constructor
     */
    function start()
    {
        /**
         * Define bunch of helpful paths and settings
         */
        define('A13FRAMEWORK_TPL_SLUG', 'fatmoon');//it is not always same as directory of theme
        define('A13FRAMEWORK_OPTIONS_NAME_PART', 'FatMoon');
        define('A13FRAMEWORK_THEME_ENVATO_NUMBER', '15966469');

        //theme root
        define('A13FRAMEWORK_TPL_URI', get_template_directory_uri());
        define('A13FRAMEWORK_TPL_DIR', get_template_directory());

        //plugins bundled with theme
        define('A13FRAMEWORK_TPL_PLUGINS', A13FRAMEWORK_TPL_URI . '/advance/plugins');
        define('A13FRAMEWORK_TPL_PLUGINS_DIR', A13FRAMEWORK_TPL_DIR . '/advance/plugins');

        //user generated files
        define('A13FRAMEWORK_USER_GENERATED', A13FRAMEWORK_TPL_URI . '/user');
        define('A13FRAMEWORK_USER_GENERATED_DIR', A13FRAMEWORK_TPL_DIR . '/user');

        //custom post type settings
        define('A13FRAMEWORK_CUSTOM_POST_TYPE_ALBUM', 'album');
//		define('A13FRAMEWORK_CUSTOM_POST_TYPE_ALBUM_SLUG', 'album'); //just to show it also exist - defined in real a bit lower
        define('A13FRAMEWORK_CUSTOM_POST_TYPE_WORK', 'work');
//		define('A13FRAMEWORK_CUSTOM_POST_TYPE_WORK_SLUG', 'work'); //just to show it also exist - defined in real a bit lower
        define('A13FRAMEWORK_CUSTOM_POST_TYPE_NAV_A', 'nava');
        define('A13FRAMEWORK_CUSTOM_POST_TYPE_PEOPLE', 'people');
        define('A13FRAMEWORK_CPT_WORK_TAXONOMY', 'work_genre');
        define('A13FRAMEWORK_CPT_ALBUM_TAXONOMY', 'genre');
        define('A13FRAMEWORK_CPT_PEOPLE_TAXONOMY', 'group');

        //misc theme globals
        define('A13FRAMEWORK_VALIDATION_CLASS', 'apollo_validation_on');
        define('A13FRAMEWORK_INPUT_PREFIX', 'a13_');
        define('A13FRAMEWORK_CONTENT_WIDTH', 800);
        $upload_dir = wp_upload_dir();
        define('A13FRAMEWORK_IMPORTER_TMP_DIR', trailingslashit( $upload_dir['basedir'] ) . 'apollo13_tmp');
        define('A13FRAMEWORK_IMPORT_SERVER', 'http://apollo13.eu/file_sender');



        //check for theme version(we try to get parent theme version)
        $theme_data = wp_get_theme();
        $have_parent = $theme_data->parent();
        //Using child theme
        if ($have_parent) {
            /** @noinspection PhpUndefinedFieldInspection */
            $t_ver = $theme_data->parent()->Version;
        }
        //Using default theme
        else {
            /** @noinspection PhpUndefinedFieldInspection */
            $t_ver = $theme_data->Version;
        }
        define('A13FRAMEWORK_THEME_VER', $t_ver);

        // ADMIN PART
        if (is_admin()) {
            /** @noinspection PhpIncludeInspection */
            require_once( get_theme_file_path( 'advance/admin/admin.php' ) );
            /** @noinspection PhpIncludeInspection */
            require_once( get_theme_file_path( 'advance/admin/admin-ajax.php' ) );
            /** @noinspection PhpIncludeInspection */
            require_once( get_theme_file_path( 'advance/admin/metaboxes.php' ) );
            /** @noinspection PhpIncludeInspection */
            require_once( get_theme_file_path( 'advance/admin/print-options.php' ) );

            // ADD CUSTOMIZER ADDONS
            /** @noinspection PhpIncludeInspection */
            require_once( get_theme_file_path( 'advance/customizer.php' ));

            // ADD WPBakery Page Builder ADDONS
            /** @noinspection PhpIncludeInspection */
            require_once( get_theme_file_path( 'advance/vc-extend.php' ));

            // ADD ADMIN THEME PAGES
            /** @noinspection PhpIncludeInspection */
            require_once( get_theme_file_path( 'advance/apollo13-pages.php' ));
            /** @noinspection PhpIncludeInspection */
            require_once( get_theme_file_path( 'advance/apollo13-pages-functions.php' ));

            //ADD EXTERNAL PLUGINS
            /** @noinspection PhpIncludeInspection */
            require_once(get_theme_file_path( 'advance/inc/class-tgm-plugin-activation.php'));
            /** @noinspection PhpIncludeInspection */
            require_once(A13FRAMEWORK_TPL_PLUGINS_DIR . '/plugins-list.php');
        }
        //only for front-end
        else{
            // THEME FRONT-END SCRIPTS & STYLES
            /** @noinspection PhpIncludeInspection */
            require_once(get_theme_file_path( 'advance/head-scripts-styles.php'));
        }

        // AFTER SETUP(supports for thumbnails, menus, languages, RSS etc.)
        add_action('after_setup_theme', array(&$this, 'setup'));

        // Warnings and notices that only admin should handle
        if (current_user_can('update_core')) {
            add_action( 'admin_notices', array(&$this, 'check_for_warnings') );
        }

        //special files depending on framework generator needs
        if( is_file( get_theme_file_path( 'advance/envy.php' )) ){
            /** @noinspection PhpIncludeInspection */
            require_once get_theme_file_path( 'advance/envy.php');
        }
        if( is_file( get_theme_file_path( 'advance/rife.php') ) ){
            /** @noinspection PhpIncludeInspection */
            require_once get_theme_file_path( 'advance/rife.php');
        }

        // ADD MEGA MENU
        /** @noinspection PhpIncludeInspection */
        require_once(get_theme_file_path( 'advance/mega-menu.php'));

        // FUNCTION FOR MANAGING ALBUMS/WORKS
        /** @noinspection PhpIncludeInspection */
        require_once(get_theme_file_path( 'advance/cpt-admin.php'));

        // ADD SIDEBARS & WIDGETS
        /** @noinspection PhpIncludeInspection */
        require_once(get_theme_file_path( 'advance/widgets.php'));


        // UTILITIES
        /** @noinspection PhpIncludeInspection */
        require_once(get_theme_file_path( 'advance/utilities/_manager.php'));


        //Images library Apollo13_Image_Resize
        /** @noinspection PhpIncludeInspection */
        require_once(get_theme_file_path( 'advance/inc/class-apollo13-image-resize.php'));

        //Redux framework
        if ( class_exists( 'ReduxFramework' ) ) {
            $fresh_install = false;
            if(get_option('apollo13_option') === false){
                $fresh_install = true;
            }

            Redux::setExtensions('apollo13_option', get_theme_file_path( 'advance/advanced_customizer'));
            /** @noinspection PhpIncludeInspection */
            require_once(get_theme_file_path( 'advance/theme-options.php'));//must be call here, before loading the customizer

            //apollo13 extension fields
            /** @noinspection PhpIncludeInspection */
            require_once(get_theme_file_path( 'advance/inc/redux-extensions/sortable/field-sortable.php'));
            /** @noinspection PhpIncludeInspection */
            require_once(get_theme_file_path( 'advance/inc/redux-extensions/typography/field-typography.php'));

            //force redux to start - has to be done like this in order to work within class
            Redux::init('apollo13_option');

            //set default setting if there is none(fresh install)
            if($fresh_install){
                $file = get_theme_file_path( 'default-settings/default.php');
                if(file_exists($file)){
                    $file_contents = include $file;
                    $options = json_decode($file_contents, true);

                    $redux = ReduxFrameworkInstances::get_instance('apollo13_option');
                    $redux->set_options($options);
                    $this->reset_user_css = true;
                }
            }
        }else{
            //load default when Redux not activated yet
            $file = get_theme_file_path( 'default-settings/default.php');
            if(file_exists($file)){
                /** @noinspection PhpIncludeInspection */
                $file_contents = include $file;
                global $apollo13_option;
                $apollo13_option = json_decode($file_contents, true);
                //user.css file will be only created if it doesn't exist yet
            }
        }

        add_action( 'update_option_apollo13_option', array( $this, 'update_redux_defaults' ) );



        /**
         * Force Visual Composer to initialize as "built into the theme". This will hide certain tabs under the Settings->Visual Composer page
         */
        add_action('vc_before_init', 'apollo13framework_vcSetAsTheme');
        function apollo13framework_vcSetAsTheme(){
            vc_set_as_theme();
        }


        //GET THEME OPTIONS
        $this->set_options();

        //defined Theme constants after getting theme options
        if( isset($this->theme_options['cpt_post_type_album']) && isset($this->theme_options['cpt_post_type_work']) ){ // in case of very first pass after theme activation Redux has not saved options yet
            define('A13FRAMEWORK_CUSTOM_POST_TYPE_ALBUM_SLUG', $this->theme_options['cpt_post_type_album']);
            define('A13FRAMEWORK_CUSTOM_POST_TYPE_WORK_SLUG', $this->theme_options['cpt_post_type_work']);
        }else{
            define('A13FRAMEWORK_CUSTOM_POST_TYPE_ALBUM_SLUG', 'album');
            define('A13FRAMEWORK_CUSTOM_POST_TYPE_WORK_SLUG', 'work');
        }


        /**
         * perform option save after saving in theme's option panel
         */

        add_action('redux/page/apollo13_option/form/after', array($this, 'customizer_customize_save_after'));


        /**
         * perform option save while using customizer
         */
        if (is_customize_preview()) {
            add_action('customize_save_after', array($this, 'customizer_customize_save_after'));
        }

        //used to compere with global options
        $this->collect_meta_parents();

	    /**
         * @param WP_Customize_Manager $wp_customize
         */
        function apollo13framework_remove_customizer_settings( $wp_customize ){
            //due to https://core.trac.wordpress.org/ticket/33411

            //$wp_customize->remove_panel('nav_menus');
            $wp_customize->get_panel( 'nav_menus' )->active_callback = '__return_false';

        }
        add_action( 'customize_register', 'apollo13framework_remove_customizer_settings', 20 );
        add_action( 'admin_init', array($this,'autoimport_wpbakery_theme_grid_items') );

        // FOR DEBUGGING - often used
//		print_r( $this->theme_options );
//		print_r( $this->parents_of_meta );
    }

    // fired when themes update comes with updatede theme options
    function update_redux_defaults(){

        $current_options_version = get_option('Apollo13'.A13FRAMEWORK_OPTIONS_NAME_PART.'OptionsVersion');
        if( !$current_options_version || version_compare( A13FRAMEWORK_THEME_VER, $current_options_version ) > 0 ){
            update_option('Apollo13'.A13FRAMEWORK_OPTIONS_NAME_PART.'OptionsVersion', A13FRAMEWORK_THEME_VER );
            $redux             = ReduxFrameworkInstances::get_instance( 'apollo13_option' );
            $this->customizer_customize_save_after( $redux->get_options() );
        }
    }

    function autoimport_wpbakery_theme_grid_items() {
        // get the file
        $check = get_option( 'apollo13_grid_elements_loaded' );

        //done or VC not active
        if($check == 1 || !defined( 'WPB_VC_VERSION' ) ){
            return;
        }

        //after successful import the import file is deleted - so I check if it is still there not to run autoimport with non existing import file
        $import_file = A13FRAMEWORK_TPL_DIR . '/autoimport/import.xml';
        if( !file_exists($import_file) ){
            return;
        }

        /** @noinspection PhpIncludeInspection */
        require_once get_theme_file_path( '/autoimport/autoimporter.php' );
        //this shouldn't happen, but lets check
        if ( ! class_exists( 'Apollo13_Framework_Auto_Importer' ) ){
            return;
        }

        // call the function
        $args = array(
            'file'        => $import_file,
            'map_user_id' => 1
        );

        apollo13framework_auto_import( $args );
        update_option( 'apollo13_grid_elements_loaded', '1', false);
    }

    /**
     * used in customizer to prepare settings
     *
     */
    function customizer_wp_loaded()
    {
        $this->set_options();
    }

    /**
     * Refresh options and generate user.css file after save in customizer
     */
    function customizer_customize_save_after( $updated_options = array() )
    {
        //remember what are slugs before save
        $pre_save_album = $this->get_option('cpt_post_type_album') ;
        $pre_save_work = $this->get_option('cpt_post_type_work') ;

        $this->set_options( $updated_options );

        //check slugs after save
        $after_save_album = $this->get_option('cpt_post_type_album') ;
        $after_save_work = $this->get_option('cpt_post_type_work') ;

        $this->generate_user_css();

        //compare slugs and flush if there is a difference
        if( !($pre_save_album === $after_save_album && $pre_save_work === $after_save_work) ){
            //write option to force rewrite flush
            update_option('a13_force_to_flush','on');
        }

    }

    /**
     * Various setup actions for setting up theme for WordPress
     */
    function setup()
    {
        global $content_width;
        //content width
        if (!isset($content_width)) {
            $content_width = A13FRAMEWORK_CONTENT_WIDTH;
        }


        if (
            //forced refresh
            $this->reset_user_css ||
            //on fresh theme install/update
            !file_exists($this->user_css_name())
            //or customizer update after giving creds to FTP
             || (is_admin() && get_option('a13_user_css_update') === 'on')
        ) {
            $this->generate_user_css();
        }

        //if file system is not in direct mode, we need to ask for FTP creds to create user.css file
        if(is_admin() && get_option('a13_user_css_update') === 'on'){
            add_action( 'admin_notices', array(&$this, 'notice_about_user_css'), 0 );
        }

        //LANGUAGE
        load_theme_textdomain('apollo13-framework', get_theme_file_path('languages' ) );
        load_theme_textdomain('fatmoon', get_theme_file_path('languages' ) );

        // Featured image support
        add_theme_support('post-thumbnails');

        // Add default posts and comments RSS feed links to head
        add_theme_support('automatic-feed-links');

        //Let WordPress manage the document title.
        add_theme_support('title-tag');

        // Add post formats
        add_theme_support('post-formats', array(
            'aside',
            'chat',
            'gallery',
            'image',
            'link',
            'quote',
            'status',
            'video',
            'audio'
        ));

        // Switches default core markup for search form, comment form, and comments
        // to output valid HTML5.
        add_theme_support('html5', array('search-form', 'comment-form', 'comment-list'));

        // WooCommerce support
        add_theme_support('woocommerce');
        //new thumbs in WooCommerce 3.0.0
        add_theme_support( 'wc-product-gallery-zoom' );
        add_theme_support( 'wc-product-gallery-lightbox' );
        add_theme_support( 'wc-product-gallery-slider' );

        // Register custom menu positions
        register_nav_menus(array(
            'header-menu' => __( 'Site Navigation', 'apollo13-framework' ),
            'top-bar-menu' => __( 'Alternative short top bar menu', 'apollo13-framework' ),
        ));

        //Define at least one call of theme default text domain - be safe for warnings
        $theme_def_text_domain = __( 'Theme default text domain is', 'fatmoon');
    }

    /**
     * Displays FTP form in case of wrong permission or ownership to user directory
     */
    function notice_about_user_css(){
        echo '<div class="notice-warning notice">';
        printf( __( '<p>Creating <strong>%s</strong> file requires access to your FTP account.<br /> It is caused by the way your server is configured.<br /> This file is required so changes done is theme settings can take effect.</p>', 'apollo13-framework' ),  $this->user_css_name() );
        printf( __( '<p>Changing permissions or ownership to directory:<br /> <strong>%1$s</strong><br /> and/or<br /> <strong>%2$s</strong><br /> should fix the issue for need of your FTP credentials.</p>', 'apollo13-framework' ), A13FRAMEWORK_TPL_DIR, A13FRAMEWORK_USER_GENERATED_DIR );

        //this will cause form from WP_Filesystem to display
        $this->generate_user_css(false, false);
        echo '</div>';
    }

    /**
     * Function for warnings that should be displayed in admin area
     */
    function check_for_warnings()
    {
        $notices = array();
        $valid_tags = array(
            'a' => array(
                'href' => array(),
            ),
        );
        // Notice if dir for user settings is no writable
        if (!is_writeable(A13FRAMEWORK_USER_GENERATED_DIR)) {
            $notices[] = sprintf( esc_html__( 'Warning - directory %s is not writable.', 'apollo13-framework' ), A13FRAMEWORK_USER_GENERATED_DIR);
        }

        //NOTICE IF CPT SLUG IS TAKEN
        // albums
        $r = new WP_Query(array('post_type' => array('post', 'page'), 'name' => A13FRAMEWORK_CUSTOM_POST_TYPE_ALBUM_SLUG));
        if ($r->have_posts() && strlen(A13FRAMEWORK_CUSTOM_POST_TYPE_ALBUM_SLUG) ) {
            $notices[] = sprintf( wp_kses( __( 'Warning - slug for Albums is taken by page or post! It may cause problems with displaying albums. Edit slug of <a href="%s">this post</a> to make sure everything works good.', 'apollo13-framework' ), $valid_tags), site_url('/' . A13FRAMEWORK_CUSTOM_POST_TYPE_ALBUM_SLUG));
        }
        // Reset the global $the_post as this query have stomped on it
        wp_reset_postdata();

        // works
        $r = new WP_Query(array('post_type' => array('post', 'page'), 'name' => A13FRAMEWORK_CUSTOM_POST_TYPE_WORK_SLUG));
        if ($r->have_posts() && strlen(A13FRAMEWORK_CUSTOM_POST_TYPE_WORK_SLUG)) {
            $notices[] = sprintf( wp_kses( __( 'Warning - slug for Works is taken by page or post! It may cause problems with displaying works. Edit slug of <a href="%s">this post</a> to make sure everything works good.', 'apollo13-framework' ), $valid_tags), site_url('/' . A13FRAMEWORK_CUSTOM_POST_TYPE_WORK_SLUG));
        }
        // Reset the global $the_post as this query have stomped on it
        wp_reset_postdata();

        // Display all error notices
        foreach ($notices as $notice) {
            echo '<div class="notice notice-error is-dismissible"><p>' . $notice . '</p></div>';
        }

        do_action( 'apollo13framework_theme_notices' );
    }

    /**
     * Prepare all theme settings to be ready for read
     *
     */
    public function set_options( $overload_options = array() )
    {

        //load options managed by Redux framework
        global $apollo13_option;
        if( is_array($overload_options) && count($overload_options) > 0){
            $apollo13_option = $overload_options;
        }

        //do some adjustment
        if ( isset($apollo13_option['custom_sidebars']) && is_array($apollo13_option['custom_sidebars'])) {
            $tmp = array();
            foreach ($apollo13_option['custom_sidebars'] as $id => $sidebar) {
                array_push($tmp, array('id' => 'apollo13-sidebar_' . (1 + $id), 'name' => $sidebar));
            }
            $apollo13_option['custom_sidebars'] = serialize($tmp);
        }

        $tmp_socials = array();
        if ( isset($apollo13_option['social_services']) &&  is_array($apollo13_option['social_services']) ) {
            foreach ($apollo13_option['social_services'] as $id => $link) {
                array_push($tmp_socials, array('id' => $id, 'link' => $link));
            }
        }

        $apollo13_option['social_services'] = json_encode($tmp_socials);

        //finally load the options
        $this->theme_options = $apollo13_option;

    }

    /**
     * Get one of theme settings
     *
     * @param string $index setting id
     *
     * @return mixed
     */
    public function get_option($index)
    {
        $option_to_return = '';
        if ($index != '' && isset($this->theme_options[$index])) {
            $option_to_return = $this->theme_options[$index];
        }

        //apply filters to returned value if some special treating is needed
        return apply_filters('a13_options_'.$index, $option_to_return );
    }

    /**
     * Get url only from media type theme setting
     *
     * @param string $index setting id
     *
     * @return string URL
     */
    public function get_option_media_url($index)
    {
        $option = $this->get_option($index);
        if (is_array($option)) {
            if (isset($option['url'])) {
                return $option['url']; //we got URL
            } else {
                return ''; //empty string as it is probably not set yet
            }
        }

        return $option;//not an array? then probably it is saved as string
    }


    /**
     * Get rgba only from color type theme setting
     *
     * @param string $index setting_id
     *
     * @return string URL
     */
    public function get_option_color_rgba( $index )
    {
        $option = $this->get_option( $index );
        if ( is_array( $option ) ) {
            if ( isset( $option['rgba'] ) ) {
                return $option['rgba']; //we got RGBA
            } elseif ( isset( $option['color'] ) && isset( $option['alpha'] ) ) {
                return apollo13framework_hex2rgba( $option['color'], $option['alpha'] ); //we got RGBA
            } else {
                return ''; //empty string as it is probably not set yet
            }
        }

        return $option;//not an array? then probably it is saved as string
    }

    /**
     * Get all settings. Used for exporting theme options
     *
     * @return array
     */
    public function get_options_array()
    {
        return $this->theme_options;
    }

    /**
     * Prepares var $parents_of_meta
     */
    private function collect_meta_parents()
    {
        /** @noinspection PhpIncludeInspection */
        require_once(get_theme_file_path( 'advance/meta.php'));

        $option_func = array(
            'post',
            'page',
            'album',
            'work',
            'people',
//            'images_manager' //no parent options here
        );

        foreach ($option_func as $function) {
            $function_to_call = 'apollo13framework_meta_boxes_' . $function;
            $family = str_replace('_layout', '', $function); //for consistent families

            foreach ($function_to_call() as $meta) {
                if (isset($meta['global_value'])) {
                    $this->parents_of_meta[$family][$meta['id']]['global_value'] = $meta['global_value'];
                }
                if (isset($meta['parent_option'])) {
                    $this->parents_of_meta[$family][$meta['id']]['parent_option'] = $meta['parent_option'];
                }
            }
        }
    }

    /**
     * Prepares list off all meta fields that have visibility dependencies and second list of possible switches with dependent fields
     */
    public function get_meta_required_array() {
        global $pagenow;
        $list_of_requirements = array();
        $list_of_dependent    = array();
        $meta_boxes           = array();


        $post_type = '';
        if ('post.php' == $pagenow && isset($_GET['post']) ) {
            // Will occur only in this kind of screen: /wp-admin/post.php?post=285&action=edit
            // and it can be a Post, a Page or a CPT
            $post_type = get_post_type($_GET['post']);
        }
        //if it is "new post" page
        elseif('post-new.php' == $pagenow ) {
            $post_type = isset($_GET['post_type']) ? $_GET['post_type'] : 'post';
        }

        if(strlen($post_type)){
            switch ( $post_type ) {
                case 'post':
                    $meta_boxes = apollo13framework_meta_boxes_post();
                    break;
                case 'page':
                    $meta_boxes = apollo13framework_meta_boxes_page();
                    break;
                case A13FRAMEWORK_CUSTOM_POST_TYPE_ALBUM:
                    $meta_boxes = array_merge( apollo13framework_meta_boxes_album(), apollo13framework_meta_boxes_images_manager() );
                    break;
                case A13FRAMEWORK_CUSTOM_POST_TYPE_WORK:
                    $meta_boxes = array_merge( apollo13framework_meta_boxes_work(), apollo13framework_meta_boxes_images_manager() );
                    break;
            }

            foreach ( $meta_boxes as &$meta ) {
                //check is it prototype
                if ( isset( $meta['required'] ) ) {
                    $required = $meta['required'];

                    //fill list of required condition for each control
                    $list_of_requirements[ $meta['id'] ] = $required;

                    //fill list of controls that activate/deactivate other
                    //we have more then one required condition
                    if(is_array($required[0]) ){
                        foreach($required as $dependency){
                            $list_of_dependent[$dependency[0]][] = $meta['id'];
                        }
                    }
                    //we have only one required condition
                    else{
                        $list_of_dependent[$required[0]][] = $meta['id'];
                    }
                }
            }
        }

        return array($list_of_requirements, $list_of_dependent);
    }

    /**
     * Get name of user CSS file in case of multi site or switcher
     *
     * @param bool|false $public if false it will return path for include,
     *                           if true it will return path for source(http://path.to.file)
     *
     * @return string path to file
     */
    function user_css_name($public = false)
    {
        $name = ($public ? A13FRAMEWORK_USER_GENERATED : A13FRAMEWORK_USER_GENERATED_DIR) . '/user'; /* user.css - comment just for easier searching */
        if (is_multisite()) {
            //add blog id to file
            $name .= '_' . get_current_blog_id();
        }

        return $name . '.css';
    }

    /**
     * Make user CSS file from theme layout options
     *
     * @param bool $force_to
     *
     * @param bool $hide_errors
     *
     */
    function generate_user_css( $force_to = false, $hide_errors = true ) {
        // in case of very first pass after theme activation, Redux has not saved options yet
        // but 'social_services' are present in array because of $this->set_options function
        if( !$force_to && (empty($this->theme_options) || (count($this->theme_options) == 1 && isset( $this->theme_options['social_services'] ) ) ) ){
            return;
        }

        $save_result = 1;

        if($hide_errors){
            ob_start();
        }

        //prepare file system

        //just in case have this files included
        require_once ABSPATH . '/wp-admin/includes/file.php';
        require_once(ABSPATH . 'wp-admin/includes/template.php');

        //we are checking if file system can operate without FTP creds
        $url = wp_nonce_url(admin_url(),'');
        if (false === ($creds = request_filesystem_credentials($url, '', false, false, null) ) ) {
            $save_result = 0;
        }
        elseif ( ! WP_Filesystem($creds) ) {
            request_filesystem_credentials($url, '', true, false, null);
            $save_result = 0;
        }

        //if we have good FTP creds or system operates with "direct" method
        if($save_result === 1){
            global $wp_filesystem;
            /* @var $wp_filesystem WP_Filesystem_Base */

            if (is_writable(A13FRAMEWORK_USER_GENERATED_DIR) ) {
                $file = $this->user_css_name();

                //in case of FTP access we need to make sure we have proper path
                $file = str_replace(ABSPATH, $wp_filesystem->abspath(), $file);

                /** @noinspection PhpIncludeInspection */
                $css = include(get_theme_file_path( 'advance/user-css.php'));
                $wp_filesystem->put_contents(
                    $file,
                    $css,
                    FS_CHMOD_FILE
                );

                //remove any pending update request
                update_option('a13_user_css_update','off');
            }
        }
        //we couldn't save
        else{
            update_option('a13_user_css_update','on');
        }

        if($hide_errors){
            ob_end_clean();
        }
    }

    /**
     * Retrieves meta setting with checking for parent settings, and global settings
     *
     * @param string $field name of meta setting
     * @param bool|false $id ID of post. If not passed it will try to get one for current loop
     *
     * @return bool|mixed|null|string field value
     */
    function get_meta($field, $id = false)
    {
        $family = '';

        if (!$id && apollo13framework_is_no_property_page()) {
            return null; //we can't get meta field for that page
        } else {
            if (!$id) {
                $id = get_the_ID();
            }

            $meta = trim(get_post_meta($id, $field, true));
        }

        if ($id) {
            //get family to check for parent option
            if (get_post_type($id) == A13FRAMEWORK_CUSTOM_POST_TYPE_ALBUM) {
                $family = 'album';
            } else if (get_post_type($id) == A13FRAMEWORK_CUSTOM_POST_TYPE_WORK) {
                $family = 'work';
            } elseif (is_page($id)) {
                $family = 'page';
            } elseif (is_single($id)) {
                $family = 'post';
            }

            $field = substr($field, 1); //remove '_'

            //if has any parent
            if (isset($this->parents_of_meta[$family][$field])) {
                $parent = $this->parents_of_meta[$family][$field];

                //meta points to global setting
                if (isset($parent['global_value']) && ($meta == $parent['global_value'] || strlen($meta) == 0)) {
                    if (isset($parent['parent_option'])) {
                        $meta = $this->get_option($parent['parent_option']);
                    }
                }
            }

            return $meta;
        }

        return false;
    }

    /**
     * Returns list of all available in theme social icons with need additional info
     *
     * @param string $what - what should array consist of:
     *                     names    : Readable names
     *                     classes  : CSS classes used on front-end
     *                     empty    : only IDs are returned
     *
     * @return array requested list of social icons
     */
    function get_social_icons_list($what = 'names'){
        $icons = array(
            /* id         => array(class, label)*/
            '500px'       => array( 'fa fa-500px', '500px' ),
            'behance'     => array( 'fa fa-behance', 'Behance' ),
            'bitbucket'   => array( 'fa fa-bitbucket', 'Bitbucket' ),
            'codepen'     => array( 'fa fa-codepen', 'CodePen' ),
            'delicious'   => array( 'fa fa-delicious', 'Delicious' ),
            'deviantart'  => array( 'fa fa-deviantart', 'Deviantart' ),
            'digg'        => array( 'fa fa-digg', 'Digg' ),
            'dribbble'    => array( 'fa fa-dribbble', 'Dribbble' ),
            'dropbox'     => array( 'fa fa-dropbox', 'Dropbox' ),
            'mailto'      => array( 'fa fa-envelope-o', 'E-mail' ),
            'facebook'    => array( 'fa fa-facebook', 'Facebook' ),
            'flickr'      => array( 'fa fa-flickr', 'Flickr' ),
            'foursquare'  => array( 'fa fa-foursquare', 'Foursquare' ),
            'github'      => array( 'fa fa-git', 'Github' ),
            'googleplus'  => array( 'fa fa-google-plus', 'Google Plus' ),
            'instagram'   => array( 'fa fa-instagram', 'Instagram' ),
            'lastfm'      => array( 'fa fa-lastfm', 'Lastfm' ),
            'linkedin'    => array( 'fa fa-linkedin', 'Linkedin' ),
            'paypal'      => array( 'fa fa-paypal', 'Paypal' ),
            'pinterest'   => array( 'fa fa-pinterest-p', 'Pinterest' ),
            'reddit'      => array( 'fa fa-reddit-alien', 'Reddit' ),
            'rss'         => array( 'fa fa-rss', 'RSS' ),
            'sharethis'   => array( 'fa fa-share-alt', 'Sharethis' ),
            'skype'       => array( 'fa fa-skype', 'Skype' ),
            'slack'       => array( 'fa fa-slack', 'Slack' ),
            'snapchat'    => array( 'fa fa-snapchat-ghost', 'Snapchat' ),
            'spotify'     => array( 'fa fa-spotify', 'Spotify' ),
            'steam'       => array( 'fa fa-steam', 'Steam' ),
            'stumbleupon' => array( 'fa fa-stumbleupon', 'Stumbleupon' ),
            'tumblr'      => array( 'fa fa-tumblr', 'Tumblr' ),
            'twitter'     => array( 'fa fa-twitter', 'Twitter' ),
            'viadeo'      => array( 'fa fa-viadeo', 'Viadeo' ),
            'vimeo'       => array( 'fa fa-vimeo', 'Vimeo' ),
            'vine'        => array( 'fa fa-vine', 'Vine' ),
            'vkontakte'   => array( 'fa fa-vk', 'VKontakte' ),
            'whatsapp'    => array( 'fa fa-whatsapp', 'Whatsapp' ),
            'wordpress'   => array( 'fa fa-wordpress', 'WordPress' ),
            'xing'        => array( 'fa fa-xing', 'Xing' ),
            'yahoo'       => array( 'fa fa-yahoo', 'Yahoo' ),
            'yelp'        => array( 'fa fa-yelp', 'Yelp' ),
            'youtube'     => array( 'fa fa-youtube', 'YouTube' ),
        );

        $icons = apply_filters('apollo13framework_social_icons_list', $icons );

        /* SAMPLE USAGE */
        /*
        add_filter('apollo13framework_social_icons_list', function($icons){
            $icons['youtube']     =  array( 'fa fa-youtube-play', 'Youtube' );
            $icons['new_service'] =  array( 'fa fa-star', 'My social' );

            return $icons;
        });
         *
        */

        $result = array();

        //return classes
        if($what === 'classes'){
            foreach( $icons as $id => $icon ){
                $result[$id] = $icon[0];
            }
        }

        //empty values
        elseif($what === 'empty'){
            foreach( $icons as $id => $icon ){
                $result[$id] = '';
            }
        }

        //return names
        else{
            foreach( $icons as $id => $icon ){
                $result[$id] = $icon[1];
            }
        }

        return $result;
    }

    function check_for_valid_license(){
        return apply_filters('apollo13framework_valid_license', false);
    }

    function check_is_import_allowed(){
        return apply_filters('apollo13framework_is_import_allowed', $this->check_for_valid_license());
    }

    function register_new_license_code($code){
        $out = array();
        return apply_filters('apollo13framework_register_license', $out, $code);
    }

    function get_license_code(){
        return apply_filters('apollo13framework_get_license', false);
    }

    function get_docs_link($location = ''){
        $locations = apply_filters( 'apollo13framework_docs_locations', array(
            'license-code'           => 'docs/getting-started/where-i-can-find-license-code/',
            'header-color-variants'  => 'docs/customizing-the-theme/header/variant-light-dark-overwrites/',
            'importer-configuration' => 'docs/installation-updating/importing-designs/importer-configuration/',
        ) );

        if(strlen($location) && array_key_exists($location, $locations)){
            $location = $locations[$location];
        }

        return apply_filters('apollo13framework_docs_address', 'http://rifetheme.com/apollo13-framework/').$location;
    }

    /**
     * Returns hidden code to protect it from easy copy
     *
     * @param $code string
     *
     * @return string "stared code"
     */
    function mask_code($code){
        //"star" code
        $changed_code = preg_replace('/[a-z0-9]/i', '*', $code);

        //parts of original code
        $first_chars = substr($code, 0, 2);
        $last_chars = substr($code, -2, 2);

        //merge
        $changed_code = substr_replace($changed_code, $first_chars, 0, 2);
        $changed_code = substr_replace($changed_code, $last_chars, -2, 2);

        return $changed_code;
    }
}
