<?php



function apollo13framework_setup_theme_options() {
	global $apollo13framework_a13;

	if ( ! class_exists( 'Redux' ) ) {
		return;
	}

	//flag to remove Redux options panel for end users
	$customizer_only = ! apollo13framework_is_home_server();

	//get all cursors
	$cursors = array();
	$dir     = get_theme_file_path( 'images/cursors' );
	if ( is_dir( $dir ) ) {
		//The GLOB_BRACE flag is not available on some non GNU systems, like Solaris. So we use merge:-)
		foreach ( (array) glob( $dir . '/*.png' ) as $file ) {
			$cursors[ basename( $file ) ] = basename( $file );
		}
	}

	//get all menu effects
	$menu_effects = array(
		'none'      => esc_html__( 'None', 'apollo13-framework' ),
		'show_icon' => esc_html__( 'Show icon', 'apollo13-framework' )
	);
	$dir          = get_theme_file_path( 'css/menu-effects' );
	if ( is_dir( $dir ) ) {
		//The GLOB_BRACE flag is not available on some non GNU systems, like Solaris. So we use merge:-)
		foreach ( (array) glob( $dir . '/*.css' ) as $file ) {
			$name                  = basename( $file, '.css' );
			$menu_effects[ $name ] = $name;
		}
	}

	/** @noinspection PhpVoidFunctionResultUsedInspection - REDUX method is written in bad style */
	$header_sidebars = Redux::getOption( 'apollo13_option', 'custom_sidebars' );
	if ( ! is_array( $header_sidebars ) ) {
		$header_sidebars = array();
	}
	$header_sidebars            = array_merge( array( 'off' => esc_html__( 'Off', 'apollo13-framework' ) ), $header_sidebars );
	$header_sidebars_off_global = array_merge( array( 'G' => esc_html__( 'Global settings', 'apollo13-framework' ) ), $header_sidebars );
	//reindexing this arrays
	array_unshift( $header_sidebars, null );
	unset( $header_sidebars[0] );
	array_unshift( $header_sidebars_off_global, null );
	unset( $header_sidebars_off_global[0] );


	// This is your option name where all the Redux data is stored.
	$opt_name = 'apollo13_option';

	/**
	 * ---> SET ARGUMENTS
	 * All the possible arguments for Redux.
	 * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
	 * */

	$theme = wp_get_theme(); // For use with some settings. Not necessary.

	$args = array(
		// TYPICAL -> Change these values as you need/desire
		'opt_name'             => $opt_name,
		'ajax_save'            => false,
		// This is where your data is stored in the database and also becomes your global variable name.
		'display_name'         => $theme->get( 'Name' ),
		// Name that appears at the top of your panel
		'display_version'      => $theme->get( 'Version' ),
		// Version that appears at the top of your panel
		'menu_type'            => 'menu',
		//Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
		'allow_sub_menu'       => true,
		// Show the sections below the admin menu item or not
		'menu_title'           => esc_html__( 'Theme custom options', 'apollo13-framework' ),
		'page_title'           => esc_html__( 'Theme custom options', 'apollo13-framework' ),
		// You will need to generate a Google API key to use this feature.
		// Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
		'google_api_key'       => '',
		// Set it you want google fonts to update weekly. A google_api_key value is required.
		'google_update_weekly' => false,
		// Must be defined to add google fonts to the typography module
		'async_typography'     => false,
		// Use a asynchronous font on the front end or font string
		//'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
		'admin_bar'            => true,
		// Show the panel pages on the admin bar
		'admin_bar_icon'       => 'dashicons-portfolio',
		// Choose an icon for the admin bar menu
		'admin_bar_priority'   => 50,
		// Choose an priority for the admin bar menu
		'global_variable'      => '',
		// Set a different name for your global variable other than the opt_name
		'dev_mode'             => false,
		//want dev mode off on localhost? uncomment below
		'forced_dev_mode_off'  => true,
		// Show the time the page took to load, etc
		'update_notice'        => false,
		// If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
		'customizer'           => true,
		'customizer_only'      => ! apollo13framework_is_home_server(),
		// Enable basic customizer support
		//'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
		//'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

		// OPTIONAL -> Give you extra features
		'page_priority'        => null,
		// Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
		'page_parent'          => 'themes.php',
		//
		'page_permissions'     => 'manage_options',
		// Permissions needed to access the options panel.
		'menu_icon'            => '',
		// Specify a custom URL to an icon
		'last_tab'             => '',
		// Force your panel to always open to a specific tab (by id)
		'page_icon'            => 'icon-themes',
		// Icon displayed in the admin panel next to your menu_title
		'page_slug'            => '_options',
		// Page slug used to denote the panel
		'save_defaults'        => true,
		// On load save the defaults to DB before user clicks save or not
		'default_show'         => false,
		// If true, shows the default value next to each field that is not the default value.
		'default_mark'         => '',
		// What to print by the field's title if the value shown is default. Suggested: *
		'show_import_export'   => true,
		// Shows the Import/Export panel when not used as a field.
		'show_options_object'  => false,
		// CAREFUL -> These options are for advanced use only
		'transient_time'       => 60 * MINUTE_IN_SECONDS,
		'output'               => true,
		// Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
		'output_tag'           => true,
		// Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
		// 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

		// FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
		'database'             => '',
		// possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!

		'use_cdn'              => true,
		// If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

		//'compiler'             => true,

		// HINTS
		'hints'                => array(
			'icon'          => 'el el-question-sign',
			'icon_position' => 'right',
			'icon_color'    => 'lightgray',
			'icon_size'     => 'normal',
			'tip_style'     => array(
				'color'   => 'light',
				'shadow'  => true,
				'rounded' => false,
				'style'   => '',
			),
			'tip_position'  => array(
				'my' => 'top left',
				'at' => 'bottom right',
			),
			'tip_effect'    => array(
				'show' => array(
					'effect'   => 'slide',
					'duration' => '500',
					'event'    => 'mouseover',
				),
				'hide' => array(
					'effect'   => 'slide',
					'duration' => '500',
					'event'    => 'click mouseleave',
				),
			),
		)
	);

	$valid_tags = array(
		'a' => array(
			'href' => array(),
		),
		'br' => array(),
		'code'  => array(),
		'em'  => array(),
		'strong' => array(),
	);

// ADMIN BAR LINKS -> Setup custom links in the admin bar menu as external items.


// SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.


	// Panel Intro text -> before the form
	$args['intro_text'] = '';

	// Add content after the form.
	$args['footer_text'] = '';

	Redux::setArgs( $opt_name, $args );

/*
 * ---> END ARGUMENTS
 */


/*
 *
 * ---> START SECTIONS
 *
 */

//GENERAL SETTINGS
	Redux::setSection( $opt_name, array(
		'title'           => esc_html__( 'General settings', 'apollo13-framework' ),
		'desc'            => '',
		'id'              => 'section_general_settings',
		'icon'            => 'el el-adjust-alt',
		'priority'        => 1,
		'customizer_only' => $customizer_only,
		'fields'          => array()
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Front page', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_general_front_page',
		'icon'       => 'fa fa-home',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'fp_variant',
				'type'     => 'select',
				'title'    => esc_html__( 'What to show on front page?', 'apollo13-framework' ),
				'subtitle' => wp_kses( __( 'If you choose <strong>Page</strong> then make sure that in Settings->Reading->Front page displays you selected <strong>A static page</strong>, that you wish to use.', 'apollo13-framework' ), $valid_tags ),
				'options'  => array(
					'page'         => esc_html__( 'Page', 'apollo13-framework' ),
					'blog'         => esc_html__( 'Blog', 'apollo13-framework' ),
					'single_album' => esc_html__( 'Single album', 'apollo13-framework' ),
					'albums_list'  => esc_html__( 'Albums list', 'apollo13-framework' ),
					'single_work'  => esc_html__( 'Single work', 'apollo13-framework' ),
					'works_list'   => esc_html__( 'Works list', 'apollo13-framework' ),
				),
				'default'  => 'page'
			),
			array(
				'id'       => 'fp_album',
				'type'     => 'select',
				'data'     => 'posts',
				'args'     => array(
					'post_type'      => A13FRAMEWORK_CUSTOM_POST_TYPE_ALBUM,
					'posts_per_page' => - 1
				),
				'title'    => esc_html__( 'Select album to use as front page', 'apollo13-framework' ),
				'subtitle' => '',
				'required' => array( 'fp_variant', '=', 'single_album' ),
			),
			array(
				'id'       => 'fp_work',
				'type'     => 'select',
				'data'     => 'posts',
				'args'     => array(
					'post_type'      => A13FRAMEWORK_CUSTOM_POST_TYPE_WORK,
					'posts_per_page' => - 1
				),
				'title'    => esc_html__( 'Select work to use as front page', 'apollo13-framework' ),
				'subtitle' => '',
				'required' => array( 'fp_variant', '=', 'single_work' ),
			),

		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'General layout', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_main_settings',
		'icon'       => 'fa fa-wrench',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'         => 'appearance_body_image',
				'type'       => 'media',
				'title'      => esc_html__( 'Background image', 'apollo13-framework' ),
				'full_width' => false,
				'mode'       => 'image',
				'subtitle'   => '',
			),
			array(
				'id'       => 'appearance_body_image_fit',
				'type'     => 'select',
				'title'    => esc_html__( 'How to fit background image', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'cover'    => esc_html__( 'Cover', 'apollo13-framework' ),
					'contain'  => esc_html__( 'Contain', 'apollo13-framework' ),
					'fitV'     => esc_html__( 'Fit Vertically', 'apollo13-framework' ),
					'fitH'     => esc_html__( 'Fit Horizontally', 'apollo13-framework' ),
					'center'   => esc_html__( 'Just center', 'apollo13-framework' ),
					'repeat'   => esc_html__( 'Repeat', 'apollo13-framework' ),
					'repeat-x' => esc_html__( 'Repeat X', 'apollo13-framework' ),
					'repeat-y' => esc_html__( 'Repeat Y', 'apollo13-framework' ),
				),
				'default'  => 'cover'
			),
			array(
				'id'       => 'appearance_body_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Background color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '#999999',
			),
			array(
				'id'      => 'layout_type',
				'type'    => 'button_set',
				'title'   => esc_html__( 'Layout type', 'apollo13-framework' ),
				'options' => array(
					'full'     => esc_html__( 'Full width', 'apollo13-framework' ),
					'bordered' => esc_html__( 'Bordered', 'apollo13-framework' ),
					'boxed'    => esc_html__( 'Boxed', 'apollo13-framework' ),
				),
				'default' => 'full'
			),
			array(
				'id'       => 'boxed_layout_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Boxed layout background color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => array(
					'color' => '#ffffff',
					'alpha' => 1
				),
				'required' => array( 'layout_type', '=', 'boxed' ),
			),
			array(
				'id'       => 'theme_borders_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Borders color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => array(
					'color' => '#ffffff',
					'alpha' => 1
				),
				'required' => array( 'layout_type', '=', 'bordered' ),
			),
			array(
				'id'       => 'theme_borders',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Borders to show', 'apollo13-framework' ),
				'options'  => array(
					'top'    => esc_html__( 'Top', 'apollo13-framework' ),
					'right'  => esc_html__( 'Right', 'apollo13-framework' ),
					'bottom' => esc_html__( 'Bottom', 'apollo13-framework' ),
					'left'   => esc_html__( 'Left', 'apollo13-framework' ),
				),
				'multi'    => true,
				'default'  => array( 'top', 'left', 'bottom', 'right' ),
				'required' => array( 'layout_type', '=', 'bordered' ),
			),
			array(
				'id'       => 'custom_cursor',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Mouse cursor', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'default' => esc_html__( 'Normal', 'apollo13-framework' ),
					'select'  => esc_html__( 'Predefined', 'apollo13-framework' ),
					'custom'  => esc_html__( 'Custom', 'apollo13-framework' ),
				),
				'default'  => 'default',
			),
			array(
				'id'       => 'cursor_select',
				'type'     => 'select',
				'title'    => esc_html__( 'Cursors', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => $cursors,
				'default'  => 'empty_black_white.png',
				'required' => array( 'custom_cursor', '=', 'select' ),
			),
			array(
				'id'         => 'cursor_image',
				'type'       => 'media',
				'title'      => esc_html__( 'Custom cursor image', 'apollo13-framework' ),
				'full_width' => false,
				'mode'       => 'image',
				'subtitle'   => '',
				'required'   => array( 'custom_cursor', '=', 'custom' ),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Page preloader', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_page_preloader',
		'icon'       => 'fa fa-spinner',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'preloader',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Page preloader', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'CSS animations used in preloader works best in modern browsers.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on'
			),
			array(
				'id'       => 'preloader_hide_event',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Hide event', 'apollo13-framework' ),
				'subtitle' => wp_kses( __( '<strong>On load</strong> is called when whole site with all images are loaded, what can take lot of time on heavier sites, and even more on mobile. Also it can sometimes hang and never hide, when there is problem with some resource. <br /><strong>On DOM ready</strong> is called when whole HTML with CSS is loaded, so after preloader will hide, you can still see loading images.', 'apollo13-framework' ), $valid_tags ),
				'options'  => array(
					'ready' => esc_html__( 'On DOM ready', 'apollo13-framework' ),
					'load'  => esc_html__( 'On load', 'apollo13-framework' ),
				),
				'default'  => 'ready',
				'required' => array( 'preloader', '=', 'on' ),
			),
			array(
				'id'         => 'preloader_bg_image',
				'type'       => 'media',
				'title'      => esc_html__( 'Background image', 'apollo13-framework' ),
				'full_width' => false,
				'mode'       => 'image',
				'subtitle'   => '',
				'required'   => array( 'preloader', '=', 'on' ),
			),
			array(
				'id'       => 'preloader_bg_image_fit',
				'type'     => 'select',
				'title'    => esc_html__( 'How to fit background image', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'cover'    => esc_html__( 'Cover', 'apollo13-framework' ),
					'contain'  => esc_html__( 'Contain', 'apollo13-framework' ),
					'fitV'     => esc_html__( 'Fit Vertically', 'apollo13-framework' ),
					'fitH'     => esc_html__( 'Fit Horizontally', 'apollo13-framework' ),
					'center'   => esc_html__( 'Just center', 'apollo13-framework' ),
					'repeat'   => esc_html__( 'Repeat', 'apollo13-framework' ),
					'repeat-x' => esc_html__( 'Repeat X', 'apollo13-framework' ),
					'repeat-y' => esc_html__( 'Repeat Y', 'apollo13-framework' ),
				),
				'default'  => 'cover',
				'required' => array( 'preloader', '=', 'on' ),
			),
			array(
				'id'       => 'preloader_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Background color', 'apollo13-framework' ),
				'subtitle' => '',
				'required' => array( 'preloader', '=', 'on' ),
				'default'  => '',
			),
			array(
				'id'       => 'preloader_type',
				'type'     => 'select',
				'title'    => esc_html__( 'Type', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'none'              => esc_html__( 'none', 'apollo13-framework' ),
					'atom'              => esc_html__( 'Atom', 'apollo13-framework' ),
					'flash'             => esc_html__( 'Flash', 'apollo13-framework' ),
					'indicator'         => esc_html__( 'Indicator', 'apollo13-framework' ),
					'radar'             => esc_html__( 'Radar', 'apollo13-framework' ),
					'circle_illusion'   => esc_html__( 'Circle Illusion', 'apollo13-framework' ),
					'square_of_squares' => esc_html__( 'Square of squares', 'apollo13-framework' ),
					'plus_minus'        => esc_html__( 'Plus minus', 'apollo13-framework' ),
					'hand'              => esc_html__( 'Hand', 'apollo13-framework' ),
					'blurry'            => esc_html__( 'Blurry', 'apollo13-framework' ),
					'arcs'              => esc_html__( 'Arcs', 'apollo13-framework' ),
					'tetromino'         => esc_html__( 'Tetromino', 'apollo13-framework' ),
					'infinity'          => esc_html__( 'Infinity', 'apollo13-framework' ),
					'cloud_circle'      => esc_html__( 'Cloud circle', 'apollo13-framework' ),
					'dots'              => esc_html__( 'Dots', 'apollo13-framework' ),
					'jet_pack_man'      => esc_html__( 'Jet-Pack-Man', 'apollo13-framework' ),
					'circle'            => 'Circle'
				),
				'default'  => 'flash',
				'required' => array( 'preloader', '=', 'on' ),
			),
			array(
				'id'       => 'preloader_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Animation color', 'apollo13-framework' ),
				'subtitle' => '',
				'required' => array( 'preloader', '=', 'on' ),
				'default'  => '',
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Cookie message', 'apollo13-framework' ),
		'desc'       => esc_html__( 'When it is closed, then message will not display for user for next 7 days. Good for cookie information.', 'apollo13-framework' ),
		'id'         => 'subsection_top_message',
		'icon'       => 'fa fa-cog',
		'subsection' => true,
		'fields'     => array(
			array(
				'title'   => esc_html__( 'Cookie message', 'apollo13-framework' ),
				'id'      => 'top_message',
				'default' => 'off',
				'options' => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'type'    => 'button_set',
			),
			array(
				'id'       => 'top_message_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Background color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => array(
					'color' => '#ffffff',
					'alpha' => 1
				),
				'required' => array( 'top_message', '=', 'on' ),
			),
			array(
				'title'    => esc_html__( 'Text color', 'apollo13-framework' ),
				'id'       => 'top_message_text_color',
				'default'  => array(
					'color' => '#000000',
					'alpha' => 1
				),
				'type'     => 'color_rgba',
				'required' => array( 'top_message', '=', 'on' ),
			),
			array(
				'title'    => esc_html__( 'Links color', 'apollo13-framework' ),
				'id'       => 'top_message_link_color',
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'top_message', '=', 'on' ),
			),
			array(
				'title'    => esc_html__( 'Links hover', 'apollo13-framework' ),
				'id'       => 'top_message_link_color_hover',
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'top_message', '=', 'on' ),
			),
			array(
				'title'    => esc_html__( 'Text transform', 'apollo13-framework' ),
				'id'       => 'top_message_text_transform',
				'default'  => 'none',
				'options'  => array(
					'none'      => esc_html__( 'None', 'apollo13-framework' ),
					'uppercase' => esc_html__( 'Uppercase', 'apollo13-framework' ),
				),
				'type'     => 'button_set',
				'required' => array( 'top_message', '=', 'on' ),
			),
			array(
				'title'    => esc_html__( 'Message text', 'apollo13-framework' ),
				'desc'     => esc_html__( 'You can use HTML here.', 'apollo13-framework' ),
				'id'       => 'top_message_text',
				'default'  => '',
				'type'     => 'textarea',
				'required' => array( 'top_message', '=', 'on' ),
			),
			array(
				'id'       => 'top_message_button',
				'type'     => 'text',
				'title'    => esc_html__( 'Close button text', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'If left empty then it will be just "X"', 'apollo13-framework' ),
				'default'  => '',
				'required' => array( 'top_message', '=', 'on' ),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Footer', 'apollo13-framework' ),
		'desc'       => esc_html__( 'Some colors and options will be ignored when vertical header is activated, cause then footer is integrated in header.', 'apollo13-framework' ),
		'id'         => 'subsection_footer',
		'icon'       => 'fa fa-ellipsis-h',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'footer_switch',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Footer', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'footer_unravel_effect',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Footer unravel effect', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Works only with horizontal header. It makes footer fixed to bottom, but hidden under main content, so when you scroll down to footer it unravels its self.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
				'required' => array(
					array( 'footer_switch', '=', 'on' ),
					array( 'header_type', '=', 'horizontal' ),
				)
			),
			array(
				'title'    => esc_html__( 'Widgets columns number', 'apollo13-framework' ),
				'id'       => 'footer_widgets_columns',
				'default'  => '3',
				'options'  => array(
					'1' => esc_html__( '1', 'apollo13-framework' ),
					'2' => esc_html__( '2', 'apollo13-framework' ),
					'3' => esc_html__( '3', 'apollo13-framework' ),
					'4' => esc_html__( '4', 'apollo13-framework' ),
					'5' => esc_html__( '5', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array( 'footer_switch', '=', 'on' ),
			),
			array(
				'id'       => 'footer_text',
				'type'     => 'textarea',
				'title'    => esc_html__( 'Content text', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'You can use HTML here.', 'apollo13-framework' ),
				'validate' => 'html',
				'default'  => '',
				'required' => array( 'footer_switch', '=', 'on' ),
			),
			array(
				'id'       => 'footer_socials',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Social icons', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
				'required' => array( 'footer_switch', '=', 'on' ),
			),
			array(
				'id'       => 'footer_socials_color',
				'type'     => 'select',
				'title'    => esc_html__( 'Social icons - color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => 'color',
				'options'  => array(
					'black'            => esc_html__( 'Black', 'apollo13-framework' ),
					'color'            => esc_html__( 'Color', 'apollo13-framework' ),
					'white'            => esc_html__( 'White', 'apollo13-framework' ),
					'semi-transparent' => esc_html__( 'Semi transparent', 'apollo13-framework' ),
				),
				'required' => array(
					array( 'footer_switch', '=', 'on' ),
					array( 'footer_socials', '=', 'on' ),
				)
			),
			array(
				'id'       => 'footer_socials_color_hover',
				'type'     => 'select',
				'title'    => esc_html__( 'Social icons - hover color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => 'semi-transparent',
				'options'  => array(
					'black'            => esc_html__( 'Black', 'apollo13-framework' ),
					'color'            => esc_html__( 'Color', 'apollo13-framework' ),
					'white'            => esc_html__( 'White', 'apollo13-framework' ),
					'semi-transparent' => esc_html__( 'Semi transparent', 'apollo13-framework' ),
				),
				'required' => array(
					array( 'footer_switch', '=', 'on' ),
					array( 'footer_socials', '=', 'on' ),
				)
			),
			array(
				'id'       => 'footer_content_width',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Content width', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'narrow' => esc_html__( 'Narrow', 'apollo13-framework' ),
					'full'   => esc_html__( 'Full width', 'apollo13-framework' ),
				),
				'default'  => 'narrow',
				'required' => array( 'footer_switch', '=', 'on' ),
			),
			array(
				'id'       => 'footer_content_style',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Content style', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'classic'  => esc_html__( 'Classic', 'apollo13-framework' ),
					'centered' => esc_html__( 'Centered', 'apollo13-framework' ),
				),
				'default'  => 'classic',
				'required' => array( 'footer_switch', '=', 'on' ),
			),
			array(
				'id'       => 'footer_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Background color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
				'required' => array( 'footer_switch', '=', 'on' ),
			),
			array(
				'id'       => 'footer_lower_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Lower background color', 'apollo13-framework' ),
				'desc'     => esc_html__( 'If you want to have different color in lower part then in footer widgets', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
				'required' => array( 'footer_switch', '=', 'on' ),
			),
			array(
				'id'       => 'footer_widgets_color',
				'title'    => esc_html__( 'Widgets colors', 'apollo13-framework' ),
				'desc'     => esc_html__( 'Depending on what background you have setup, choose proper option.', 'apollo13-framework' ),
				'default'  => 'dark-sidebar',
				'options'  => array(
					'dark-sidebar'  => esc_html__( 'On dark', 'apollo13-framework' ),
					'light-sidebar' => esc_html__( 'On light', 'apollo13-framework' ),
				),
				'type'     => 'button_set',
				'required' => array( 'footer_switch', '=', 'on' ),
			),
			array(
				'id'       => 'footer_separator',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Separator between widgets and footer content', 'apollo13-framework' ),
				'default'  => 'on',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'required' => array( 'footer_switch', '=', 'on' ),
			),
			array(
				'id'       => 'footer_separator_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Separator color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
				'required' => array( 'footer_switch', '=', 'on' ),
			),
			array(
				'id'            => 'footer_font_size',
				'type'          => 'slider',
				'title'         => esc_html__( 'Font size in lower part', 'apollo13-framework' ),
				'default'       => 10,
				'min'           => 10,
				'step'          => 1,
				'max'           => 30,
				'display_value' => 'text',
				'required'      => array( 'footer_switch', '=', 'on' ),
			),
			array(
				'id'            => 'footer_widgets_font_size',
				'type'          => 'slider',
				'title'         => esc_html__( 'Font size in widgets part', 'apollo13-framework' ),
				'default'       => 10,
				'min'           => 10,
				'step'          => 1,
				'max'           => 30,
				'display_value' => 'text',
				'required'      => array( 'footer_switch', '=', 'on' ),
			),
			array(
				'id'       => 'footer_font_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Font color in lower part', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Does not work for footer widgets.', 'apollo13-framework' ),
				'default'  => '',
				'required' => array( 'footer_switch', '=', 'on' ),
			),
			array(
				'id'       => 'footer_link_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Links color in lower part', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Does not work for footer widgets.', 'apollo13-framework' ),
				'default'  => '',
				'required' => array( 'footer_switch', '=', 'on' ),
			),
			array(
				'id'       => 'footer_hover_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Links hover color in lower part', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Does not work for footer widgets.', 'apollo13-framework' ),
				'default'  => '',
				'required' => array( 'footer_switch', '=', 'on' ),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Hidden sidebar', 'apollo13-framework' ),
		'desc'       => esc_html__( 'It is only active if it has some active widgets in it. When activated it displays opening button in header.', 'apollo13-framework' ),
		'id'         => 'subsection_hidden_sidebar',
		'icon'       => 'fa fa-columns',
		'subsection' => true,
		'fields'     => array(

			array(
				'id'       => 'hidden_sidebar_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Background color', 'apollo13-framework' ),
				'default'  => '',
				'subtitle' => '',
			),
			array(
				'id'            => 'hidden_sidebar_font_size',
				'type'          => 'slider',
				'title'         => esc_html__( 'Font size', 'apollo13-framework' ),
				'subtitle'      => '',
				'default'       => 10,
				'min'           => 5,
				'step'          => 1,
				'max'           => 30,
				'display_value' => 'text',
			),
			array(
				'id'       => 'hidden_sidebar_widgets_color',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Widgets colors', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Depending on what background you have setup, choose proper option.', 'apollo13-framework' ),
				'options'  => array(
					'dark-sidebar'  => esc_html__( 'On dark', 'apollo13-framework' ),
					'light-sidebar' => esc_html__( 'On light', 'apollo13-framework' ),
				),
				'default'  => 'dark-sidebar',
			),
			array(
				'id'       => 'hidden_sidebar_side',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Sidebar side', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'left'  => esc_html__( 'Left', 'apollo13-framework' ),
					'right' => esc_html__( 'Right', 'apollo13-framework' ),
				),
				'default'  => 'left',
			),
			array(
				'id'       => 'hidden_sidebar_effect',
				'type'     => 'select',
				'title'    => esc_html__( 'Sidebar effect', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'1' => esc_html__( 'Slide in on top', 'apollo13-framework' ),
					'2' => esc_html__( 'Reveal', 'apollo13-framework' ),
					'3' => esc_html__( 'Push', 'apollo13-framework' ),
					'4' => esc_html__( 'Slide along', 'apollo13-framework' ),
					'5' => esc_html__( 'Reverse slide out', 'apollo13-framework' ),
					'6' => esc_html__( 'Fall down', 'apollo13-framework' ),
				),
				'default'  => '2',
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Fonts settings', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_fonts_settings',
		'icon'       => 'fa fa-font',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'             => 'nav_menu_fonts',
				'type'           => 'typography',
				'title'          => esc_html__( 'Font for top nav menu and overlay menu:', 'apollo13-framework' ),
				'subtitle'       => '',
				'google'         => true,
				'word-spacing'   => true,
				'letter-spacing' => true,
				'all_styles'     => true,
				'color'          => false,
				'font-size'      => false,
				'font-weight'    => false,
				'font-style'     => false,
				'text-align'     => false,
				'line-height'    => false,
				'preview'        => array(
					'always_display' => true,
				),
				'default'        => array(
					'font-family'    => '-apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif',
					'word-spacing'   => 'normal',
					'letter-spacing' => 'normal'
				),
			),
			array(
				'id'             => 'titles_fonts',
				'type'           => 'typography',
				'title'          => esc_html__( 'Font for Titles/Headings:', 'apollo13-framework' ),
				'subtitle'       => '',
				'google'         => true,
				'word-spacing'   => true,
				'letter-spacing' => true,
				'all_styles'     => true,
				'color'          => false,
				'font-size'      => false,
				'font-weight'    => false,
				'font-style'     => false,
				'text-align'     => false,
				'line-height'    => false,
				'preview'        => array(
					'always_display' => true,
				),
				'default'        => array(
					'font-family'    => '-apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif',
					'word-spacing'   => 'normal',
					'letter-spacing' => 'normal'
				),
			),
			array(
				'id'             => 'normal_fonts',
				'type'           => 'typography',
				'title'          => esc_html__( 'Font for normal(content) text:', 'apollo13-framework' ),
				'subtitle'       => '',
				'google'         => true,
				'word-spacing'   => true,
				'letter-spacing' => true,
				'all_styles'     => true,
				'color'          => false,
				'font-size'      => false,
				'font-weight'    => false,
				'font-style'     => false,
				'text-align'     => false,
				'line-height'    => false,
				'preview'        => array(
					'always_display' => true,
				),
				'default'        => array(
					'font-family'    => '-apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif',
					'word-spacing'   => 'normal',
					'letter-spacing' => 'normal'
				),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Headings styles', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_heading_styles',
		'icon'       => 'fa fa-header',
		'subsection' => true,
		'fields'     => array(

			array(
				'id'       => 'headings_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
			),
			array(
				'id'       => 'headings_color_hover',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Hover color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
			),
			array(
				'id'       => 'headings_weight',
				'type'     => 'select',
				'title'    => esc_html__( 'Font weight', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'100'    => esc_html__( '100', 'apollo13-framework' ),
					'200'    => esc_html__( '200', 'apollo13-framework' ),
					'300'    => esc_html__( '300', 'apollo13-framework' ),
					'normal' => esc_html__( 'Normal 400', 'apollo13-framework' ),
					'500'    => esc_html__( '500', 'apollo13-framework' ),
					'600'    => esc_html__( '600', 'apollo13-framework' ),
					'bold'   => esc_html__( 'Bold 700', 'apollo13-framework' ),
					'800'    => esc_html__( '800', 'apollo13-framework' ),
					'900'    => esc_html__( '900', 'apollo13-framework' ),
				),
				'default'  => 'bold',
			),
			array(
				'id'       => 'headings_transform',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Text transform', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'none'      => esc_html__( 'None', 'apollo13-framework' ),
					'uppercase' => esc_html__( 'Uppercase', 'apollo13-framework' ),
				),
				'default'  => 'uppercase',
			),
			array(
				'id'            => 'page_title_font_size',
				'type'          => 'slider',
				'title'         => esc_html__( 'Font size for main titles', 'apollo13-framework' ),
				'subtitle'      => '',
				'default'       => 36,
				'min'           => 10,
				'step'          => 1,
				'max'           => 60,
				'display_value' => 'text',
			),
			array(
				'id'            => 'page_title_font_size_768',
				'type'          => 'slider',
				'title'         => esc_html__( 'Font size for main titles on mobile', 'apollo13-framework' ),
				'subtitle'      => esc_html__( 'It will be used on devices with less then 768 pixels width.', 'apollo13-framework' ),
				'default'       => 32,
				'min'           => 10,
				'step'          => 1,
				'max'           => 60,
				'display_value' => 'text',
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Content styles', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_content_styles',
		'icon'       => 'fa fa-align-left',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'content_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Background color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'It will change default white background color that is set under content on pages, blog, posts, works etc.', 'apollo13-framework' ),
				'default'  => array(
					'color' => '#ffffff',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'content_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Font color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => array(
					'color' => '#000000',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'content_link_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Links color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
			),
			array(
				'id'       => 'content_link_color_hover',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Links hover color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
			),
			array(
				'id'            => 'content_font_size',
				'type'          => 'slider',
				'title'         => esc_html__( 'Font size', 'apollo13-framework' ),
				'subtitle'      => '',
				'default'       => 16,
				'min'           => 10,
				'step'          => 1,
				'max'           => 30,
				'display_value' => 'text',
			),
			array(
				'id'       => 'first_paragraph',
				'type'     => 'button_set',
				'title'    => esc_html__( 'First paragraph mark out', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'If enabled it marks out(font size and color) first paragraph in many places(blog, post, page). It will do nothing when using builder.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'first_paragraph_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'First paragraph color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
				'required' => array( 'first_paragraph', '=', 'on' ),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Social settings', 'apollo13-framework' ),
		'desc'       => esc_html__( 'These icons will be used in various places across theme if you decide to activate them.', 'apollo13-framework' ),
		'id'         => 'section_social',
		'icon'       => 'fa fa-facebook-official',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'socials_variant',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Type of icons', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'squares'    => esc_html__( 'Squares', 'apollo13-framework' ),
					'circles'    => esc_html__( 'Circles', 'apollo13-framework' ),
					'icons-only' => esc_html__( 'Only icons', 'apollo13-framework' ),
				),
				'default'  => 'squares',
			),
			array(
				'id'       => 'social_services',
				'type'     => 'sortable',
				'title'    => esc_html__( 'Social services', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Drag and drop to change order of icons. Only filled links will show up as social icons.', 'apollo13-framework' ),
				'label'    => false,
				'options'  => $apollo13framework_a13->get_social_icons_list( 'names' ),
				'default'  => $apollo13framework_a13->get_social_icons_list( 'empty' )
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Lightbox settings', 'apollo13-framework' ),
		'desc'       => esc_html__( 'If you wish to use some other plugin/script for images and items, you can switch off default theme lightbox. If you are planning to use different lightbox script instead, then you will have to do some extra work with scripting to make it work in every theme place.', 'apollo13-framework' ),
		'id'         => 'subsection_lightbox',
		'icon'       => 'fa fa-picture-o',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'lightbox_vc_media_grid',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Use theme ligthbox for WPB Media Grid', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'If enabled it will use theme lightbox to display images for WPBakery Page Builder Media Grid element.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
				'required' => array( 'apollo_lightbox', '=', 'lightGallery' ),
			),
			array(
				'id'      => 'apollo_lightbox',
				'type'    => 'button_set',
				'title'   => esc_html__( 'Theme lightbox', 'apollo13-framework' ),
				'options' => array(
					'lightGallery' => esc_html__( 'Light Gallery', 'apollo13-framework' ),
					'off'          => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default' => 'lightGallery',
			),
			array(
				'title'    => esc_html__( 'lightGallery transition between images', 'apollo13-framework' ),
				'id'       => 'lg_lightbox_mode',
				'default'  => 'lg-slide',
				'type'     => 'select',
				'options'  => array(
					'lg-slide'                    => 'lg-slide',
					'lg-fade'                     => 'lg-fade',
					'lg-zoom-in'                  => 'lg-zoom-in',
					'lg-zoom-in-big'              => 'lg-zoom-in-big',
					'lg-zoom-out'                 => 'lg-zoom-out',
					'lg-zoom-out-big'             => 'lg-zoom-out-big',
					'lg-zoom-out-in'              => 'lg-zoom-out-in',
					'lg-zoom-in-out'              => 'lg-zoom-in-out',
					'lg-soft-zoom'                => 'lg-soft-zoom',
					'lg-scale-up'                 => 'lg-scale-up',
					'lg-slide-circular'           => 'lg-slide-circular',
					'lg-slide-circular-vertical'  => 'lg-slide-circular-vertical',
					'lg-slide-vertical'           => 'lg-slide-vertical',
					'lg-slide-vertical-growth'    => 'lg-slide-vertical-growth',
					'lg-slide-skew-only'          => 'lg-slide-skew-only',
					'lg-slide-skew-only-rev'      => 'lg-slide-skew-only-rev',
					'lg-slide-skew-only-y'        => 'lg-slide-skew-only-y',
					'lg-slide-skew-only-y-rev'    => 'lg-slide-skew-only-y-rev',
					'lg-slide-skew'               => 'lg-slide-skew',
					'lg-slide-skew-rev'           => 'lg-slide-skew-rev',
					'lg-slide-skew-cross'         => 'lg-slide-skew-cross',
					'lg-slide-skew-cross-rev'     => 'lg-slide-skew-cross-rev',
					'lg-slide-skew-ver'           => 'lg-slide-skew-ver',
					'lg-slide-skew-ver-rev'       => 'lg-slide-skew-ver-rev',
					'lg-slide-skew-ver-cross'     => 'lg-slide-skew-ver-cross',
					'lg-slide-skew-ver-cross-rev' => 'lg-slide-skew-ver-cross-rev',
					'lg-lollipop'                 => 'lg-lollipop',
					'lg-lollipop-rev'             => 'lg-lollipop-rev',
					'lg-rotate'                   => 'lg-rotate',
					'lg-rotate-rev'               => 'lg-rotate-rev',
					'lg-tube'                     => 'lg-tube',
				),
				'required' => array( 'apollo_lightbox', '=', 'lightGallery' ),
			),
			array(
				'title'    => esc_html__( 'lightGallery transition speed(in ms)', 'apollo13-framework' ),
				'id'       => 'lg_lightbox_speed',
				'default'  => '600',
				'unit'     => '',
				'min'      => 100,
				'max'      => 1000,
				'type'     => 'slider',
				'required' => array( 'apollo_lightbox', '=', 'lightGallery' ),
			),
			array(
				'title'    => esc_html__( 'lightGallery preload items', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'How many previous and next items should be preloaded. Number set means that X previous and X next items will be preloaded.', 'apollo13-framework' ),
				'id'       => 'lg_lightbox_preload',
				'default'  => '1',
				'unit'     => '',
				'min'      => 0,
				'max'      => 5,
				'type'     => 'slider',
				'required' => array( 'apollo_lightbox', '=', 'lightGallery' ),
			),
			array(
				'title'    => esc_html__( 'lightGallery delay for hiding gallery controls(in ms)', 'apollo13-framework' ),
				'id'       => 'lg_lightbox_hide_delay',
				'default'  => '2000',
				'unit'     => '',
				'min'      => 100,
				'max'      => 10000,
				'type'     => 'slider',
				'required' => array( 'apollo_lightbox', '=', 'lightGallery' ),
			),
			array(
				'id'       => 'lg_lightbox_share',
				'type'     => 'button_set',
				'title'    => esc_html__( 'lightGallery share', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'If enabled social icons will be available in top bar of lightbox.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
				'required' => array( 'apollo_lightbox', '=', 'lightGallery' ),
			),
			array(
				'id'       => 'lg_lightbox_controls',
				'type'     => 'button_set',
				'title'    => esc_html__( 'lightGallery arrow controls', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Arrows to next and previous slide.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
				'required' => array( 'apollo_lightbox', '=', 'lightGallery' ),
			),
			array(
				'id'       => 'lg_lightbox_download',
				'type'     => 'button_set',
				'title'    => esc_html__( 'lightGallery download control', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
				'required' => array( 'apollo_lightbox', '=', 'lightGallery' ),
			),
			array(
				'id'       => 'lg_lightbox_full_screen',
				'type'     => 'button_set',
				'title'    => esc_html__( 'lightGallery full screen control', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
				'required' => array( 'apollo_lightbox', '=', 'lightGallery' ),
			),
			array(
				'id'       => 'lg_lightbox_zoom',
				'type'     => 'button_set',
				'title'    => esc_html__( 'lightGallery zoom controls', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
				'required' => array( 'apollo_lightbox', '=', 'lightGallery' ),
			),
			array(
				'id'       => 'lg_lightbox_autoplay',
				'type'     => 'button_set',
				'title'    => esc_html__( 'lightGallery autoplay control', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
				'required' => array( 'apollo_lightbox', '=', 'lightGallery' ),
			),
			array(
				'id'       => 'lg_lightbox_autoplay_open',
				'type'     => 'button_set',
				'title'    => esc_html__( 'lightGallery autoplay on open', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
				'required' => array( 'apollo_lightbox', '=', 'lightGallery' ),
			),
			array(
				'id'       => 'lg_lightbox_progressbar',
				'type'     => 'button_set',
				'title'    => esc_html__( 'lightGallery show progress bar on autoplay', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
				'required' => array( 'apollo_lightbox', '=', 'lightGallery' ),
			),
			array(
				'title'    => esc_html__( 'lightGallery time(in ms) between each auto transition', 'apollo13-framework' ),
				'id'       => 'lg_lightbox_autoplay_pause',
				'default'  => '5000',
				'unit'     => '',
				'min'      => 500,
				'max'      => 10000,
				'type'     => 'slider',
				'required' => array( 'apollo_lightbox', '=', 'lightGallery' ),
			),
			array(
				'id'       => 'lg_lightbox_counter',
				'type'     => 'button_set',
				'title'    => esc_html__( 'lightGallery slides counter', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
				'required' => array( 'apollo_lightbox', '=', 'lightGallery' ),
			),
			array(
				'id'       => 'lg_lightbox_thumbnail',
				'type'     => 'button_set',
				'title'    => esc_html__( 'lightGallery thumbnails', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
				'required' => array( 'apollo_lightbox', '=', 'lightGallery' ),
			),
			array(
				'id'       => 'lg_lightbox_show_thumbs',
				'type'     => 'button_set',
				'title'    => esc_html__( 'lightGallery show thumbnails on open', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
				'required' => array( 'apollo_lightbox', '=', 'lightGallery' ),
			),
			array(
				'id'       => 'lg_lightbox_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'lightGallery main background color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
				'required' => array( 'apollo_lightbox', '=', 'lightGallery' ),
			),
			array(
				'id'       => 'lg_lightbox_elements_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'lightGallery semi transparent elements background color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Set it to transparent if you wish it wont cover your images at all.', 'apollo13-framework' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 0.45
				),
				'required' => array( 'apollo_lightbox', '=', 'lightGallery' ),
			),
			array(
				'title'    => esc_html__( 'lightGallery semi transparent elements color', 'apollo13-framework' ),
				'id'       => 'lg_lightbox_elements_color',
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'apollo_lightbox', '=', 'lightGallery' ),
			),
			array(
				'title'    => esc_html__( 'lightGallery semi transparent elements hover color', 'apollo13-framework' ),
				'id'       => 'lg_lightbox_elements_color_hover',
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'apollo_lightbox', '=', 'lightGallery' ),
			),
			array(
				'title'    => esc_html__( 'lightGallery semi transparent elements text color', 'apollo13-framework' ),
				'id'       => 'lg_lightbox_elements_text_color',
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'apollo_lightbox', '=', 'lightGallery' ),
			),
			array(
				'title'    => esc_html__( 'lightGallery thumbnails tray background color', 'apollo13-framework' ),
				'id'       => 'lg_lightbox_thumbs_bg_color',
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'apollo_lightbox', '=', 'lightGallery' ),
			),
			array(
				'title'    => esc_html__( 'lightGallery thumbs border color', 'apollo13-framework' ),
				'id'       => 'lg_lightbox_thumbs_border_bg_color',
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'apollo_lightbox', '=', 'lightGallery' ),
			),
			array(
				'title'    => esc_html__( 'lightGallery thumbs hover border color', 'apollo13-framework' ),
				'id'       => 'lg_lightbox_thumbs_border_bg_color_hover',
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'apollo_lightbox', '=', 'lightGallery' ),
			),

		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Widgets', 'apollo13-framework' ),
		'id'         => 'subsection_widgets',
		'icon'       => 'fa fa-puzzle-piece',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'widgets_top_margin',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Widgets top margin', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'It only affect widgets in Vertical sidebars.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'            => 'widget_title_font_size',
				'type'          => 'slider',
				'title'         => esc_html__( 'Font size for widget titles', 'apollo13-framework' ),
				'subtitle'      => '',
				'default'       => 14,
				'min'           => 10,
				'step'          => 1,
				'max'           => 60,
				'display_value' => 'text',
			),
			array(
				'id'            => 'widget_font_size',
				'type'          => 'slider',
				'title'         => esc_html__( 'Font size for content', 'apollo13-framework' ),
				'subtitle'      => esc_html__( 'It only affect widgets in Vertical sidebars.', 'apollo13-framework' ),
				'default'       => 12,
				'min'           => 5,
				'step'          => 1,
				'max'           => 30,
				'display_value' => 'text',
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'To top button', 'apollo13-framework' ),
		'id'         => 'subsection_to_top',
		'icon'       => 'fa fa-chevron-up',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'to_top_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Background color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => array(
					'color' => '#524F51',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'to_top_bg_hover_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Background hover color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => array(
					'color' => '#000',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'to_top_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Icon color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => array(
					'color' => '#cccccc',
					'alpha' => 1
				)
			),
			array(
				'id'       => 'to_top_hover_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Icon hover color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => array(
					'color' => '#ffffff',
					'alpha' => 1
				)
			),
			array(
				'id'            => 'to_top_font_size',
				'type'          => 'slider',
				'title'         => esc_html__( 'Icon size', 'apollo13-framework' ),
				'subtitle'      => '',
				'default'       => 13,
				'min'           => 10,
				'step'          => 1,
				'max'           => 60,
				'display_value' => 'text',
			),
			array(
				'id'       => 'to_top_icon',
				'title'    => esc_html__( 'Icon', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Select icon by clicking on input.', 'apollo13-framework' ),
				'default'  => 'chevron-up',
				'type'     => 'text',
				'class'    => 'a13-fa-icon',
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Buttons', 'apollo13-framework' ),
		'desc'       => esc_html__( 'You can change here colors of buttons that submit forms. For shop buttons, go to shop settings.', 'apollo13-framework' ),
		'id'         => 'subsection_buttons',
		'icon'       => 'fa fa-arrow-down',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'button_submit_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Background color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => array(
					'color' => '#524F51',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'button_submit_bg_hover_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Background hover color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => array(
					'color' => '#000',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'button_submit_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Text color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => array(
					'color' => '#cccccc',
					'alpha' => 1
				)
			),
			array(
				'id'       => 'button_submit_hover_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Text hover color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => array(
					'color' => '#ffffff',
					'alpha' => 1
				)
			),
			array(
				'id'            => 'button_submit_font_size',
				'type'          => 'slider',
				'title'         => esc_html__( 'Font size', 'apollo13-framework' ),
				'subtitle'      => '',
				'default'       => 13,
				'min'           => 10,
				'step'          => 1,
				'max'           => 60,
				'display_value' => 'text',
			),
			array(
				'id'       => 'button_submit_weight',
				'type'     => 'select',
				'title'    => esc_html__( 'Font weight', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'100'    => esc_html__( '100', 'apollo13-framework' ),
					'200'    => esc_html__( '200', 'apollo13-framework' ),
					'300'    => esc_html__( '300', 'apollo13-framework' ),
					'normal' => esc_html__( 'Normal 400', 'apollo13-framework' ),
					'500'    => esc_html__( '500', 'apollo13-framework' ),
					'600'    => esc_html__( '600', 'apollo13-framework' ),
					'bold'   => esc_html__( 'Bold 700', 'apollo13-framework' ),
					'800'    => esc_html__( '800', 'apollo13-framework' ),
					'900'    => esc_html__( '900', 'apollo13-framework' ),
				),
				'default'  => 'bold',
			),
			array(
				'id'       => 'button_submit_transform',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Text transform', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'none'      => esc_html__( 'None', 'apollo13-framework' ),
					'uppercase' => esc_html__( 'Uppercase', 'apollo13-framework' ),
				),
				'default'  => 'uppercase',
			),
			array(
				'id'             => 'button_submit_padding',
				'type'           => 'spacing',
				'mode'           => 'padding',
				'all'            => false,
				'top'            => false,
				'right'          => true,
				'bottom'         => false,
				'left'           => true,
				'units'          => array( 'px', 'em' ),
				'units_extended' => true,
				'display_units'  => true,
				'title'          => esc_html__( 'Padding', 'apollo13-framework' ),
				'desc'           => '',
				'default'        => array(
					'padding-left'  => '30px',
					'padding-right' => '30px',
					'units'         => 'px'
				),
			),
			array(
				'id'            => 'button_submit_radius',
				'type'          => 'slider',
				'title'         => esc_html__( 'Border radius(px)', 'apollo13-framework' ),
				'subtitle'      => esc_html__( 'AKA round corners', 'apollo13-framework' ),
				'default'       => 20,
				'min'           => 0,
				'step'          => 1,
				'max'           => 20,
				'display_value' => 'text',
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Flyout box', 'apollo13-framework' ),
		'desc'       => esc_html__( 'Small flyout box that will hover on side of screen, and can be openen with click.', 'apollo13-framework' ),
		'id'         => 'subsection_flyout_box',
		'icon'       => 'fa fa-info-circle',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'flyout_box',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Flyout box', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
			),
			array(
				'id'       => 'flyout_box_content',
				'type'     => 'textarea',
				'title'    => esc_html__( 'Content text', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'You can use HTML and shortcodes here.', 'apollo13-framework' ),
				'validate' => 'html',
				'default'  => '',
				'required' => array( 'flyout_box', '=', 'on' ),
			),
			array(
				'id'       => 'flyout_box_icon',
				'title'    => esc_html__( 'Opening icon', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Select icon by clicking on input.', 'apollo13-framework' ),
				'default'  => 'info-circle',
				'type'     => 'text',
				'class'    => 'a13-fa-icon',
				'required' => array(
					array( 'flyout_box', '=', 'on' ),
				)
			),
		)
	) );


//HEADER SETTINGS
	Redux::setSection( $opt_name, array(
		'title'           => esc_html__( 'Header settings', 'apollo13-framework' ),
		'desc'            => '',
		'id'              => 'section_header_settings',
		'icon'            => 'el el-magic',
		'priority'        => 2,
		'customizer_only' => $customizer_only,
		'fields'          => array()
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Type, variant, background', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_header_type',
		'icon'       => 'fa fa-cogs',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'header_type',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Type', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Please note that Vertical header will not be displayed in boxed layout.', 'apollo13-framework' ),
				'options'  => array(
					'vertical'   => esc_html__( 'Vertical', 'apollo13-framework' ),
					'horizontal' => esc_html__( 'Horizontal', 'apollo13-framework' ),
				),
				'default'  => 'horizontal',
			),
			array(
				'id'       => 'header_horizontal_sticky',
				'type'     => 'select',
				'title'    => esc_html__( 'Sticky version', 'apollo13-framework' ),
				'options'  => array(
					'default-sticky'     => esc_html__( 'Hiding when scrolling down', 'apollo13-framework' ),
					'sticky-no-hiding'   => esc_html__( 'No hiding sticky', 'apollo13-framework' ),
					'no-sticky no-fixed' => esc_html__( 'Disabled, show only default header(not fixed)', 'apollo13-framework' ),
					'no-sticky'          => esc_html__( 'Disabled, show only default header fixed', 'apollo13-framework' )
				),
				'default'  => 'default-sticky',
				'required' => array( 'header_type', '=', 'horizontal' ),
			),
			array(
				'id'       => 'header_side',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Side', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'left'  => esc_html__( 'Left', 'apollo13-framework' ),
					'right' => esc_html__( 'Right', 'apollo13-framework' ),
				),
				'default'  => 'left',
				'required' => array( 'header_type', '=', 'vertical' ),
			),
			array(
				'id'       => 'header_side_rtl',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Side on RTL languages', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'left'  => esc_html__( 'Left', 'apollo13-framework' ),
					'right' => esc_html__( 'Right', 'apollo13-framework' ),
				),
				'default'  => 'left',
				'required' => array( 'header_type', '=', 'vertical' ),
			),
			array(
				'id'       => 'header_horizontal_variant',
				'type'     => 'select',
				'title'    => esc_html__( 'Variant', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'one_line'               => esc_html__( 'One line, logo on side', 'apollo13-framework' ),
					'one_line_menu_centered' => esc_html__( 'One line, menu centered', 'apollo13-framework' ),
					'one_line_centered'      => esc_html__( 'One line, logo centered', 'apollo13-framework' ),
					'menu_below'             => esc_html__( 'Logo centered, menu below', 'apollo13-framework' ),
					'menu_above'             => esc_html__( 'Logo centered, menu above', 'apollo13-framework' ),
				),
				'default'  => 'one_line',
				'required' => array( 'header_type', '=', 'horizontal' ),
			),
			array(
				'id'       => 'header_color_variants',
				'type'     => 'select',
				'title'    => esc_html__( 'Header color variants', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'If you want to use theme header color variants(light and dark variants) or in sticky header variant, then enable this option. Some settings of header can then be overwritten in color & sticky variants.', 'apollo13-framework' ),
				'options'  => array(
					'on'     => esc_html__( 'Enabled', 'apollo13-framework' ),
					'sticky' => esc_html__( 'Enable only for sticky variant', 'apollo13-framework' ),
					'off'    => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
				'required' => array( 'header_type', '=', 'horizontal' ),
			),
			array(
				'id'       => 'header_content_width',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Content width', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'narrow' => esc_html__( 'Narrow', 'apollo13-framework' ),
					'full'   => esc_html__( 'Full width', 'apollo13-framework' ),
				),
				'default'  => 'full',
				'required' => array( 'header_type', '=', 'horizontal' ),
			),
			array(
				'id'       => 'header_content_width_narrow_bg',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Narrow also whole header', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
				'required' => array(
					array( 'header_type', '=', 'horizontal' ),
					array( 'header_content_width', '=', 'narrow' )
				),
			),
			array(
				'id'       => 'header_vertical_variant',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Variant', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'classic'        => esc_html__( 'Classic', 'apollo13-framework' ),
					'content_in_mid' => esc_html__( 'Vertically centered', 'apollo13-framework' ),
				),
				'default'  => 'classic',
				'required' => array( 'header_type', '=', 'vertical' ),
			),
			array(
				'id'       => 'header_center_content',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Center all content', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
				'required' => array( 'header_type', '=', 'vertical' ),
			),
			array(
				'id'       => 'header_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Background color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => array(
					'color' => '#ffffff',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'header_bg_hover_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Background hover color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Useful in special cases, like when you make transparent header.', 'apollo13-framework' ),
				'default'  => '',
			),
			array(
				'id'         => 'header_bg_image',
				'type'       => 'media',
				'title'      => esc_html__( 'Background image', 'apollo13-framework' ),
				'full_width' => false,
				'mode'       => 'image',
				'subtitle'   => esc_html__( 'It only works for big screens where header is vertical.', 'apollo13-framework' ),
				'required'   => array( 'header_type', '=', 'vertical' ),
			),
			array(
				'id'       => 'header_bg_image_fit',
				'type'     => 'select',
				'title'    => esc_html__( 'How to fit background image', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'cover'    => esc_html__( 'Cover', 'apollo13-framework' ),
					'contain'  => esc_html__( 'Contain', 'apollo13-framework' ),
					'fitV'     => esc_html__( 'Fit Vertically', 'apollo13-framework' ),
					'fitH'     => esc_html__( 'Fit Horizontally', 'apollo13-framework' ),
					'center'   => esc_html__( 'Just center', 'apollo13-framework' ),
					'repeat'   => esc_html__( 'Repeat', 'apollo13-framework' ),
					'repeat-x' => esc_html__( 'Repeat X', 'apollo13-framework' ),
					'repeat-y' => esc_html__( 'Repeat Y', 'apollo13-framework' ),
				),
				'default'  => 'cover',
				'required' => array( 'header_type', '=', 'vertical' ),
			),
			array(
				'id'       => 'header_menu_part_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Header menu part background color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Only for multi-line horizontal header variant', 'apollo13-framework' ),
				'default'  => '',
				'required' => array(
					array( 'header_type', '=', 'horizontal' ),
					array( 'header_horizontal_variant', '!=', 'one_line' ),
					array( 'header_horizontal_variant', '!=', 'one_line_menu_centered' ),
					array( 'header_horizontal_variant', '!=', 'one_line_centered' ),
				)
			),
			array(
				'id'      => 'header_mobile_menu_bg_color',
				'type'    => 'color_rgba',
				'title'   => esc_html__( 'Mobile menu background color', 'apollo13-framework' ),
				'default' => array(
					'color' => '#ffffff',
					'alpha' => 1
				),
			),
			array(
				'title'    => esc_html__( 'Bottom border', 'apollo13-framework' ),
				'id'       => 'header_border',
				'default'  => 'on',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'type'     => 'button_set',
				'required' => array( 'header_type', '=', 'horizontal' ),
			),
			array(
				'id'       => 'header_shadow',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Shadow', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'header_separators_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Separator and lines color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
				'required' => array( 'header_type', '=', 'horizontal' ),
			),
			array(
				'id'       => 'header_custom_sidebar',
				'type'     => 'select',
				'title'    => esc_html__( 'Custom sidebar', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => $header_sidebars,
				'default'  => 'off',
				'required' => array( 'header_type', '=', 'vertical' ),
			),
			array(
				'id'       => 'header_widgets_color',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Widgets colors', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Depending on what header background you have setup, choose proper option.', 'apollo13-framework' ),
				'options'  => array(
					'dark-sidebar'  => esc_html__( 'On dark', 'apollo13-framework' ),
					'light-sidebar' => esc_html__( 'On light', 'apollo13-framework' ),
				),
				'default'  => 'light-sidebar',
				'required' => array( 'header_type', '=', 'vertical' ),
			),
			array(
				'title'    => esc_html__( 'Social icons', 'apollo13-framework' ),
				'desc'     => '',
				'id'       => 'header_socials',
				'default'  => 'off',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'type'     => 'button_set',
				'required' => array( 'header_type', '=', 'horizontal' ),
			),
			array(
				'title'    => esc_html__( 'Social icons - color', 'apollo13-framework' ),
				'id'       => 'header_socials_color',
				'default'  => 'semi-transparent',
				'options'  => array(
					'black'            => esc_html__( 'Black', 'apollo13-framework' ),
					'color'            => esc_html__( 'Color', 'apollo13-framework' ),
					'white'            => esc_html__( 'White', 'apollo13-framework' ),
					'semi-transparent' => esc_html__( 'Semi transparent', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array(
					array( 'header_type', '=', 'horizontal' ),
					array( 'header_socials', '=', 'on' ),
				)
			),
			array(
				'title'    => esc_html__( 'Social icons - hover color', 'apollo13-framework' ),
				'id'       => 'header_socials_color_hover',
				'default'  => 'color',
				'options'  => array(
					'black'            => esc_html__( 'Black', 'apollo13-framework' ),
					'color'            => esc_html__( 'Color', 'apollo13-framework' ),
					'white'            => esc_html__( 'White', 'apollo13-framework' ),
					'semi-transparent' => esc_html__( 'Semi transparent', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array(
					array( 'header_type', '=', 'horizontal' ),
					array( 'header_socials', '=', 'on' ),
				)
			),
			array(
				'id'       => 'header_socials_display_on_mobile',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Social icons - display it on mobiles', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Should it be displayed on devices smaller then 600px width.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
				'required' => array(
					array( 'header_type', '=', 'horizontal' ),
					array( 'header_socials', '=', 'on' ),
				)
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Logo', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_logo',
		'icon'       => 'fa fa-picture-o',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'logo_from_variants',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Use logos from header variants', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'If you want to be able to change logo in header color variants(light and dark variants) or in sticky header variant, then enable this option.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
				'required' => array(
					array( 'header_type', '=', 'horizontal' ),
					array( 'header_color_variants', '!=', 'off' ),
				)
			),
			array(
				'id'       => 'logo_type',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Type', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'image' => esc_html__( 'Image', 'apollo13-framework' ),
					'text'  => esc_html__( 'Text', 'apollo13-framework' ),
				),
				'default'  => 'image',
			),
			array(
				'id'         => 'logo_image',
				'type'       => 'media',
				'title'      => esc_html__( 'Image', 'apollo13-framework' ),
				'subtitle'   => esc_html__( 'Upload an image for logo.', 'apollo13-framework' ),
				'full_width' => false,
				'mode'       => 'image',
				'default'    => '',
				'required'   => array( 'logo_type', '=', 'image' ),
			),
			array(
				'id'         => 'logo_image_high_dpi',
				'type'       => 'media',
				'title'      => esc_html__( 'Image for HIGH DPI screen', 'apollo13-framework' ),
				'subtitle'   => esc_html__( 'For example Retina(iPhone/iPad) screen is HIGH DPI.', 'apollo13-framework' ) . ' ' . esc_html__( 'Upload an image for logo.', 'apollo13-framework' ),
				'full_width' => false,
				'mode'       => 'image',
				'default'    => '',
				'required'   => array( 'logo_type', '=', 'image' ),
			),
			array(
				'id'       => 'logo_with_shield',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Use shield for logo', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Works only in horizontal header with variant "One line, logo centered". Gives shield background for your logo.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
				'required' => array(
					array( 'header_type', '=', 'horizontal' ),
					array( 'header_horizontal_variant', '=', 'one_line_centered' ),
				)
			),
			array(
				'id'       => 'logo_shield_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Shield color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => array(
					'color' => '#000000',
					'alpha' => 1
				),
				'required' => array(
					array( 'header_type', '=', 'horizontal' ),
					array( 'header_horizontal_variant', '=', 'one_line_centered' ),
					array( 'logo_with_shield', '=', 'on' ),
				)
			),
			array(
				'id'            => 'logo_shield_padding',
				'type'          => 'slider',
				'title'         => esc_html__( 'Shield area over logo', 'apollo13-framework' ),
				'subtitle'      => esc_html__( 'If your logo does not fit in shield try to increase this setting.', 'apollo13-framework' ),
				'default'       => 15,
				'min'           => 0,
				'step'          => 1,
				'max'           => 100,
				'display_value' => 'text',
				'required'      => array(
					array( 'header_type', '=', 'horizontal' ),
					array( 'header_horizontal_variant', '=', 'one_line_centered' ),
					array( 'logo_with_shield', '=', 'on' ),
				)
			),
			array(
				'id'            => 'logo_shield_hide',
				'type'          => 'slider',
				'title'         => esc_html__( 'How many % logo should fold up', 'apollo13-framework' ),
				'subtitle'      => esc_html__( 'When there is sticky header how many percent(%) of logo should hide by folding up.', 'apollo13-framework' ),
				'default'       => 50,
				'min'           => 0,
				'step'          => 1,
				'max'           => 150,
				'display_value' => 'text',
				'required'      => array(
					array( 'header_type', '=', 'horizontal' ),
					array( 'header_horizontal_variant', '=', 'one_line_centered' ),
					array( 'logo_with_shield', '=', 'on' ),
				)
			),
			array(
				'id'            => 'logo_shield_hide_mobile',
				'type'          => 'slider',
				'title'         => esc_html__( 'How many % logo should fold up on mobile', 'apollo13-framework' ),
				'subtitle'      => esc_html__( 'How many percent(%) of logo should hide by folding up when viewed on smaller(mobile) devices.', 'apollo13-framework' ),
				'default'       => 50,
				'min'           => 0,
				'step'          => 1,
				'max'           => 150,
				'display_value' => 'text',
				'required'      => array(
					array( 'header_type', '=', 'horizontal' ),
					array( 'header_horizontal_variant', '=', 'one_line_centered' ),
					array( 'logo_with_shield', '=', 'on' ),
				)
			),
			array(
				'id'            => 'logo_image_max_desktop_width',
				'type'          => 'slider',
				'title'         => esc_html__( 'Max width of logo on desktop', 'apollo13-framework' ),
				'subtitle'      => esc_html__( 'Works only in horizontal header. Max allowed width of logo on big screens.', 'apollo13-framework' ),
				'default'       => 200,
				'min'           => 25,
				'step'          => 1,
				'max'           => 400,
				'display_value' => 'text',
				'required'      => array(
					array( 'logo_type', '=', 'image' ),
					array( 'header_type', '=', 'horizontal' ),
				)
			),
			array(
				'id'            => 'logo_image_max_mobile_width',
				'type'          => 'slider',
				'title'         => esc_html__( 'Max width of logo on mobiles', 'apollo13-framework' ),
				'subtitle'      => esc_html__( 'Works only in horizontal header. Max allowed width of logo on mobile devices.', 'apollo13-framework' ),
				'default'       => 200,
				'min'           => 25,
				'step'          => 1,
				'max'           => 250,
				'display_value' => 'text',
				'required'      => array(
					array( 'logo_type', '=', 'image' ),
					array( 'header_type', '=', 'horizontal' ),
				)
			),
			array(
				'id'            => 'logo_image_height',
				'type'          => 'slider',
				'title'         => esc_html__( 'Height', 'apollo13-framework' ),
				'subtitle'      => esc_html__( 'Leave empty if you do not need anything fancy', 'apollo13-framework' ),
				'default'       => '',
				'min'           => 0,
				'step'          => 1,
				'max'           => 100,
				'display_value' => 'text',
				'required'      => array( 'logo_type', '=', 'image' ),
			),
			array(
				'id'            => 'logo_image_opacity',
				'type'          => 'slider',
				'title'         => esc_html__( 'Hover opacity', 'apollo13-framework' ),
				'subtitle'      => '',
				'default'       => 50,
				'min'           => 0,
				'step'          => 1,
				'max'           => 100,
				'display_value' => 'text',
				'required'      => array( 'logo_type', '=', 'image' ),
			),
			array(
				'id'       => 'logo_text',
				'type'     => 'text',
				'title'    => esc_html__( 'Text', 'apollo13-framework' ),
				'subtitle' => wp_kses( __( 'If you use more then one word in logo, then you might want to use <code>&amp;nbsp;</code> instead of white space, so words wont break in many lines.', 'apollo13-framework' ), $valid_tags ),
				'default'  => get_bloginfo( 'name' ),
				'required' => array( 'logo_type', '=', 'text' ),
			),
			array(
				'id'       => 'logo_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
				'required' => array( 'logo_type', '=', 'text' ),
			),
			array(
				'id'       => 'logo_color_hover',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Hover color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
				'required' => array( 'logo_type', '=', 'text' ),
			),
			array(
				'id'            => 'logo_font_size',
				'type'          => 'slider',
				'title'         => esc_html__( 'Font size', 'apollo13-framework' ),
				'subtitle'      => '',
				'default'       => 26,
				'min'           => 10,
				'step'          => 1,
				'max'           => 60,
				'display_value' => 'text',
				'required'      => array( 'logo_type', '=', 'text' ),
			),
			array(
				'id'       => 'logo_weight',
				'type'     => 'select',
				'title'    => esc_html__( 'Font weight', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'100'    => esc_html__( '100', 'apollo13-framework' ),
					'200'    => esc_html__( '200', 'apollo13-framework' ),
					'300'    => esc_html__( '300', 'apollo13-framework' ),
					'normal' => esc_html__( 'Normal 400', 'apollo13-framework' ),
					'500'    => esc_html__( '500', 'apollo13-framework' ),
					'600'    => esc_html__( '600', 'apollo13-framework' ),
					'bold'   => esc_html__( 'Bold 700', 'apollo13-framework' ),
					'800'    => esc_html__( '800', 'apollo13-framework' ),
					'900'    => esc_html__( '900', 'apollo13-framework' ),
				),
				'default'  => 'normal',
				'required' => array( 'logo_type', '=', 'text' ),
			),
			array(
				'id'             => 'logo_padding',
				'type'           => 'spacing',
				'mode'           => 'padding',
				'all'            => false,
				'top'            => true,
				'right'          => false,
				'bottom'         => true,
				'left'           => false,
				'units'          => array( 'px', 'em' ),
				'units_extended' => true,
				'display_units'  => true,
				'title'          => esc_html__( 'Padding', 'apollo13-framework' ),
				'desc'           => '',
				'default'        => array(
					'padding-top'    => '10px',
					'padding-bottom' => '10px',
				)
			),
			array(
				'id'             => 'logo_padding_mobile',
				'type'           => 'spacing',
				'mode'           => 'padding',
				'all'            => false,
				'top'            => true,
				'right'          => false,
				'bottom'         => true,
				'left'           => false,
				'units'          => array( 'px', 'em' ),
				'units_extended' => true,
				'display_units'  => true,
				'title'          => esc_html__( 'Padding for mobile header', 'apollo13-framework' ),
				'subtitle'       => esc_html__( 'This will show up on devices that has less then 1024px of width.', 'apollo13-framework' ),
				'desc'           => '',
				'default'        => array(
					'padding-top'    => '10px',
					'padding-bottom' => '10px',
				)
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Main Menu', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_header_menu',
		'icon'       => 'fa fa-bars',
		'subsection' => true,
		'fields'     => array(
			array(
				'title'   => esc_html__( 'Main Menu', 'apollo13-framework' ),
				'id'      => 'header_main_menu',
				'default' => 'on',
				'options' => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'type'    => 'button_set',
			),
			array(
				'title'    => esc_html__( 'Hover effect', 'apollo13-framework' ),
				'id'       => 'menu_hover_effect',
				'default'  => 'none',
				'type'     => 'select',
				'subtitle' => esc_html__( 'This works only for first level menu items. "Show icon effect" - if you use icons for your menu items then they will appear only when item is hovered or active. ', 'apollo13-framework' ),
				'options'  => $menu_effects,
				'required' => array( 'header_main_menu', '=', 'on' ),
			),
			array(
				'title'    => esc_html__( 'Close mobile menu after click', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'If enabled, mobile menu will close after clicking in menu link. This option is good for "one page" sites. In case of traditional sites, it is advised to disable it.', 'apollo13-framework' ),
				'id'       => 'menu_close_mobile_menu_on_click',
				'default'  => 'off',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'type'     => 'button_set',
				'required' => array( 'header_main_menu', '=', 'on' ),
			),
			array(
				'title'    => esc_html__( 'Allow mobile menu', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Works only in horizontal header. If you disable this then menu wont switch to mobile menu. You should consider disabling this option only if you have clean header with short menu.', 'apollo13-framework' ),
				'id'       => 'menu_allow_mobile_menu',
				'default'  => 'on',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'type'     => 'button_set',
				'required' => array(
					array( 'header_main_menu', '=', 'on' ),
					array( 'header_type', '=', 'horizontal' ),
				)
			),
			array(
				'id'            => 'menu_font_size',
				'type'          => 'slider',
				'title'         => esc_html__( 'Font size', 'apollo13-framework' ),
				'subtitle'      => '',
				'default'       => 14,
				'min'           => 10,
				'step'          => 1,
				'max'           => 30,
				'display_value' => 'text',
				'required'      => array( 'header_main_menu', '=', 'on' ),
			),
			array(
				'id'       => 'menu_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Links color', 'apollo13-framework' ),
				'subtitle' => '',
				'required' => array( 'header_main_menu', '=', 'on' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'menu_hover_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Links hover/active color', 'apollo13-framework' ),
				'subtitle' => '',
				'required' => array( 'header_main_menu', '=', 'on' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'menu_hover_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Links hover/active background color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Works only for first level menu items.', 'apollo13-framework' ),
				'required' => array( 'header_main_menu', '=', 'on' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 0
				),
			),
			array(
				'id'       => 'menu_weight',
				'type'     => 'select',
				'title'    => esc_html__( 'Font weight', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'100'    => esc_html__( '100', 'apollo13-framework' ),
					'200'    => esc_html__( '200', 'apollo13-framework' ),
					'300'    => esc_html__( '300', 'apollo13-framework' ),
					'normal' => esc_html__( 'Normal 400', 'apollo13-framework' ),
					'500'    => esc_html__( '500', 'apollo13-framework' ),
					'600'    => esc_html__( '600', 'apollo13-framework' ),
					'bold'   => esc_html__( 'Bold 700', 'apollo13-framework' ),
					'800'    => esc_html__( '800', 'apollo13-framework' ),
					'900'    => esc_html__( '900', 'apollo13-framework' ),
				),
				'default'  => 'normal',
				'required' => array( 'header_main_menu', '=', 'on' ),
			),
			array(
				'id'       => 'menu_transform',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Text transform', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'none'      => esc_html__( 'None', 'apollo13-framework' ),
					'uppercase' => esc_html__( 'Uppercase', 'apollo13-framework' ),
				),
				'default'  => 'uppercase',
				'required' => array( 'header_main_menu', '=', 'on' ),
			),
			array(
				'id'       => 'submenu_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( '"Flyout submenu"/megamenu background color', 'apollo13-framework' ),
				'subtitle' => '',
				'required' => array( 'header_main_menu', '=', 'on' ),
				'default'  => array(
					'color' => '#ffffff',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'submenu_separator_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Mega menu separator color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
				'required' => array( 'header_main_menu', '=', 'on' ),
			),
			array(
				'title'    => esc_html__( 'Submenu/mega menu open icons', 'apollo13-framework' ),
				'id'       => 'submenu_open_icons',
				'default'  => 'on',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'type'     => 'button_set',
				'required' => array( 'header_main_menu', '=', 'on' ),
			),
			array(
				'id'       => 'submenu_opener',
				'title'    => esc_html__( 'Submenu/mega menu opener icon', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Select icon by clicking on input.', 'apollo13-framework' ),
				'default'  => 'angle-down',
				'type'     => 'text',
				'class'    => 'a13-fa-icon',
				'required' => array(
					array( 'header_main_menu', '=', 'on' ),
					array( 'submenu_open_icons', '=', 'on' ),
				)

			),
			array(
				'id'       => 'submenu_closer',
				'title'    => esc_html__( 'Submenu/mega menu closer icon', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Select icon by clicking on input.', 'apollo13-framework' ),
				'default'  => 'angle-up',
				'type'     => 'text',
				'class'    => 'a13-fa-icon',
				'required' => array(
					array( 'header_main_menu', '=', 'on' ),
					array( 'submenu_open_icons', '=', 'on' ),
				)
			),
			array(
				'id'       => 'submenu_third_lvl_opener',
				'title'    => esc_html__( 'Submenu 3rd level opener icon', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Select icon by clicking on input.', 'apollo13-framework' ),
				'default'  => 'angle-right',
				'type'     => 'text',
				'class'    => 'a13-fa-icon',
				'required' => array(
					array( 'header_main_menu', '=', 'on' ),
					array( 'submenu_open_icons', '=', 'on' ),
				)

			),
			array(
				'id'       => 'submenu_third_lvl_closer',
				'title'    => esc_html__( 'Submenu 3rd level closer icon', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Select icon by clicking on input.', 'apollo13-framework' ),
				'default'  => 'angle-left',
				'type'     => 'text',
				'class'    => 'a13-fa-icon',
				'required' => array(
					array( 'header_main_menu', '=', 'on' ),
					array( 'submenu_open_icons', '=', 'on' ),
				)
			),
			array(
				'id'       => 'submenu_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Submenu/mega menu links color', 'apollo13-framework' ),
				'subtitle' => '',
				'required' => array( 'header_main_menu', '=', 'on' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'submenu_color_hover',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Submenu/mega menu links hover/active color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
				'required' => array( 'header_main_menu', '=', 'on' ),
			),
			array(
				'id'            => 'submenu_font_size',
				'type'          => 'slider',
				'title'         => esc_html__( 'Submenu/mega menu links font size', 'apollo13-framework' ),
				'subtitle'      => '',
				'default'       => 10,
				'min'           => 10,
				'step'          => 1,
				'max'           => 30,
				'display_value' => 'text',
				'required'      => array( 'header_main_menu', '=', 'on' ),
			),
			array(
				'id'       => 'submenu_weight',
				'type'     => 'select',
				'title'    => esc_html__( 'Submenu/mega menu font weight', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'100'    => esc_html__( '100', 'apollo13-framework' ),
					'200'    => esc_html__( '200', 'apollo13-framework' ),
					'300'    => esc_html__( '300', 'apollo13-framework' ),
					'normal' => esc_html__( 'Normal 400', 'apollo13-framework' ),
					'500'    => esc_html__( '500', 'apollo13-framework' ),
					'600'    => esc_html__( '600', 'apollo13-framework' ),
					'bold'   => esc_html__( 'Bold 700', 'apollo13-framework' ),
					'800'    => esc_html__( '800', 'apollo13-framework' ),
					'900'    => esc_html__( '900', 'apollo13-framework' ),
				),
				'default'  => 'bold',
				'required' => array( 'header_main_menu', '=', 'on' ),
			),
			array(
				'id'       => 'submenu_transform',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Submenu/mega menu text transform', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'none'      => esc_html__( 'None', 'apollo13-framework' ),
					'uppercase' => esc_html__( 'Uppercase', 'apollo13-framework' ),
				),
				'default'  => 'uppercase',
				'required' => array( 'header_main_menu', '=', 'on' ),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Top bar', 'apollo13-framework' ),
		'desc'       => esc_html__( 'Works only in horizontal header', 'apollo13-framework' ),
		'id'         => 'subsection_header_top_bar',
		'icon'       => 'fa fa-arrow-circle-o-up',
		'subsection' => true,
		'fields'     => array(
			array(
				'title'   => esc_html__( 'Top bar', 'apollo13-framework' ),
				'id'      => 'header_top_bar',
				'default' => 'on',
				'options' => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'type'    => 'button_set',
			),
			array(
				'id'       => 'header_top_bar_display_on_mobile',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Display it on mobiles', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Should it be displayed on devices smaller then 600px width.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
				'required' => array( 'header_top_bar', '=', 'on' ),
			),
			array(
				'id'       => 'top_bar_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Background color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => array(
					'color' => '#ffffff',
					'alpha' => 0
				),
				'required' => array( 'header_top_bar', '=', 'on' ),
			),
			array(
				'title'    => esc_html__( 'Bottom border', 'apollo13-framework' ),
				'id'       => 'top_bar_border',
				'default'  => 'on',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'type'     => 'button_set',
				'required' => array( 'header_top_bar', '=', 'on' ),
			),
			array(
				'title'    => esc_html__( 'Text color', 'apollo13-framework' ),
				'id'       => 'top_bar_text_color',
				'default'  => array(
					'color' => '#000000',
					'alpha' => 1
				),
				'type'     => 'color_rgba',
				'required' => array( 'header_top_bar', '=', 'on' ),
			),
			array(
				'title'    => esc_html__( 'Links color', 'apollo13-framework' ),
				'id'       => 'top_bar_link_color',
				'default'  => array(
					'color' => '#000000',
					'alpha' => 1
				),
				'type'     => 'color_rgba',
				'required' => array( 'header_top_bar', '=', 'on' ),
			),
			array(
				'title'    => esc_html__( 'Links hover/active color', 'apollo13-framework' ),
				'id'       => 'top_bar_link_color_hover',
				'default'  => array(
					'color' => '#000000',
					'alpha' => 1
				),
				'type'     => 'color_rgba',
				'required' => array( 'header_top_bar', '=', 'on' ),
			),
			array(
				'title'    => esc_html__( 'Text transform', 'apollo13-framework' ),
				'id'       => 'top_bar_text_transform',
				'default'  => 'none',
				'options'  => array(
					'none'      => esc_html__( 'None', 'apollo13-framework' ),
					'uppercase' => esc_html__( 'Uppercase', 'apollo13-framework' ),
				),
				'type'     => 'button_set',
				'required' => array( 'header_top_bar', '=', 'on' ),
			),
			array(
				'title'    => esc_html__( 'Message part', 'apollo13-framework' ),
				'id'       => 'top_bar_msg_part',
				'default'  => 'message',
				'options'  => array(
					'message' => esc_html__( 'Use message', 'apollo13-framework' ),
					'menu'    => sprintf( esc_html__( 'Use menu from "%s" position.', 'apollo13-framework' ), esc_html__( 'Alternative short top bar menu', 'apollo13-framework' ) ),
					'off'     => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array( 'header_top_bar', '=', 'on' ),
			),
			array(
				'title'    => esc_html__( 'Message text', 'apollo13-framework' ),
				'desc'     => esc_html__( 'You can use HTML here.', 'apollo13-framework' ),
				'id'       => 'top_bar_message',
				'default'  => '',
				'type'     => 'textarea',
				'required' => array(
					array( 'header_top_bar', '=', 'on' ),
					array( 'top_bar_msg_part', '=', 'message' ),
				)
			),
			array(
				'title'    => esc_html__( 'Social icons', 'apollo13-framework' ),
				'id'       => 'top_bar_socials',
				'default'  => 'on',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'type'     => 'button_set',
				'required' => array( 'header_top_bar', '=', 'on' ),
			),
			array(
				'title'    => esc_html__( 'Social icons - color', 'apollo13-framework' ),
				'id'       => 'top_bar_socials_color',
				'default'  => 'color',
				'options'  => array(
					'black'            => esc_html__( 'Black', 'apollo13-framework' ),
					'color'            => esc_html__( 'Color', 'apollo13-framework' ),
					'white'            => esc_html__( 'White', 'apollo13-framework' ),
					'semi-transparent' => esc_html__( 'Semi transparent', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array(
					array( 'header_top_bar', '=', 'on' ),
					array( 'top_bar_socials', '=', 'on' ),
				)
			),
			array(
				'title'    => esc_html__( 'Social icons - hover color', 'apollo13-framework' ),
				'id'       => 'top_bar_socials_color_hover',
				'default'  => 'color',
				'options'  => array(
					'black'            => esc_html__( 'Black', 'apollo13-framework' ),
					'color'            => esc_html__( 'Color', 'apollo13-framework' ),
					'white'            => esc_html__( 'White', 'apollo13-framework' ),
					'semi-transparent' => esc_html__( 'Semi transparent', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array(
					array( 'header_top_bar', '=', 'on' ),
					array( 'top_bar_socials', '=', 'on' ),
				)
			),
			array(
				'title'    => esc_html__( 'Language switcher', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Shows only if WPML plugin is enabled', 'apollo13-framework' ),
				'id'       => 'top_bar_lang_switcher',
				'default'  => 'off',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'type'     => 'button_set',
				'required' => array( 'header_top_bar', '=', 'on' ),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Variant light - overwrites', 'apollo13-framework' ),
		'desc'       => sprintf( wp_kses( __( 'It works only for horizontal header. These options are very useful when slider(Revolution Slider) is used, when page is scrolled to top and special params for slide are used. You can also use this header type in other situations. Read more in <a href="%s">documentation</a>.', 'apollo13-framework' ), $valid_tags ), esc_attr( $apollo13framework_a13->get_docs_link( 'header-color-variants' ) ) ),
		'id'         => 'subsection_header_light',
		'icon'       => 'fa fa-sun-o',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'         => 'header_light_logo_image',
				'type'       => 'media',
				'title'      => esc_html__( 'Logo image', 'apollo13-framework' ),
				'subtitle'   => esc_html__( 'Upload an image for logo.', 'apollo13-framework' ),
				'full_width' => false,
				'mode'       => 'image',
				'default'    => '',
				'required'   => array(
					array( 'logo_type', '=', 'image' ),
					array( 'logo_from_variants', '=', 'on' ),
				)
			),
			array(
				'id'         => 'header_light_logo_image_high_dpi',
				'type'       => 'media',
				'title'      => esc_html__( 'Logo image for HIGH DPI screen', 'apollo13-framework' ),
				'subtitle'   => esc_html__( 'For example Retina(iPhone/iPad) screen is HIGH DPI.', 'apollo13-framework' ) . ' ' . esc_html__( 'Upload an image for logo.', 'apollo13-framework' ),
				'full_width' => false,
				'mode'       => 'image',
				'default'    => '',
				'required'   => array(
					array( 'logo_type', '=', 'image' ),
					array( 'logo_from_variants', '=', 'on' ),
				)
			),
			array(
				'id'       => 'header_light_logo_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Logo color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
				'required' => array(
					array( 'logo_type', '=', 'text' ),
					array( 'logo_from_variants', '=', 'on' ),
				)
			),
			array(
				'id'       => 'header_light_logo_color_hover',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Logo hover color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
				'required' => array(
					array( 'logo_type', '=', 'text' ),
					array( 'logo_from_variants', '=', 'on' ),
				)
			),
			array(
				'id'       => 'header_light_menu_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Menu links color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
			),
			array(
				'id'       => 'header_light_menu_hover_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Menu links hover/active color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
			),
			array(
				'id'       => 'header_light_menu_hover_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Menu hover/active background color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Works only for main link', 'apollo13-framework' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 0
				),
			),
			array(
				'id'       => 'header_light_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Background color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
			),
			array(
				'id'       => 'header_light_menu_part_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Header menu part background color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Only for multi-line horizontal header variant', 'apollo13-framework' ),
				'default'  => '',
				'required' => array(
					array( 'header_type', '=', 'horizontal' ),
					array( 'header_horizontal_variant', '!=', 'one_line' ),
					array( 'header_horizontal_variant', '!=', 'one_line_menu_centered' ),
					array( 'header_horizontal_variant', '!=', 'one_line_centered' ),
				)
			),
			array(
				'id'      => 'header_light_mobile_menu_bg_color',
				'type'    => 'color_rgba',
				'title'   => esc_html__( 'Mobile menu background color', 'apollo13-framework' ),
				'default' => array(
					'color' => '#222222',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'header_light_shadow',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Shadow', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'header_light_separators_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Header separator and lines color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
			),
			array(
				'id'       => 'header_light_tools_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Tools icons - color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Basket, sidebar and search icons. It is also color for text of "Tools button".', 'apollo13-framework' ),
				'default'  => '',
			),
			array(
				'id'       => 'header_light_tools_color_hover',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Tools icons - hover and active color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Basket, sidebar and search icons. It is also color for text of "Tools button".', 'apollo13-framework' ),
				'default'  => '',
			),
			array(
				'id'       => 'header_light_button_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Tools button - background color', 'apollo13-framework' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 0
				),
				'required' => array( 'header_button', '!=', '' ),
			),
			array(
				'id'       => 'header_light_button_bg_color_hover',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Tools button - background hover color', 'apollo13-framework' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 0
				),
				'required' => array( 'header_button', '!=', '' ),
			),
			array(
				'id'       => 'header_light_button_border_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Tools button - border color', 'apollo13-framework' ),
				'default'  => array(
					'color' => '#ffffff',
					'alpha' => 0.3
				),
				'required' => array( 'header_button', '!=', '' ),
			),
			array(
				'id'       => 'header_light_button_border_color_hover',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Tools button - border hover color', 'apollo13-framework' ),
				'default'  => array(
					'color' => '#ffffff',
					'alpha' => 0.5
				),
				'required' => array( 'header_button', '!=', '' ),
			),
			array(
				'title'    => esc_html__( 'Social icons - color', 'apollo13-framework' ),
				'id'       => 'header_light_socials_color',
				'default'  => 'semi-transparent',
				'options'  => array(
					'black'            => esc_html__( 'Black', 'apollo13-framework' ),
					'color'            => esc_html__( 'Color', 'apollo13-framework' ),
					'white'            => esc_html__( 'White', 'apollo13-framework' ),
					'semi-transparent' => esc_html__( 'Semi transparent', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array(
					array( 'header_type', '=', 'horizontal' ),
					array( 'header_socials', '=', 'on' ),
				)
			),
			array(
				'title'    => esc_html__( 'Social icons - hover color', 'apollo13-framework' ),
				'id'       => 'header_light_socials_color_hover',
				'default'  => 'color',
				'options'  => array(
					'black'            => esc_html__( 'Black', 'apollo13-framework' ),
					'color'            => esc_html__( 'Color', 'apollo13-framework' ),
					'white'            => esc_html__( 'White', 'apollo13-framework' ),
					'semi-transparent' => esc_html__( 'Semi transparent', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array(
					array( 'header_type', '=', 'horizontal' ),
					array( 'header_socials', '=', 'on' ),
				)
			),
			array(
				'id'       => 'header_light_top_bar_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Top bar - Background color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => array(
					'color' => '#000000',
					'alpha' => 0.6
				),
				'required' => array( 'header_top_bar', '=', 'on' ),
			),
			array(
				'title'    => esc_html__( 'Top bar - Text color', 'apollo13-framework' ),
				'id'       => 'header_light_top_bar_text_color',
				'default'  => array(
					'color' => '#ffffff',
					'alpha' => 0.6
				),
				'type'     => 'color_rgba',
				'required' => array( 'header_top_bar', '=', 'on' ),
			),
			array(
				'title'    => esc_html__( 'Top bar - Links color', 'apollo13-framework' ),
				'id'       => 'header_light_top_bar_link_color',
				'default'  => array(
					'color' => '#ffffff',
					'alpha' => 0.7
				),
				'type'     => 'color_rgba',
				'required' => array( 'header_top_bar', '=', 'on' ),
			),
			array(
				'title'    => esc_html__( 'Top bar - Links hover/active color', 'apollo13-framework' ),
				'id'       => 'header_light_top_bar_link_color_hover',
				'default'  => array(
					'color' => '#ffffff',
					'alpha' => 1
				),
				'type'     => 'color_rgba',
				'required' => array( 'header_top_bar', '=', 'on' ),
			),
			array(
				'title'    => esc_html__( 'Top bar - Social icons color', 'apollo13-framework' ),
				'id'       => 'header_light_top_bar_socials_color',
				'default'  => 'white',
				'options'  => array(
					'black'            => esc_html__( 'Black', 'apollo13-framework' ),
					'color'            => esc_html__( 'Color', 'apollo13-framework' ),
					'white'            => esc_html__( 'White', 'apollo13-framework' ),
					'semi-transparent' => esc_html__( 'Semi transparent', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array(
					array( 'header_top_bar', '=', 'on' ),
					array( 'top_bar_socials', '=', 'on' ),
				)
			),
			array(
				'title'    => esc_html__( 'Top bar - Social icons hover color', 'apollo13-framework' ),
				'id'       => 'header_light_top_bar_socials_color_hover',
				'default'  => 'color',
				'options'  => array(
					'black'            => esc_html__( 'Black', 'apollo13-framework' ),
					'color'            => esc_html__( 'Color', 'apollo13-framework' ),
					'white'            => esc_html__( 'White', 'apollo13-framework' ),
					'semi-transparent' => esc_html__( 'Semi transparent', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array(
					array( 'header_top_bar', '=', 'on' ),
					array( 'top_bar_socials', '=', 'on' ),
				)
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Variant dark - overwrites', 'apollo13-framework' ),
		'desc'       => sprintf( wp_kses( __( 'It works only for horizontal header. These options are very useful when slider(Revolution Slider) is used, when page is scrolled to top and special params for slide are used. You can also use this header type in other situations. Read more in <a href="%s">documentation</a>.', 'apollo13-framework' ), $valid_tags ), esc_attr( $apollo13framework_a13->get_docs_link( 'header-color-variants' ) ) ),
		'id'         => 'subsection_header_dark',
		'icon'       => 'fa fa-moon-o',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'         => 'header_dark_logo_image',
				'type'       => 'media',
				'title'      => esc_html__( 'Logo image', 'apollo13-framework' ),
				'subtitle'   => esc_html__( 'Upload an image for logo.', 'apollo13-framework' ),
				'full_width' => false,
				'mode'       => 'image',
				'default'    => '',
				'required'   => array(
					array( 'logo_type', '=', 'image' ),
					array( 'logo_from_variants', '=', 'on' ),
				)
			),
			array(
				'id'         => 'header_dark_logo_image_high_dpi',
				'type'       => 'media',
				'title'      => esc_html__( 'Logo image for HIGH DPI screen', 'apollo13-framework' ),
				'subtitle'   => esc_html__( 'For example Retina(iPhone/iPad) screen is HIGH DPI.', 'apollo13-framework' ) . ' ' . esc_html__( 'Upload an image for logo.', 'apollo13-framework' ),
				'full_width' => false,
				'mode'       => 'image',
				'default'    => '',
				'required'   => array(
					array( 'logo_type', '=', 'image' ),
					array( 'logo_from_variants', '=', 'on' ),
				)
			),
			array(
				'id'       => 'header_dark_logo_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Logo color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
				'required' => array(
					array( 'logo_type', '=', 'text' ),
					array( 'logo_from_variants', '=', 'on' ),
				)
			),
			array(
				'id'       => 'header_dark_logo_color_hover',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Logo hover color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
				'required' => array(
					array( 'logo_type', '=', 'text' ),
					array( 'logo_from_variants', '=', 'on' ),
				)
			),
			array(
				'id'       => 'header_dark_menu_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Menu links color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
			),
			array(
				'id'       => 'header_dark_menu_hover_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Menu links hover/active color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
			),
			array(
				'id'       => 'header_dark_menu_hover_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Menu hover/active background color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Works only for main link', 'apollo13-framework' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 0
				),
			),
			array(
				'id'       => 'header_dark_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Background color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
			),
			array(
				'id'       => 'header_dark_menu_part_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Header menu part background color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Only for multi-line horizontal header variant', 'apollo13-framework' ),
				'default'  => '',
				'required' => array(
					array( 'header_type', '=', 'horizontal' ),
					array( 'header_horizontal_variant', '!=', 'one_line' ),
					array( 'header_horizontal_variant', '!=', 'one_line_menu_centered' ),
					array( 'header_horizontal_variant', '!=', 'one_line_centered' ),
				)
			),
			array(
				'id'      => 'header_dark_mobile_menu_bg_color',
				'type'    => 'color_rgba',
				'title'   => esc_html__( 'Mobile menu background color', 'apollo13-framework' ),
				'default' => array(
					'color' => '#ffffff',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'header_dark_shadow',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Shadow', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'header_dark_separators_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Header separator and lines color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
			),
			array(
				'id'       => 'header_dark_tools_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Tools icons - color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Basket, sidebar and search icons. It is also color for text of "Tools button".', 'apollo13-framework' ),
				'default'  => '',
			),
			array(
				'id'       => 'header_dark_tools_color_hover',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Tools icons - hover and active color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Basket, sidebar and search icons. It is also color for text of "Tools button".', 'apollo13-framework' ),
				'default'  => '',
			),
			array(
				'id'       => 'header_dark_button_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Tools button - background color', 'apollo13-framework' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 0
				),
				'required' => array( 'header_button', '!=', '' ),
			),
			array(
				'id'       => 'header_dark_button_bg_color_hover',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Tools button - background hover color', 'apollo13-framework' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 0
				),
				'required' => array( 'header_button', '!=', '' ),
			),
			array(
				'id'       => 'header_dark_button_border_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Tools button - border color', 'apollo13-framework' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 0.2
				),
				'required' => array( 'header_button', '!=', '' ),
			),
			array(
				'id'       => 'header_dark_button_border_color_hover',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Tools button - border hover color', 'apollo13-framework' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 0.4
				),
				'required' => array( 'header_button', '!=', '' ),
			),
			array(
				'title'    => esc_html__( 'Social icons - color', 'apollo13-framework' ),
				'id'       => 'header_dark_socials_color',
				'default'  => 'semi-transparent',
				'options'  => array(
					'black'            => esc_html__( 'Black', 'apollo13-framework' ),
					'color'            => esc_html__( 'Color', 'apollo13-framework' ),
					'white'            => esc_html__( 'White', 'apollo13-framework' ),
					'semi-transparent' => esc_html__( 'Semi transparent', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array(
					array( 'header_type', '=', 'horizontal' ),
					array( 'header_socials', '=', 'on' ),
				)
			),
			array(
				'title'    => esc_html__( 'Social icons - hover color', 'apollo13-framework' ),
				'id'       => 'header_dark_socials_color_hover',
				'default'  => 'color',
				'options'  => array(
					'black'            => esc_html__( 'Black', 'apollo13-framework' ),
					'color'            => esc_html__( 'Color', 'apollo13-framework' ),
					'white'            => esc_html__( 'White', 'apollo13-framework' ),
					'semi-transparent' => esc_html__( 'Semi transparent', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array(
					array( 'header_type', '=', 'horizontal' ),
					array( 'header_socials', '=', 'on' ),
				)
			),
			array(
				'id'       => 'header_dark_top_bar_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Top bar - Background color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => array(
					'color' => '#ffffff',
					'alpha' => 0
				),
				'required' => array( 'header_top_bar', '=', 'on' ),
			),
			array(
				'title'    => esc_html__( 'Top bar - Text color', 'apollo13-framework' ),
				'id'       => 'header_dark_top_bar_text_color',
				'default'  => array(
					'color' => '#000000',
					'alpha' => 0.5
				),
				'type'     => 'color_rgba',
				'required' => array( 'header_top_bar', '=', 'on' ),
			),
			array(
				'title'    => esc_html__( 'Top bar - Links color', 'apollo13-framework' ),
				'id'       => 'header_dark_top_bar_link_color',
				'default'  => array(
					'color' => '#000000',
					'alpha' => 0.6
				),
				'type'     => 'color_rgba',
				'required' => array( 'header_top_bar', '=', 'on' ),
			),
			array(
				'title'    => esc_html__( 'Top bar - Links hover/active color', 'apollo13-framework' ),
				'id'       => 'header_dark_top_bar_link_color_hover',
				'default'  => array(
					'color' => '#000000',
					'alpha' => 0.7
				),
				'type'     => 'color_rgba',
				'required' => array( 'header_top_bar', '=', 'on' ),
			),
			array(
				'title'    => esc_html__( 'Top bar - Social icons color', 'apollo13-framework' ),
				'id'       => 'header_dark_top_bar_socials_color',
				'default'  => 'semi-transparent',
				'options'  => array(
					'black'            => esc_html__( 'Black', 'apollo13-framework' ),
					'color'            => esc_html__( 'Color', 'apollo13-framework' ),
					'white'            => esc_html__( 'White', 'apollo13-framework' ),
					'semi-transparent' => esc_html__( 'Semi transparent', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array(
					array( 'header_top_bar', '=', 'on' ),
					array( 'top_bar_socials', '=', 'on' ),
				)
			),
			array(
				'title'    => esc_html__( 'Top bar - Social icons hover color', 'apollo13-framework' ),
				'id'       => 'header_dark_top_bar_socials_color_hover',
				'default'  => 'color',
				'options'  => array(
					'black'            => esc_html__( 'Black', 'apollo13-framework' ),
					'color'            => esc_html__( 'Color', 'apollo13-framework' ),
					'white'            => esc_html__( 'White', 'apollo13-framework' ),
					'semi-transparent' => esc_html__( 'Semi transparent', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array(
					array( 'header_top_bar', '=', 'on' ),
					array( 'top_bar_socials', '=', 'on' ),
				)
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Sticky header - overwrites', 'apollo13-framework' ),
		'desc'       => esc_html__( 'It works only for horizontal header. You can change here some options to change look of sticky header(if activated).', 'apollo13-framework' ),
		'id'         => 'subsection_header_sticky',
		'icon'       => 'fa fa-thumb-tack',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'         => 'header_sticky_logo_image',
				'type'       => 'media',
				'title'      => esc_html__( 'Logo image', 'apollo13-framework' ),
				'subtitle'   => esc_html__( 'Upload an image for logo.', 'apollo13-framework' ),
				'full_width' => false,
				'mode'       => 'image',
				'default'    => '',
				'required'   => array(
					array( 'logo_type', '=', 'image' ),
					array( 'logo_from_variants', '=', 'on' ),
				)
			),
			array(
				'id'         => 'header_sticky_logo_image_high_dpi',
				'type'       => 'media',
				'title'      => esc_html__( 'Logo image for HIGH DPI screen', 'apollo13-framework' ),
				'subtitle'   => esc_html__( 'For example Retina(iPhone/iPad) screen is HIGH DPI.', 'apollo13-framework' ) . ' ' . esc_html__( 'Upload an image for logo.', 'apollo13-framework' ),
				'full_width' => false,
				'mode'       => 'image',
				'default'    => '',
				'required'   => array(
					array( 'logo_type', '=', 'image' ),
					array( 'logo_from_variants', '=', 'on' ),
				)
			),
			array(
				'id'       => 'header_sticky_logo_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Logo color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
				'required' => array(
					array( 'logo_type', '=', 'text' ),
					array( 'logo_from_variants', '=', 'on' ),
				)
			),
			array(
				'id'       => 'header_sticky_logo_color_hover',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Logo hover color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
				'required' => array(
					array( 'logo_type', '=', 'text' ),
					array( 'logo_from_variants', '=', 'on' ),
				)
			),
			array(
				'id'       => 'header_sticky_menu_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Menu links color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
			),
			array(
				'id'       => 'header_sticky_menu_hover_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Menu links hover/active color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
			),
			array(
				'id'       => 'header_sticky_menu_hover_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Menu hover/active background color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Works only for main link', 'apollo13-framework' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 0
				),
			),
			array(
				'id'       => 'header_sticky_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Background color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
			),
			array(
				'id'       => 'header_sticky_menu_part_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Header menu part background color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Only for multi-line horizontal header variant', 'apollo13-framework' ),
				'default'  => '',
				'required' => array(
					array( 'header_type', '=', 'horizontal' ),
					array( 'header_horizontal_variant', '!=', 'one_line' ),
					array( 'header_horizontal_variant', '!=', 'one_line_menu_centered' ),
					array( 'header_horizontal_variant', '!=', 'one_line_centered' ),
				)
			),
			array(
				'id'      => 'header_sticky_mobile_menu_bg_color',
				'type'    => 'color_rgba',
				'title'   => esc_html__( 'Mobile menu background color', 'apollo13-framework' ),
				'default' => '#ffffff',
			),
			array(
				'id'       => 'header_sticky_shadow',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Shadow', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'header_sticky_separators_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Header separator and lines color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
			),
			array(
				'id'             => 'header_sticky_logo_padding',
				'type'           => 'spacing',
				'mode'           => 'padding',
				'all'            => false,
				'top'            => true,
				'right'          => false,
				'bottom'         => true,
				'left'           => false,
				'units'          => array( 'px', 'em' ),
				'units_extended' => true,
				'display_units'  => true,
				'title'          => esc_html__( 'Logo padding', 'apollo13-framework' ),
				'desc'           => '',
				'default'        => array(
					'padding-top'    => '10px',
					'padding-bottom' => '10px',
				)
			),
			array(
				'id'       => 'header_sticky_tools_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Tools icons - color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Basket, sidebar and search icons. It is also color for text of "Tools button".', 'apollo13-framework' ),
				'default'  => '',
			),
			array(
				'id'       => 'header_sticky_tools_color_hover',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Tools icons - hover and active color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Basket, sidebar and search icons. It is also color for text of "Tools button".', 'apollo13-framework' ),
				'default'  => '',
			),
			array(
				'id'       => 'header_sticky_button_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Tools button - background color', 'apollo13-framework' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 0
				),
				'required' => array( 'header_button', '!=', '' ),
			),
			array(
				'id'       => 'header_sticky_button_bg_color_hover',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Tools button - background hover color', 'apollo13-framework' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 0
				),
				'required' => array( 'header_button', '!=', '' ),
			),
			array(
				'id'       => 'header_sticky_button_border_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Tools button - border color', 'apollo13-framework' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 0.2
				),
				'required' => array( 'header_button', '!=', '' ),
			),
			array(
				'id'       => 'header_sticky_button_border_color_hover',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Tools button - border hover color', 'apollo13-framework' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 0.4
				),
				'required' => array( 'header_button', '!=', '' ),
			),
			array(
				'title'    => esc_html__( 'Social icons - color', 'apollo13-framework' ),
				'id'       => 'header_sticky_socials_color',
				'default'  => 'semi-transparent',
				'options'  => array(
					'black'            => esc_html__( 'Black', 'apollo13-framework' ),
					'color'            => esc_html__( 'Color', 'apollo13-framework' ),
					'white'            => esc_html__( 'White', 'apollo13-framework' ),
					'semi-transparent' => esc_html__( 'Semi transparent', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array(
					array( 'header_type', '=', 'horizontal' ),
					array( 'header_socials', '=', 'on' ),
				)
			),
			array(
				'title'    => esc_html__( 'Social icons - hover color', 'apollo13-framework' ),
				'id'       => 'header_sticky_socials_color_hover',
				'default'  => 'color',
				'options'  => array(
					'black'            => esc_html__( 'Black', 'apollo13-framework' ),
					'color'            => esc_html__( 'Color', 'apollo13-framework' ),
					'white'            => esc_html__( 'White', 'apollo13-framework' ),
					'semi-transparent' => esc_html__( 'Semi transparent', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array(
					array( 'header_type', '=', 'horizontal' ),
					array( 'header_socials', '=', 'on' ),
				)
			),
			array(
				'title'    => esc_html__( 'Top bar', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Works only if top bar is enabled in its own settings', 'apollo13-framework' ),
				'id'       => 'header_sticky_top_bar',
				'default'  => 'on',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'type'     => 'button_set',
				'required' => array( 'header_top_bar', '=', 'on' ),
			),
			array(
				'id'       => 'header_sticky_top_bar_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Top bar - Background color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => array(
					'color' => '#ffffff',
					'alpha' => 0
				),
				'required' => array(
					array( 'header_top_bar', '=', 'on' ),
					array( 'header_sticky_top_bar', '=', 'on' ),
				),
			),
			array(
				'title'    => esc_html__( 'Top bar - Text color', 'apollo13-framework' ),
				'id'       => 'header_sticky_top_bar_text_color',
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array(
					array( 'header_top_bar', '=', 'on' ),
					array( 'header_sticky_top_bar', '=', 'on' ),
				),
			),
			array(
				'title'    => esc_html__( 'Top bar - Links color', 'apollo13-framework' ),
				'id'       => 'header_sticky_top_bar_link_color',
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array(
					array( 'header_top_bar', '=', 'on' ),
					array( 'header_sticky_top_bar', '=', 'on' ),
				),
			),
			array(
				'title'    => esc_html__( 'Top bar - Links hover/active color', 'apollo13-framework' ),
				'id'       => 'header_sticky_top_bar_link_color_hover',
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array(
					array( 'header_top_bar', '=', 'on' ),
					array( 'header_sticky_top_bar', '=', 'on' ),
				),
			),
			array(
				'title'    => esc_html__( 'Top bar - Social icons color', 'apollo13-framework' ),
				'id'       => 'header_sticky_top_bar_socials_color',
				'default'  => 'color',
				'options'  => array(
					'black'            => esc_html__( 'Black', 'apollo13-framework' ),
					'color'            => esc_html__( 'Color', 'apollo13-framework' ),
					'white'            => esc_html__( 'White', 'apollo13-framework' ),
					'semi-transparent' => esc_html__( 'Semi transparent', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array(
					array( 'header_top_bar', '=', 'on' ),
					array( 'top_bar_socials', '=', 'on' ),
					array( 'header_sticky_top_bar', '=', 'on' ),
				)
			),
			array(
				'title'    => esc_html__( 'Top bar - Social icons hover color', 'apollo13-framework' ),
				'id'       => 'header_sticky_top_bar_socials_color_hover',
				'default'  => 'color',
				'options'  => array(
					'black'            => esc_html__( 'Black', 'apollo13-framework' ),
					'color'            => esc_html__( 'Color', 'apollo13-framework' ),
					'white'            => esc_html__( 'White', 'apollo13-framework' ),
					'semi-transparent' => esc_html__( 'Semi transparent', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array(
					array( 'header_top_bar', '=', 'on' ),
					array( 'top_bar_socials', '=', 'on' ),
					array( 'header_sticky_top_bar', '=', 'on' ),
				)
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Tools icons - general', 'apollo13-framework' ),
		'id'         => 'subsection_header_tools',
		'icon'       => 'fa fa-ellipsis-h',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'header_tools_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Tools icons - color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Basket, sidebar, menu and search icons. It is also color for text of "Tools button".', 'apollo13-framework' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'header_tools_color_hover',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Tools icons - hover and active color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Basket, sidebar, menu and search icons. It is also color for text of "Tools button".', 'apollo13-framework' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 1
				),
			),
			array(
				'id'      => 'header_search',
				'type'    => 'button_set',
				'title'   => esc_html__( 'Search', 'apollo13-framework' ),
				'options' => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default' => 'on',
			),
			array(
				'id'       => 'header_button',
				'type'     => 'text',
				'title'    => esc_html__( 'Text button - text', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'If left empty then button will not be displayed.', 'apollo13-framework' ),
				'default'  => '',
			),
			array(
				'id'       => 'header_button_link',
				'type'     => 'text',
				'title'    => esc_html__( 'Tools button - link', 'apollo13-framework' ),
				'default'  => '',
				'required' => array( 'header_button', '!=', '' ),
			),
			array(
				'id'       => 'header_button_link_target',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Tools button - open link in new tab', 'apollo13-framework' ),
				'subtitle' => sprintf( esc_html__( 'It will add %1$s to link', 'apollo13-framework' ), '<code>target="_blank"</code>' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
				'required' => array( 'header_button', '!=', '' ),
			),
			array(
				'id'            => 'header_button_font_size',
				'type'          => 'slider',
				'title'         => esc_html__( 'Tools button - font size', 'apollo13-framework' ),
				'subtitle'      => '',
				'default'       => '12',
				'min'           => 5,
				'step'          => 1,
				'max'           => 30,
				'display_value' => 'text',
				'required'      => array( 'header_button', '!=', '' ),
			),
			array(
				'id'       => 'header_button_weight',
				'type'     => 'select',
				'title'    => esc_html__( 'Tools button - font weight', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'100'    => esc_html__( '100', 'apollo13-framework' ),
					'200'    => esc_html__( '200', 'apollo13-framework' ),
					'300'    => esc_html__( '300', 'apollo13-framework' ),
					'normal' => esc_html__( 'Normal 400', 'apollo13-framework' ),
					'500'    => esc_html__( '500', 'apollo13-framework' ),
					'600'    => esc_html__( '600', 'apollo13-framework' ),
					'bold'   => esc_html__( 'Bold 700', 'apollo13-framework' ),
					'800'    => esc_html__( '800', 'apollo13-framework' ),
					'900'    => esc_html__( '900', 'apollo13-framework' ),
				),
				'default'  => 'normal',
				'required' => array( 'header_button', '!=', '' ),
			),
			array(
				'id'       => 'header_button_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Tools button - background color', 'apollo13-framework' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 0
				),
				'required' => array( 'header_button', '!=', '' ),
			),
			array(
				'id'       => 'header_button_bg_color_hover',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Tools button - background hover color', 'apollo13-framework' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 0
				),
				'required' => array( 'header_button', '!=', '' ),
			),
			array(
				'id'       => 'header_button_border_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Tools button - border color', 'apollo13-framework' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 0.2
				),
				'required' => array( 'header_button', '!=', '' ),
			),
			array(
				'id'       => 'header_button_border_color_hover',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Tools button - border hover color', 'apollo13-framework' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 0.4
				),
				'required' => array( 'header_button', '!=', '' ),
			),
			array(
				'id'       => 'header_button_display_on_mobile',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Tools button - display it on mobiles', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Should it be displayed on devices smaller then 600px width.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
				'required' => array( 'header_button', '!=', '' ),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Tools icons - individual icons', 'apollo13-framework' ),
		'id'         => 'subsection_header_tools_individual',
		'icon'       => 'fa fa-ellipsis-h',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'      => 'header_tools_mobile_menu_icon_type',
				'type'    => 'button_set',
				'title'   => esc_html__( 'Icon type for mobile menu button', 'apollo13-framework' ),
				'default' => 'default',
				'options' => array(
					'default'  => esc_html__( 'Default for framework', 'apollo13-framework' ),
					'animated' => esc_html__( 'Animated', 'apollo13-framework' ),
					'custom'   => esc_html__( 'Custom', 'apollo13-framework' ),
				),
			),
			array(
				'id'       => 'header_tools_mobile_menu_icon',
				'title'    => esc_html__( 'Icon type for mobile menu button', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Select icon by clicking on input.', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'text',
				'class'    => 'a13-fa-icon',
				'required' => array(
					array( 'header_tools_mobile_menu_icon_type', '=', 'custom' ),
				)
			),
			array(
				'id'            => 'header_tools_mobile_menu_icon_size',
				'type'          => 'slider',
				'title'         => esc_html__( 'Mobile menu button icon size', 'apollo13-framework' ),
				'subtitle'      => '',
				'default'       => 18,
				'min'           => 10,
				'step'          => 1,
				'max'           => 30,
				'display_value' => 'text',
				'required'      => array(
					array( 'header_tools_mobile_menu_icon_type', '!=', 'animated' ),
				)
			),
			array(
				'id'       => 'header_tools_mobile_menu_effect_active',
				'type'     => 'select',
				'title'    => esc_html__( 'Mobile menu button - when active show', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'x'  => esc_html__( 'X', 'apollo13-framework' ),
					'la' => esc_html__( 'Left arrow', 'apollo13-framework' ),
					'ra' => esc_html__( 'Right arrow', 'apollo13-framework' ),
				),
				'default'  => 'x',
				'required' => array(
					array( 'header_tools_mobile_menu_icon_type', '=', 'animated' ),
				)
			),
			array(
				'id'      => 'header_tools_basket_sidebar_icon_type',
				'type'    => 'button_set',
				'title'   => esc_html__( 'Icon type for basket menu button', 'apollo13-framework' ),
				'default' => 'default',
				'options' => array(
					'default' => esc_html__( 'Default for framework', 'apollo13-framework' ),
					'custom'  => esc_html__( 'Custom', 'apollo13-framework' ),
				),
			),
			array(
				'id'       => 'header_tools_basket_sidebar_icon',
				'title'    => esc_html__( 'Icon type for basket menu button', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Select icon by clicking on input.', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'text',
				'class'    => 'a13-fa-icon',
				'required' => array(
					array( 'header_tools_basket_sidebar_icon_type', '=', 'custom' ),
				)
			),
			array(
				'id'            => 'header_tools_basket_sidebar_icon_size',
				'type'          => 'slider',
				'title'         => esc_html__( 'Basket menu button icon size', 'apollo13-framework' ),
				'subtitle'      => '',
				'default'       => 16,
				'min'           => 10,
				'step'          => 1,
				'max'           => 30,
				'display_value' => 'text',
			),
			array(
				'id'      => 'header_tools_header_search_icon_type',
				'type'    => 'button_set',
				'title'   => esc_html__( 'Icon type for search button', 'apollo13-framework' ),
				'default' => 'default',
				'options' => array(
					'default' => esc_html__( 'Default for framework', 'apollo13-framework' ),
					'custom'  => esc_html__( 'Custom', 'apollo13-framework' ),
				),
			),
			array(
				'id'       => 'header_tools_header_search_icon',
				'title'    => esc_html__( 'Icon type for search button', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Select icon by clicking on input.', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'text',
				'class'    => 'a13-fa-icon',
				'required' => array(
					array( 'header_tools_header_search_icon_type', '=', 'custom' ),
				)
			),
			array(
				'id'            => 'header_tools_header_search_icon_size',
				'type'          => 'slider',
				'title'         => esc_html__( 'Search button icon size', 'apollo13-framework' ),
				'subtitle'      => '',
				'default'       => 16,
				'min'           => 10,
				'step'          => 1,
				'max'           => 30,
				'display_value' => 'text',
			),
			array(
				'id'      => 'header_tools_hidden_sidebar_icon_type',
				'type'    => 'button_set',
				'title'   => esc_html__( 'Icon type for hidden sidebar button', 'apollo13-framework' ),
				'default' => 'default',
				'options' => array(
					'default'  => esc_html__( 'Default for framework', 'apollo13-framework' ),
					'animated' => esc_html__( 'Animated', 'apollo13-framework' ),
					'custom'   => esc_html__( 'Custom', 'apollo13-framework' ),
				),
			),
			array(
				'id'       => 'header_tools_hidden_sidebar_icon',
				'title'    => esc_html__( 'Icon type for hidden sidebar button', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Select icon by clicking on input.', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'text',
				'class'    => 'a13-fa-icon',
				'required' => array(
					array( 'header_tools_hidden_sidebar_icon_type', '=', 'custom' ),
				)
			),
			array(
				'id'            => 'header_tools_hidden_sidebar_icon_size',
				'type'          => 'slider',
				'title'         => esc_html__( 'Hidden sidebar button icon size', 'apollo13-framework' ),
				'subtitle'      => '',
				'default'       => 16,
				'min'           => 10,
				'step'          => 1,
				'max'           => 30,
				'display_value' => 'text',
				'required'      => array(
					array( 'header_tools_hidden_sidebar_icon_type', '!=', 'animated' ),
				)
			),
			array(
				'id'       => 'header_tools_hidden_sidebar_effect_active',
				'type'     => 'select',
				'title'    => esc_html__( 'Hidden sidebar button - when active show', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'x'  => esc_html__( 'X', 'apollo13-framework' ),
					'la' => esc_html__( 'Left arrow', 'apollo13-framework' ),
					'ra' => esc_html__( 'Right arrow', 'apollo13-framework' ),
				),
				'default'  => 'x',
				'required' => array(
					array( 'header_tools_hidden_sidebar_icon_type', '=', 'animated' ),
				)
			),
			array(
				'id'      => 'header_tools_menu_overlay_icon_type',
				'type'    => 'button_set',
				'title'   => esc_html__( 'Icon type for menu overlay button', 'apollo13-framework' ),
				'default' => 'default',
				'options' => array(
					'default'  => esc_html__( 'Default for framework', 'apollo13-framework' ),
					'animated' => esc_html__( 'Animated', 'apollo13-framework' ),
					'custom'   => esc_html__( 'Custom', 'apollo13-framework' ),
				),
			),
			array(
				'id'       => 'header_tools_menu_overlay_icon',
				'title'    => esc_html__( 'Icon type for menu overlay button', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Select icon by clicking on input.', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'text',
				'class'    => 'a13-fa-icon',
				'required' => array(
					array( 'header_tools_menu_overlay_icon_type', '=', 'custom' ),
				)
			),
			array(
				'id'            => 'header_tools_menu_overlay_icon_size',
				'type'          => 'slider',
				'title'         => esc_html__( 'Menu overlay button icon size', 'apollo13-framework' ),
				'subtitle'      => '',
				'default'       => 16,
				'min'           => 10,
				'step'          => 1,
				'max'           => 30,
				'display_value' => 'text',
				'required'      => array(
					array( 'header_tools_menu_overlay_icon_type', '!=', 'animated' ),
				)
			),
			array(
				'id'       => 'header_tools_menu_overlay_effect_active',
				'type'     => 'select',
				'title'    => esc_html__( 'Menu overlay button - when active show', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'x'  => esc_html__( 'X', 'apollo13-framework' ),
					'la' => esc_html__( 'Left arrow', 'apollo13-framework' ),
					'ra' => esc_html__( 'Right arrow', 'apollo13-framework' ),
				),
				'default'  => 'x',
				'required' => array(
					array( 'header_tools_menu_overlay_icon_type', '=', 'animated' ),
				)
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Menu overlay', 'apollo13-framework' ),
		'id'         => 'subsection_header_menu_overlay',
		'desc'       => esc_html__( 'Enabling this will add button that displays full screen menu but only with main level of menu(no sub menus)', 'apollo13-framework' ),
		'icon'       => 'fa fa-align-center',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'      => 'header_menu_overlay',
				'type'    => 'button_set',
				'title'   => esc_html__( 'Menu overlay', 'apollo13-framework' ),
				'options' => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default' => 'off',
			),
			array(
				'id'       => 'header_menu_overlay_effect',
				'type'     => 'select',
				'title'    => esc_html__( 'Opening effect', 'apollo13-framework' ),
				'options'  => array(
					'default'     => esc_html__( 'Default', 'apollo13-framework' ),
					'slide-top'   => esc_html__( 'Slide from top', 'apollo13-framework' ),
					'slide-left'  => esc_html__( 'Slide from left', 'apollo13-framework' ),
					'slide-right' => esc_html__( 'Slide from right', 'apollo13-framework' ),
					'scale'       => esc_html__( 'Scale', 'apollo13-framework' ),
					'circle'      => esc_html__( 'Circle', 'apollo13-framework' ),
				),
				'default'  => 'default',
				'required' => array( 'header_menu_overlay', '=', 'on' ),
			),
			array(
				'id'       => 'header_menu_overlay_align',
				'type'     => 'select',
				'title'    => esc_html__( 'Text align', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'left'   => esc_html__( 'Texts to left', 'apollo13-framework' ),
					'center' => esc_html__( 'Texts to center', 'apollo13-framework' ),
					'right'  => esc_html__( 'Texts to right', 'apollo13-framework' ),
				),
				'default'  => 'center',
				'required' => array( 'header_menu_overlay', '=', 'on' ),
			),
			array(
				'id'       => 'header_menu_overlay_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Background color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
				'required' => array( 'header_menu_overlay', '=', 'on' ),
			),
			array(
				'id'       => 'header_menu_overlay_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Links color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '#aaaaaa',
				'required' => array( 'header_menu_overlay', '=', 'on' ),
			),
			array(
				'id'       => 'header_menu_overlay_color_hover',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Links hover color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '#ffffff',
				'required' => array( 'header_menu_overlay', '=', 'on' ),
			),
			array(
				'id'            => 'header_menu_overlay_font_size',
				'type'          => 'slider',
				'title'         => esc_html__( 'Font size', 'apollo13-framework' ),
				'subtitle'      => '',
				'default'       => 54,
				'min'           => 10,
				'step'          => 1,
				'max'           => 70,
				'display_value' => 'text',
				'required'      => array( 'header_menu_overlay', '=', 'on' ),
			),
			array(
				'id'       => 'header_menu_overlay_weight',
				'type'     => 'select',
				'title'    => esc_html__( 'Font weight', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'100'    => esc_html__( '100', 'apollo13-framework' ),
					'200'    => esc_html__( '200', 'apollo13-framework' ),
					'300'    => esc_html__( '300', 'apollo13-framework' ),
					'normal' => esc_html__( 'Normal 400', 'apollo13-framework' ),
					'500'    => esc_html__( '500', 'apollo13-framework' ),
					'600'    => esc_html__( '600', 'apollo13-framework' ),
					'bold'   => esc_html__( 'Bold 700', 'apollo13-framework' ),
					'800'    => esc_html__( '800', 'apollo13-framework' ),
					'900'    => esc_html__( '900', 'apollo13-framework' ),
				),
				'default'  => 'bold',
				'required' => array( 'header_menu_overlay', '=', 'on' ),
			),
			array(
				'id'       => 'header_menu_overlay_transform',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Text transform', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'none'      => esc_html__( 'None', 'apollo13-framework' ),
					'uppercase' => esc_html__( 'Uppercase', 'apollo13-framework' ),
				),
				'default'  => 'uppercase',
				'required' => array( 'header_menu_overlay', '=', 'on' ),
			),
		)
	) );

//BLOG SETTINGS
	Redux::setSection( $opt_name, array(
		'title'           => esc_html__( 'Blog settings', 'apollo13-framework' ),
		'desc'            => esc_html__( 'Posts list refers to Blog, Search and Archives pages', 'apollo13-framework' ),
		'id'              => 'section_blog_layout',
		'icon'            => 'fa fa-pencil',
		'priority'        => 4,
		'customizer_only' => $customizer_only,
		'fields'          => array()
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Background', 'apollo13-framework' ),
		'id'         => 'subsection_blog_bg',
		'desc'       => esc_html__( 'It will be default background for blog connected pages.', 'apollo13-framework' ),
		'icon'       => 'fa fa-picture-o',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'blog_custom_background',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Custom background', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
			),
			array(
				'id'         => 'blog_body_image',
				'type'       => 'media',
				'title'      => esc_html__( 'Background image', 'apollo13-framework' ),
				'full_width' => false,
				'mode'       => 'image',
				'subtitle'   => '',
				'required'   => array( 'blog_custom_background', '=', 'on' ),
			),
			array(
				'id'       => 'blog_body_image_fit',
				'type'     => 'select',
				'title'    => esc_html__( 'How to fit background image', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'cover'    => esc_html__( 'Cover', 'apollo13-framework' ),
					'contain'  => esc_html__( 'Contain', 'apollo13-framework' ),
					'fitV'     => esc_html__( 'Fit Vertically', 'apollo13-framework' ),
					'fitH'     => esc_html__( 'Fit Horizontally', 'apollo13-framework' ),
					'center'   => esc_html__( 'Just center', 'apollo13-framework' ),
					'repeat'   => esc_html__( 'Repeat', 'apollo13-framework' ),
					'repeat-x' => esc_html__( 'Repeat X', 'apollo13-framework' ),
					'repeat-y' => esc_html__( 'Repeat Y', 'apollo13-framework' ),
				),
				'default'  => 'cover',
				'required' => array( 'blog_custom_background', '=', 'on' ),
			),
			array(
				'id'       => 'blog_body_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Background color', 'apollo13-framework' ),
				'subtitle' => '',
				'required' => array( 'blog_custom_background', '=', 'on' ),
				'default'  => '',
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Posts list', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_blog',
		'icon'       => 'fa fa-list',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'          => 'blog_content_under_header',
				'title'       => esc_html__( 'Hide content under header', 'apollo13-framework' ),
				'description' => esc_html__( 'Only valid when using horizontal header.', 'apollo13-framework' ),
				'default'     => 'off',
				'type'        => 'select',
				'options'     => array(
					'content' => esc_html__( 'Yes hide content', 'apollo13-framework' ),
					'title'   => esc_html__( 'Yes hide content and add top padding to outside title bar.', 'apollo13-framework' ),
					'off'     => esc_html__( 'Turn it off', 'apollo13-framework' ),
				),
				'required'    => array( 'header_type', '=', 'horizontal' ),
			),
			array(
				'id'          => 'blog_horizontal_header_color_variant',
				'title'       => esc_html__( 'Header color variant', 'apollo13-framework' ),
				'description' => esc_html__( 'Only valid when using horizontal header.', 'apollo13-framework' ),
				'default'     => 'normal',
				'type'        => 'select',
				'options'     => array(
					'normal' => esc_html__( 'Normal', 'apollo13-framework' ),
					'light'  => esc_html__( 'Light', 'apollo13-framework' ),
					'dark'   => esc_html__( 'Dark', 'apollo13-framework' ),
				),
				'required'    => array( 'header_type', '=', 'horizontal' ),
			),
			array(
				'id'       => 'blog_content_layout',
				'type'     => 'select',
				'title'    => esc_html__( 'Content Layout', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'center'        => esc_html__( 'Center fixed width', 'apollo13-framework' ),
					'left'          => esc_html__( 'Left fixed width', 'apollo13-framework' ),
					'left_padding'  => esc_html__( 'Left fixed width + padding', 'apollo13-framework' ),
					'right'         => esc_html__( 'Right fixed width', 'apollo13-framework' ),
					'right_padding' => esc_html__( 'Right fixed width + padding', 'apollo13-framework' ),
					'full_fixed'    => esc_html__( 'Full width + fixed content', 'apollo13-framework' ),
					'full_padding'  => esc_html__( 'Full width + padding', 'apollo13-framework' ),
					'full'          => esc_html__( 'Full width', 'apollo13-framework' ),
				),
				'default'  => 'center',
			),
			array(
				'id'       => 'blog_content_padding',
				'type'     => 'select',
				'title'    => esc_html__( 'Content top/bottom padding', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'both'   => esc_html__( 'Both on', 'apollo13-framework' ),
					'top'    => esc_html__( 'Only top', 'apollo13-framework' ),
					'bottom' => esc_html__( 'Only bottom', 'apollo13-framework' ),
					'off'    => esc_html__( 'Both off', 'apollo13-framework' ),
				),
				'default'  => 'off',
			),
			array(
				'id'       => 'blog_sidebar',
				'type'     => 'select',
				'title'    => esc_html__( 'Sidebar', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'left-sidebar'  => esc_html__( 'Left', 'apollo13-framework' ),
					'right-sidebar' => esc_html__( 'Right', 'apollo13-framework' ),
					'off'           => esc_html__( 'Off', 'apollo13-framework' ),
				),
				'default'  => 'off',
			),
			array(
				'id'       => 'blog_post_look',
				'type'     => 'select',
				'title'    => esc_html__( 'Post look', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'vertical_no_padding' => esc_html__( 'Vertical no padding', 'apollo13-framework' ),
					'vertical_padding'    => esc_html__( 'Vertical with padding', 'apollo13-framework' ),
					'vertical_centered'   => esc_html__( 'Vertical centered', 'apollo13-framework' ),
					'horizontal'          => esc_html__( 'Horizontal', 'apollo13-framework' ),
				),
				'default'  => 'vertical_padding',
			),
			array(
				'id'       => 'blog_layout_mode',
				'type'     => 'button_set',
				'title'    => esc_html__( 'How to place items in rows', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'It your items has various heights you may want to start each row of items from new line instead of masonry style.', 'apollo13-framework' ),
				'options'  => array(
					'packery' => esc_html__( 'Masonry', 'apollo13-framework' ),
					'fitRows' => esc_html__( 'Each row from new line', 'apollo13-framework' ),
				),
				'default'  => 'packery',
			),
			array(
				'id'            => 'blog_brick_columns',
				'type'          => 'slider',
				'title'         => esc_html__( 'Bricks columns', 'apollo13-framework' ),
				'subtitle'      => esc_html__( 'It only affects wider screen resolutions.', 'apollo13-framework' ),
				'default'       => 2,
				'min'           => 1,
				'step'          => 1,
				'max'           => 4,
				'display_value' => 'text',
				'required'      => array( 'blog_post_look', '!=', 'horizontal' ),
			),
			array(
				'id'            => 'blog_bricks_max_width',
				'type'          => 'slider',
				'title'         => esc_html__( 'Max width of bricks content.', 'apollo13-framework' ),
				'subtitle'      => esc_html__( 'Depending on actual screen width and content style used for blog page, available space for bricks might be smaller, but newer greater then this number.', 'apollo13-framework' ),
				'default'       => 1920,
				'min'           => 200,
				'step'          => 1,
				'max'           => 2500,
				'display_value' => 'text',
				'required'      => array( 'blog_post_look', '!=', 'horizontal' ),
			),
			array(
				'id'            => 'blog_brick_margin',
				'type'          => 'slider',
				'title'         => esc_html__( 'Brick margin', 'apollo13-framework' ),
				'subtitle'      => '',
				'default'       => 10,
				'min'           => 0,
				'step'          => 1,
				'max'           => 100,
				'display_value' => 'text',
			),
			array(
				'id'       => 'blog_lazy_load',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Lazy load', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'blog_lazy_load_mode',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Lazy load mode', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'button' => esc_html__( 'By clicking button', 'apollo13-framework' ),
					'auto'   => esc_html__( 'On scroll', 'apollo13-framework' ),
				),
				'default'  => 'button',
				'required' => array( 'blog_lazy_load', '=', 'on' ),
			),
			array(
				'id'       => 'blog_excerpt_type',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Type of post excerpts', 'apollo13-framework' ),
				'subtitle' => wp_kses( __(
					'In Manual mode excerpts are used only if you add more tag (&lt;!--more--&gt;).<br /> In Automatic mode if you will not provide more tag or explicit excerpt, content of post will be cut automatic.<br /> This setting only concerns blog list, archive list, search results.', 'apollo13-framework' ), $valid_tags ),
				'options'  => array(
					'auto'   => esc_html__( 'Automatic', 'apollo13-framework' ),
					'manual' => esc_html__( 'Manual', 'apollo13-framework' ),
				),
				'default'  => 'auto',
			),
			array(
				'id'            => 'blog_excerpt_length',
				'type'          => 'slider',
				'title'         => esc_html__( 'Number of words to cut post', 'apollo13-framework' ),
				'subtitle'      => esc_html__( 'After this many words post will be cut in automatic mode.', 'apollo13-framework' ),
				'default'       => 40,
				'min'           => 3,
				'step'          => 1,
				'max'           => 200,
				'display_value' => 'text',
				'required'      => array( 'blog_excerpt_type', '=', 'auto' ),
			),
			array(
				'id'       => 'blog_media',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Display post Media', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'You can set to not display post media(featured image/video/slider) inside of post brick.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'blog_videos',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Display of posts video', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'You can set to display videos as featured media on posts list. This can speed up loading of page with many posts(blog, archive, search results) when videos are used.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'blog_date',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Post meta: Date of publish or last update', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'You can\'t use both dates, cause then Search Engine will not know which date is correct.', 'apollo13-framework' ),
				'options'  => array(
					'on'      => esc_html__( 'Published', 'apollo13-framework' ),
					'updated' => esc_html__( 'Updated', 'apollo13-framework' ),
					'off'     => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'      => 'blog_author',
				'type'    => 'button_set',
				'title'   => esc_html__( 'Post meta: Author', 'apollo13-framework' ),
				'options' => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default' => 'on',
			),
			array(
				'id'      => 'blog_comments',
				'type'    => 'button_set',
				'title'   => esc_html__( 'Post meta: Comments number', 'apollo13-framework' ),
				'options' => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default' => 'on',
			),
			array(
				'id'      => 'blog_cats',
				'type'    => 'button_set',
				'title'   => esc_html__( 'Post meta: Categories', 'apollo13-framework' ),
				'options' => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default' => 'on',
			),
			array(
				'id'      => 'blog_tags',
				'type'    => 'button_set',
				'title'   => esc_html__( 'Post meta: Tags', 'apollo13-framework' ),
				'options' => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default' => 'off',
			),
			array(
				'id'       => 'blog_header_custom_sidebar',
				'type'     => 'select',
				'title'    => esc_html__( 'Custom header sidebar', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Works only with vertical header.', 'apollo13-framework' ),
				'options'  => $header_sidebars_off_global,
				'default'  => 'off',
				'required' => array( 'header_type', '=', 'vertical' ),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Posts list - title bar', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_blog_title',
		'icon'       => 'fa fa-text-width',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'blog_title',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Title', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'blog_title_bar_variant',
				'title'    => esc_html__( 'Title bar variant', 'apollo13-framework' ),
				'type'     => 'button_set',
				'default'  => 'centered',
				'options'  => array(
					'classic'  => esc_html__( 'Classic(to side)', 'apollo13-framework' ),
					'centered' => esc_html__( 'Centered', 'apollo13-framework' ),
				),
				'required' => array( 'blog_title', '=', 'on' ),
			),
			array(
				'id'       => 'blog_title_bar_width',
				'title'    => esc_html__( 'Title bar width', 'apollo13-framework' ),
				'type'     => 'button_set',
				'default'  => 'full',
				'options'  => array(
					'full'  => esc_html__( 'Full', 'apollo13-framework' ),
					'boxed' => esc_html__( 'Boxed', 'apollo13-framework' ),
				),
				'required' => array( 'blog_title', '=', 'on' ),
			),
			array(
				'id'         => 'blog_title_bar_image',
				'title'      => esc_html__( 'Title bar custom background image', 'apollo13-framework' ),
				'default'    => '',
				'type'       => 'media',
				'full_width' => false,
				'mode'       => 'image',
				'required'   => array( 'blog_title', '=', 'on' ),
			),
			array(
				'id'       => 'blog_title_bar_image_fit',
				'title'    => esc_html__( 'How to fit background image', 'apollo13-framework' ),
				'default'  => 'repeat',
				'options'  => array(
					'cover'    => esc_html__( 'Cover', 'apollo13-framework' ),
					'contain'  => esc_html__( 'Contain', 'apollo13-framework' ),
					'fitV'     => esc_html__( 'Fit Vertically', 'apollo13-framework' ),
					'fitH'     => esc_html__( 'Fit Horizontally', 'apollo13-framework' ),
					'center'   => esc_html__( 'Just center', 'apollo13-framework' ),
					'repeat'   => esc_html__( 'Repeat', 'apollo13-framework' ),
					'repeat-x' => esc_html__( 'Repeat X', 'apollo13-framework' ),
					'repeat-y' => esc_html__( 'Repeat Y', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array( 'blog_title', '=', 'on' ),
			),
			array(
				'id'       => 'blog_title_bar_parallax',
				'title'    => esc_html__( 'Title bar parallax?', 'apollo13-framework' ),
				'default'  => 'off',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'type'     => 'button_set',
				'required' => array( 'blog_title', '=', 'on' ),
			),
			array(
				'id'       => 'blog_title_bar_parallax_type',
				'title'    => esc_html__( 'Parallax type', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'It defines how image will scroll in background while page is scrolled down.', 'apollo13-framework' ),
				'default'  => 'tb',
				'options'  => array(
					"tb"   => esc_html__( 'top to bottom', 'apollo13-framework' ),
					"bt"   => esc_html__( 'bottom to top', 'apollo13-framework' ),
					"lr"   => esc_html__( 'left to right', 'apollo13-framework' ),
					"rl"   => esc_html__( 'right to left', 'apollo13-framework' ),
					"tlbr" => esc_html__( 'top-left to bottom-right', 'apollo13-framework' ),
					"trbl" => esc_html__( 'top-right to bottom-left', 'apollo13-framework' ),
					"bltr" => esc_html__( 'bottom-left to top-right', 'apollo13-framework' ),
					"brtl" => esc_html__( 'bottom-right to top-left', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array(
					array( 'blog_title', '=', 'on' ),
					array( 'blog_title_bar_parallax', '=', 'on' ),
				)
			),
			array(
				'id'         => 'blog_title_bar_parallax_speed',
				'title'      => esc_html__( 'Parallax speed', 'apollo13-framework' ),
				'subtitle'   => esc_html__( 'It will be only used for background that are repeated. If background is set to not repeat this value will be ignored.', 'apollo13-framework' ),
				'default'    => '1.00',
				'type'       => 'slider',
				'min'        => 0,
				'max'        => 1,
				'step'       => 0.01,
				'resolution' => 0.01,
				'required'   => array(
					array( 'blog_title', '=', 'on' ),
					array( 'blog_title_bar_parallax', '=', 'on' ),
				)
			),
			array(
				'id'       => 'blog_title_bar_bg_color',
				'title'    => esc_html__( 'Title bar overlay color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'It will be put above image(if used)', 'apollo13-framework' ),
				'type'     => 'color_rgba',
				'required' => array( 'blog_title', '=', 'on' ),
				'default'  => array(
					'color' => '#ffffff',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'blog_title_bar_title_color',
				'title'    => esc_html__( 'Titles color', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'blog_title', '=', 'on' ),
			),
			array(
				'id'       => 'blog_title_bar_color_1',
				'title'    => esc_html__( 'Second elements color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Used in breadcrumbs.', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'blog_title', '=', 'on' ),
			),
			array(
				'id'       => 'blog_title_bar_space_width',
				'title'    => esc_html__( 'Space in top and bottom', 'apollo13-framework' ),
				'default'  => '40',
				'min'      => 0,
				'max'      => 600,
				'step'     => 1,
				'type'     => 'slider',
				'required' => array( 'blog_title', '=', 'on' ),
			),
			array(
				'id'       => 'blog_breadcrumbs',
				'title'    => esc_html__( 'Breadcrumbs', 'apollo13-framework' ),
				'default'  => 'on',
				'type'     => 'button_set',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'required' => array( 'blog_title', '=', 'on' ),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Posts list - filter', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_blog_filter',
		'icon'       => 'fa fa-filter',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'      => 'blog_filter',
				'type'    => 'button_set',
				'title'   => esc_html__( 'Filter', 'apollo13-framework' ),
				'options' => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default' => 'off',
			),
			array(
				'id'             => 'blog_filter_padding',
				'type'           => 'spacing',
				'mode'           => 'padding',
				'all'            => false,
				'top'            => true,
				'right'          => false,
				'bottom'         => true,
				'left'           => false,
				'units'          => array( 'px', 'em' ),
				'units_extended' => true,
				'display_units'  => true,
				'title'          => esc_html__( 'Padding', 'apollo13-framework' ),
				'desc'           => '',
				'default'        => array(
					'padding-top'    => '40px',
					'padding-bottom' => '40px',
				),
				'required'       => array( 'blog_filter', '=', 'on' ),
			),
			array(
				'id'       => 'blog_filter_bg_color',
				'title'    => esc_html__( 'Background color', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'blog_filter', '=', 'on' ),
			),
			array(
				'id'       => 'blog_filter_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Links color', 'apollo13-framework' ),
				'subtitle' => '',
				'required' => array( 'blog_filter', '=', 'on' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'blog_filter_hover_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Links hover/active color', 'apollo13-framework' ),
				'subtitle' => '',
				'required' => array( 'blog_filter', '=', 'on' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'blog_filter_weight',
				'type'     => 'select',
				'title'    => esc_html__( 'Font weight', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'100'    => esc_html__( '100', 'apollo13-framework' ),
					'200'    => esc_html__( '200', 'apollo13-framework' ),
					'300'    => esc_html__( '300', 'apollo13-framework' ),
					'normal' => esc_html__( 'Normal 400', 'apollo13-framework' ),
					'500'    => esc_html__( '500', 'apollo13-framework' ),
					'600'    => esc_html__( '600', 'apollo13-framework' ),
					'bold'   => esc_html__( 'Bold 700', 'apollo13-framework' ),
					'800'    => esc_html__( '800', 'apollo13-framework' ),
					'900'    => esc_html__( '900', 'apollo13-framework' ),
				),
				'default'  => 'bold',
				'required' => array( 'blog_filter', '=', 'on' ),
			),
			array(
				'id'       => 'blog_filter_transform',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Text transform', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'none'      => esc_html__( 'None', 'apollo13-framework' ),
					'uppercase' => esc_html__( 'Uppercase', 'apollo13-framework' ),
				),
				'default'  => 'uppercase',
				'required' => array( 'blog_filter', '=', 'on' ),
			),
			array(
				'id'       => 'blog_filter_text_align',
				'title'    => esc_html__( 'Text align', 'apollo13-framework' ),
				'type'     => 'button_set',
				'default'  => 'center',
				'options'  => array(
					'left'   => esc_html__( 'Left', 'apollo13-framework' ),
					'center' => esc_html__( 'Center', 'apollo13-framework' ),
					'right'  => esc_html__( 'Right', 'apollo13-framework' ),
				),
				'required' => array( 'blog_filter', '=', 'on' ),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Single post', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_post',
		'icon'       => 'fa fa-pencil-square',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'          => 'post_content_under_header',
				'title'       => esc_html__( 'Hide content under header', 'apollo13-framework' ),
				'description' => esc_html__( 'Only valid when using horizontal header.', 'apollo13-framework' ),
				'default'     => 'off',
				'type'        => 'select',
				'options'     => array(
					'content' => esc_html__( 'Yes hide content', 'apollo13-framework' ),
					'title'   => esc_html__( 'Yes hide content and add top padding to outside title bar.', 'apollo13-framework' ),
					'off'     => esc_html__( 'Turn it off', 'apollo13-framework' ),
				),
				'required'    => array( 'header_type', '=', 'horizontal' ),
			),
			array(
				'id'          => 'post_horizontal_header_color_variant',
				'title'       => esc_html__( 'Header color variant', 'apollo13-framework' ),
				'description' => esc_html__( 'Only valid when using horizontal header.', 'apollo13-framework' ),
				'default'     => 'normal',
				'type'        => 'select',
				'options'     => array(
					'normal' => esc_html__( 'Normal', 'apollo13-framework' ),
					'light'  => esc_html__( 'Light', 'apollo13-framework' ),
					'dark'   => esc_html__( 'Dark', 'apollo13-framework' ),
				),
				'required'    => array( 'header_type', '=', 'horizontal' ),
			),
			array(
				'id'       => 'post_content_layout',
				'type'     => 'select',
				'title'    => esc_html__( 'Content Layout', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'center'        => esc_html__( 'Center fixed width', 'apollo13-framework' ),
					'left'          => esc_html__( 'Left fixed width', 'apollo13-framework' ),
					'left_padding'  => esc_html__( 'Left fixed width + padding', 'apollo13-framework' ),
					'right'         => esc_html__( 'Right fixed width', 'apollo13-framework' ),
					'right_padding' => esc_html__( 'Right fixed width + padding', 'apollo13-framework' ),
					'full_fixed'    => esc_html__( 'Full width + fixed content', 'apollo13-framework' ),
					'full_padding'  => esc_html__( 'Full width + padding', 'apollo13-framework' ),
					'full'          => esc_html__( 'Full width', 'apollo13-framework' ),
				),
				'default'  => 'center',
			),
			array(
				'id'      => 'post_sidebar',
				'type'    => 'select',
				'title'   => esc_html__( 'Sidebar', 'apollo13-framework' ),
				'options' => array(
					'left-sidebar'  => esc_html__( 'Left', 'apollo13-framework' ),
					'right-sidebar' => esc_html__( 'Right', 'apollo13-framework' ),
					'off'           => esc_html__( 'Off', 'apollo13-framework' ),
				),
				'default' => 'right-sidebar',
			),
			array(
				'id'       => 'post_media',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Display post Media', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'You can set to not display post media(featured image/video/slider) inside of post.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'post_author_info',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Author info', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Will show information about author below post content.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
			),
			array(
				'id'       => 'post_date',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Post meta: Date of publish or last update', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'You can\'t use both dates, cause then Search Engine will not know which date is correct.', 'apollo13-framework' ),
				'options'  => array(
					'on'      => esc_html__( 'Published', 'apollo13-framework' ),
					'updated' => esc_html__( 'Updated', 'apollo13-framework' ),
					'off'     => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'post_author',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Post meta: Author', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'post_comments',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Post meta: Comments number', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'post_cats',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Post meta: Categories', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'post_tags',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Post meta: Tags', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'post_navigation',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Posts navigation', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Links to next and prev post.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),

		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Single post - title bar', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_post_title',
		'icon'       => 'fa fa-text-width',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'post_title',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Title', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'post_title_bar_position',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Title position', 'apollo13-framework' ),
				'options'  => array(
					'outside' => esc_html__( 'Before content', 'apollo13-framework' ),
					'inside'  => esc_html__( 'Inside content', 'apollo13-framework' ),
				),
				'default'  => 'inside',
				'required' => array( 'post_title', '=', 'on' ),
			),
			array(
				'id'       => 'post_title_bar_variant',
				'title'    => esc_html__( 'Title bar variant', 'apollo13-framework' ),
				'type'     => 'button_set',
				'default'  => 'classic',
				'options'  => array(
					'classic'  => esc_html__( 'Classic(to side)', 'apollo13-framework' ),
					'centered' => esc_html__( 'Centered', 'apollo13-framework' ),
				),
				'required' => array(
					array( 'post_title', '=', 'on' ),
					array( 'post_title_bar_position', '!=', 'inside' ),
				)
			),
			array(
				'id'       => 'post_title_bar_width',
				'title'    => esc_html__( 'Title bar width', 'apollo13-framework' ),
				'type'     => 'button_set',
				'default'  => 'full',
				'options'  => array(
					'full'  => esc_html__( 'Full', 'apollo13-framework' ),
					'boxed' => esc_html__( 'Boxed', 'apollo13-framework' ),
				),
				'required' => array(
					array( 'post_title', '=', 'on' ),
					array( 'post_title_bar_position', '!=', 'inside' ),
				)
			),
			array(
				'id'         => 'post_title_bar_image',
				'title'      => esc_html__( 'Title bar custom background image', 'apollo13-framework' ),
				'default'    => '',
				'type'       => 'media',
				'full_width' => false,
				'mode'       => 'image',
				'required'   => array(
					array( 'post_title', '=', 'on' ),
					array( 'post_title_bar_position', '!=', 'inside' ),
				)
			),
			array(
				'id'       => 'post_title_bar_image_fit',
				'title'    => esc_html__( 'How to fit background image', 'apollo13-framework' ),
				'default'  => 'repeat',
				'options'  => array(
					'cover'    => esc_html__( 'Cover', 'apollo13-framework' ),
					'contain'  => esc_html__( 'Contain', 'apollo13-framework' ),
					'fitV'     => esc_html__( 'Fit Vertically', 'apollo13-framework' ),
					'fitH'     => esc_html__( 'Fit Horizontally', 'apollo13-framework' ),
					'center'   => esc_html__( 'Just center', 'apollo13-framework' ),
					'repeat'   => esc_html__( 'Repeat', 'apollo13-framework' ),
					'repeat-x' => esc_html__( 'Repeat X', 'apollo13-framework' ),
					'repeat-y' => esc_html__( 'Repeat Y', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array(
					array( 'post_title', '=', 'on' ),
					array( 'post_title_bar_position', '!=', 'inside' ),
				)
			),
			array(
				'id'       => 'post_title_bar_parallax',
				'title'    => esc_html__( 'Title bar parallax?', 'apollo13-framework' ),
				'default'  => 'off',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'type'     => 'button_set',
				'required' => array(
					array( 'post_title', '=', 'on' ),
					array( 'post_title_bar_position', '!=', 'inside' ),
				)
			),
			array(
				'id'       => 'post_title_bar_parallax_type',
				'title'    => esc_html__( 'Parallax type', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'It defines how image will scroll in background while page is scrolled down.', 'apollo13-framework' ),
				'default'  => 'tb',
				'options'  => array(
					"tb"   => esc_html__( 'top to bottom', 'apollo13-framework' ),
					"bt"   => esc_html__( 'bottom to top', 'apollo13-framework' ),
					"lr"   => esc_html__( 'left to right', 'apollo13-framework' ),
					"rl"   => esc_html__( 'right to left', 'apollo13-framework' ),
					"tlbr" => esc_html__( 'top-left to bottom-right', 'apollo13-framework' ),
					"trbl" => esc_html__( 'top-right to bottom-left', 'apollo13-framework' ),
					"bltr" => esc_html__( 'bottom-left to top-right', 'apollo13-framework' ),
					"brtl" => esc_html__( 'bottom-right to top-left', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array(
					array( 'post_title', '=', 'on' ),
					array( 'post_title_bar_position', '!=', 'inside' ),
					array( 'post_title_bar_parallax', '=', 'on' ),
				)
			),
			array(
				'id'         => 'post_title_bar_parallax_speed',
				'title'      => esc_html__( 'Parallax speed', 'apollo13-framework' ),
				'subtitle'   => esc_html__( 'It will be only used for background that are repeated. If background is set to not repeat this value will be ignored.', 'apollo13-framework' ),
				'default'    => '1.00',
				'type'       => 'slider',
				'min'        => 0,
				'max'        => 1,
				'step'       => 0.01,
				'resolution' => 0.01,
				'required'   => array(
					array( 'post_title', '=', 'on' ),
					array( 'post_title_bar_position', '!=', 'inside' ),
					array( 'post_title_bar_parallax', '=', 'on' ),
				)
			),
			array(
				'id'       => 'post_title_bar_bg_color',
				'title'    => esc_html__( 'Title bar overlay color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'It will be put above image(if used)', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'post_title', '=', 'on' ),
			),
			array(
				'id'       => 'post_title_bar_title_color',
				'title'    => esc_html__( 'Titles color', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array(
					array( 'post_title', '=', 'on' ),
					array( 'post_title_bar_position', '!=', 'inside' ),
				)
			),
			array(
				'id'       => 'post_title_bar_color_1',
				'title'    => esc_html__( 'Second elements color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Used in breadcrumbs.', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array(
					array( 'post_title', '=', 'on' ),
					array( 'post_title_bar_position', '!=', 'inside' ),
				)
			),
			array(
				'id'       => 'post_title_bar_space_width',
				'title'    => esc_html__( 'Space in top and bottom', 'apollo13-framework' ),
				'default'  => '40',
				'min'      => 0,
				'max'      => 600,
				'step'     => 1,
				'type'     => 'slider',
				'required' => array(
					array( 'post_title', '=', 'on' ),
					array( 'post_title_bar_position', '!=', 'inside' ),
				)
			),
		)
	) );

//SHOP SETTINGS
	Redux::setSection( $opt_name, array(
		'title'           => esc_html__( 'Shop(WooCommerce) settings', 'apollo13-framework' ),
		'desc'            => '',
		'id'              => 'section_shop_general',
		'icon'            => 'fa fa-shopping-cart',
		'priority'        => 5,
		'customizer_only' => $customizer_only,
		'fields'          => array()
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Background', 'apollo13-framework' ),
		'desc'       => esc_html__( 'These options will work for all shop pages - product list, single product and other.', 'apollo13-framework' ),
		'id'         => 'subsection_shop_general',
		'icon'       => 'fa fa-picture-o',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'shop_custom_background',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Custom background', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
			),
			array(
				'id'         => 'shop_body_image',
				'type'       => 'media',
				'title'      => esc_html__( 'Background image', 'apollo13-framework' ),
				'full_width' => false,
				'mode'       => 'image',
				'subtitle'   => '',
				'required'   => array( 'shop_custom_background', '=', 'on' ),
			),
			array(
				'id'       => 'shop_body_image_fit',
				'type'     => 'select',
				'title'    => esc_html__( 'How to fit background image', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'cover'    => esc_html__( 'Cover', 'apollo13-framework' ),
					'contain'  => esc_html__( 'Contain', 'apollo13-framework' ),
					'fitV'     => esc_html__( 'Fit Vertically', 'apollo13-framework' ),
					'fitH'     => esc_html__( 'Fit Horizontally', 'apollo13-framework' ),
					'center'   => esc_html__( 'Just center', 'apollo13-framework' ),
					'repeat'   => esc_html__( 'Repeat', 'apollo13-framework' ),
					'repeat-x' => esc_html__( 'Repeat X', 'apollo13-framework' ),
					'repeat-y' => esc_html__( 'Repeat Y', 'apollo13-framework' ),
				),
				'default'  => 'cover',
				'required' => array( 'shop_custom_background', '=', 'on' ),
			),
			array(
				'id'       => 'shop_body_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Background color', 'apollo13-framework' ),
				'subtitle' => '',
				'required' => array( 'shop_custom_background', '=', 'on' ),
				'default'  => '',
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Products list', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_shop',
		'icon'       => 'fa fa-list',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'shop_search',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Search in products instead of pages', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'It will change wordpress default search function to make shop search. So when this is activated search function in header or search widget will act as woocommerece search widget.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
			),
			array(
				'id'          => 'shop_content_under_header',
				'title'       => esc_html__( 'Hide content under header', 'apollo13-framework' ),
				'description' => esc_html__( 'Only valid when using horizontal header.', 'apollo13-framework' ),
				'default'     => 'off',
				'type'        => 'select',
				'options'     => array(
					'content' => esc_html__( 'Yes hide content', 'apollo13-framework' ),
					'title'   => esc_html__( 'Yes hide content and add top padding to outside title bar.', 'apollo13-framework' ),
					'off'     => esc_html__( 'Turn it off', 'apollo13-framework' ),
				),
				'required'    => array( 'header_type', '=', 'horizontal' ),
			),
			array(
				'id'          => 'shop_horizontal_header_color_variant',
				'title'       => esc_html__( 'Header color variant', 'apollo13-framework' ),
				'description' => esc_html__( 'Only valid when using horizontal header.', 'apollo13-framework' ),
				'default'     => 'normal',
				'type'        => 'select',
				'options'     => array(
					'normal' => esc_html__( 'Normal', 'apollo13-framework' ),
					'light'  => esc_html__( 'Light', 'apollo13-framework' ),
					'dark'   => esc_html__( 'Dark', 'apollo13-framework' ),
				),
				'required'    => array( 'header_type', '=', 'horizontal' ),
			),
			array(
				'id'       => 'shop_content_layout',
				'type'     => 'select',
				'title'    => esc_html__( 'Content Layout', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'center'        => esc_html__( 'Center fixed width', 'apollo13-framework' ),
					'left'          => esc_html__( 'Left fixed width', 'apollo13-framework' ),
					'left_padding'  => esc_html__( 'Left fixed width + padding', 'apollo13-framework' ),
					'right'         => esc_html__( 'Right fixed width', 'apollo13-framework' ),
					'right_padding' => esc_html__( 'Right fixed width + padding', 'apollo13-framework' ),
					'full_fixed'    => esc_html__( 'Full width + fixed content', 'apollo13-framework' ),
					'full_padding'  => esc_html__( 'Full width + padding', 'apollo13-framework' ),
					'full'          => esc_html__( 'Full width', 'apollo13-framework' ),
				),
				'default'  => 'full',
			),
			array(
				'id'       => 'shop_sidebar',
				'type'     => 'select',
				'title'    => esc_html__( 'Sidebar', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'left-sidebar'  => esc_html__( 'Left', 'apollo13-framework' ),
					'right-sidebar' => esc_html__( 'Right', 'apollo13-framework' ),
					'off'           => esc_html__( 'Off', 'apollo13-framework' ),
				),
				'default'  => 'left-sidebar',
			),
			array(
				'id'       => 'shop_products_variant',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Look of products on list', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'overlay' => esc_html__( 'Text as overlay', 'apollo13-framework' ),
					'under'   => esc_html__( 'Text under photo', 'apollo13-framework' ),
				),
				'default'  => 'overlay',
			),
			array(
				'id'       => 'shop_products_subvariant',
				'type'     => 'select',
				'title'    => esc_html__( 'Look of products on list', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'left'   => esc_html__( 'Texts to left', 'apollo13-framework' ),
					'center' => esc_html__( 'Texts to center', 'apollo13-framework' ),
					'right'  => esc_html__( 'Texts to right', 'apollo13-framework' ),
				),
				'default'  => 'center',
				'required' => array( 'shop_products_variant', '=', 'under' ),
			),
			array(
				'id'       => 'shop_products_second_image',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Show second image of product on hover', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'shop_products_layout_mode',
				'type'     => 'button_set',
				'title'    => esc_html__( 'How to place items in rows', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'It your items has various heights you may want to start each row of items from new line instead of masonry style.', 'apollo13-framework' ),
				'options'  => array(
					'packery' => esc_html__( 'Masonry', 'apollo13-framework' ),
					'fitRows' => esc_html__( 'Each row from new line', 'apollo13-framework' ),
				),
				'default'  => 'packery',
			),
			array(
				'id'            => 'shop_products_columns',
				'type'          => 'slider',
				'title'         => esc_html__( 'Columns(per row)', 'apollo13-framework' ),
				'subtitle'      => esc_html__( 'It only affects wider screen resolutions.', 'apollo13-framework' ),
				'default'       => 4,
				'min'           => 1,
				'step'          => 1,
				'max'           => 4,
				'display_value' => 'text',
			),
			array(
				'id'            => 'shop_products_per_page',
				'type'          => 'slider',
				'title'         => esc_html__( 'Products per page', 'apollo13-framework' ),
				'default'       => 12,
				'min'           => 1,
				'step'          => 1,
				'max'           => 30,
				'display_value' => 'text',
			),
			array(
				'id'            => 'shop_brick_margin',
				'type'          => 'slider',
				'title'         => esc_html__( 'Product brick margin', 'apollo13-framework' ),
				'subtitle'      => '',
				'default'       => 20,
				'min'           => 0,
				'step'          => 1,
				'max'           => 100,
				'display_value' => 'text',
			),
			array(
				'id'       => 'shop_lazy_load',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Lazy load', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'shop_lazy_load_mode',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Lazy load mode', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'button' => esc_html__( 'By clicking button', 'apollo13-framework' ),
					'auto'   => esc_html__( 'On scroll', 'apollo13-framework' ),
				),
				'default'  => 'auto',
				'required' => array( 'shop_lazy_load', '=', 'on' ),
			),
			array(
				'id'       => 'shop_header_custom_sidebar',
				'type'     => 'select',
				'title'    => esc_html__( 'Custom header sidebar', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Works only with vertical header.', 'apollo13-framework' ),
				'options'  => $header_sidebars_off_global,
				'default'  => 'off',
				'required' => array( 'header_type', '=', 'vertical' ),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Products list - title bar', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_shop_title',
		'icon'       => 'fa fa-text-width',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'shop_title',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Title', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'shop_title_bar_variant',
				'title'    => esc_html__( 'Title bar variant', 'apollo13-framework' ),
				'type'     => 'button_set',
				'default'  => 'classic',
				'options'  => array(
					'classic'  => esc_html__( 'Classic(to side)', 'apollo13-framework' ),
					'centered' => esc_html__( 'Centered', 'apollo13-framework' ),
				),
				'required' => array( 'shop_title', '=', 'on' ),
			),
			array(
				'id'       => 'shop_title_bar_width',
				'title'    => esc_html__( 'Title bar width', 'apollo13-framework' ),
				'type'     => 'button_set',
				'default'  => 'full',
				'options'  => array(
					'full'  => esc_html__( 'Full', 'apollo13-framework' ),
					'boxed' => esc_html__( 'Boxed', 'apollo13-framework' ),
				),
				'required' => array( 'shop_title', '=', 'on' ),
			),
			array(
				'id'         => 'shop_title_bar_image',
				'title'      => esc_html__( 'Title bar custom background image', 'apollo13-framework' ),
				'default'    => '',
				'type'       => 'media',
				'full_width' => false,
				'mode'       => 'image',
				'required'   => array( 'shop_title', '=', 'on' ),
			),
			array(
				'id'       => 'shop_title_bar_image_fit',
				'title'    => esc_html__( 'How to fit background image', 'apollo13-framework' ),
				'default'  => 'repeat',
				'options'  => array(
					'cover'    => esc_html__( 'Cover', 'apollo13-framework' ),
					'contain'  => esc_html__( 'Contain', 'apollo13-framework' ),
					'fitV'     => esc_html__( 'Fit Vertically', 'apollo13-framework' ),
					'fitH'     => esc_html__( 'Fit Horizontally', 'apollo13-framework' ),
					'center'   => esc_html__( 'Just center', 'apollo13-framework' ),
					'repeat'   => esc_html__( 'Repeat', 'apollo13-framework' ),
					'repeat-x' => esc_html__( 'Repeat X', 'apollo13-framework' ),
					'repeat-y' => esc_html__( 'Repeat Y', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array( 'shop_title', '=', 'on' ),
			),
			array(
				'id'       => 'shop_title_bar_parallax',
				'title'    => esc_html__( 'Title bar parallax?', 'apollo13-framework' ),
				'default'  => 'off',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'type'     => 'button_set',
				'required' => array( 'shop_title', '=', 'on' ),
			),
			array(
				'id'       => 'shop_title_bar_parallax_type',
				'title'    => esc_html__( 'Parallax type', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'It defines how image will scroll in background while page is scrolled down.', 'apollo13-framework' ),
				'default'  => 'tb',
				'options'  => array(
					"tb"   => esc_html__( 'top to bottom', 'apollo13-framework' ),
					"bt"   => esc_html__( 'bottom to top', 'apollo13-framework' ),
					"lr"   => esc_html__( 'left to right', 'apollo13-framework' ),
					"rl"   => esc_html__( 'right to left', 'apollo13-framework' ),
					"tlbr" => esc_html__( 'top-left to bottom-right', 'apollo13-framework' ),
					"trbl" => esc_html__( 'top-right to bottom-left', 'apollo13-framework' ),
					"bltr" => esc_html__( 'bottom-left to top-right', 'apollo13-framework' ),
					"brtl" => esc_html__( 'bottom-right to top-left', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array(
					array( 'shop_title', '=', 'on' ),
					array( 'shop_title_bar_parallax', '=', 'on' ),
				)
			),
			array(
				'id'         => 'shop_title_bar_parallax_speed',
				'title'      => esc_html__( 'Parallax speed', 'apollo13-framework' ),
				'subtitle'   => esc_html__( 'It will be only used for background that are repeated. If background is set to not repeat this value will be ignored.', 'apollo13-framework' ),
				'default'    => '1.00',
				'type'       => 'slider',
				'min'        => 0,
				'max'        => 1,
				'step'       => 0.01,
				'resolution' => 0.01,
				'required'   => array(
					array( 'shop_title', '=', 'on' ),
					array( 'shop_title_bar_parallax', '=', 'on' ),
				)
			),
			array(
				'id'       => 'shop_title_bar_bg_color',
				'title'    => esc_html__( 'Title bar overlay color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'It will be put above image(if used)', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'shop_title', '=', 'on' ),
			),
			array(
				'id'       => 'shop_title_bar_title_color',
				'title'    => esc_html__( 'Titles color', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'shop_title', '=', 'on' ),
			),
			array(
				'id'       => 'shop_title_bar_color_1',
				'title'    => esc_html__( 'Second elements color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Used in breadcrumbs.', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'shop_title', '=', 'on' ),
			),
			array(
				'id'       => 'shop_title_bar_space_width',
				'title'    => esc_html__( 'Space in top and bottom', 'apollo13-framework' ),
				'default'  => '40',
				'min'      => 0,
				'max'      => 600,
				'step'     => 1,
				'type'     => 'slider',
				'required' => array( 'shop_title', '=', 'on' ),
			),
			array(
				'id'       => 'shop_breadcrumbs',
				'title'    => esc_html__( 'Breadcrumbs', 'apollo13-framework' ),
				'default'  => 'on',
				'type'     => 'button_set',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'required' => array( 'shop_title', '=', 'on' ),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Single product', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_product',
		'icon'       => 'fa fa-pencil-square',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'product_content_layout',
				'type'     => 'select',
				'title'    => esc_html__( 'Content Layout', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'center'        => esc_html__( 'Center fixed width', 'apollo13-framework' ),
					'left'          => esc_html__( 'Left fixed width', 'apollo13-framework' ),
					'left_padding'  => esc_html__( 'Left fixed width + padding', 'apollo13-framework' ),
					'right'         => esc_html__( 'Right fixed width', 'apollo13-framework' ),
					'right_padding' => esc_html__( 'Right fixed width + padding', 'apollo13-framework' ),
					'full_fixed'    => esc_html__( 'Full width + fixed content', 'apollo13-framework' ),
					'full_padding'  => esc_html__( 'Full width + padding', 'apollo13-framework' ),
					'full'          => esc_html__( 'Full width', 'apollo13-framework' ),
				),
				'default'  => 'full_fixed',
			),
			array(
				'id'       => 'product_sidebar',
				'type'     => 'select',
				'title'    => esc_html__( 'Sidebar', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'left-sidebar'  => esc_html__( 'Left', 'apollo13-framework' ),
					'right-sidebar' => esc_html__( 'Right', 'apollo13-framework' ),
					'off'           => esc_html__( 'Off', 'apollo13-framework' ),
				),
				'default'  => 'left-sidebar',
			),
			array(
				'id'       => 'product_custom_thumbs',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Theme thumbnails', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'If disabled it will display standard WooCommerce thumbs.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Other shop pages', 'apollo13-framework' ),
		'desc'       => esc_html__( 'Settings for cart, checkout, order received and my account pages.', 'apollo13-framework' ),
		'id'         => 'subsection_shop_no_major_pages',
		'icon'       => 'fa fa-cog',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'shop_no_major_pages_content_layout',
				'type'     => 'select',
				'title'    => esc_html__( 'Content Layout', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'center'        => esc_html__( 'Center fixed width', 'apollo13-framework' ),
					'left'          => esc_html__( 'Left fixed width', 'apollo13-framework' ),
					'left_padding'  => esc_html__( 'Left fixed width + padding', 'apollo13-framework' ),
					'right'         => esc_html__( 'Right fixed width', 'apollo13-framework' ),
					'right_padding' => esc_html__( 'Right fixed width + padding', 'apollo13-framework' ),
					'full_fixed'    => esc_html__( 'Full width + fixed content', 'apollo13-framework' ),
					'full_padding'  => esc_html__( 'Full width + padding', 'apollo13-framework' ),
					'full'          => esc_html__( 'Full width', 'apollo13-framework' ),
				),
				'default'  => 'full_fixed',
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'desc'       => esc_html__( 'Settings for cart, checkout, order received and my account pages.', 'apollo13-framework' ),
		'title'      => esc_html__( 'Other shop pages - title bar', 'apollo13-framework' ),
		'id'         => 'subsection_shop_no_major_pages_title',
		'icon'       => 'fa fa-text-width',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'shop_no_major_pages_title',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Title', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'shop_no_major_pages_title_bar_variant',
				'title'    => esc_html__( 'Title bar variant', 'apollo13-framework' ),
				'type'     => 'button_set',
				'default'  => 'classic',
				'options'  => array(
					'classic'  => esc_html__( 'Classic(to side)', 'apollo13-framework' ),
					'centered' => esc_html__( 'Centered', 'apollo13-framework' ),
				),
				'required' => array( 'shop_no_major_pages_title', '=', 'on' ),
			),
			array(
				'id'       => 'shop_no_major_pages_title_bar_width',
				'title'    => esc_html__( 'Title bar width', 'apollo13-framework' ),
				'type'     => 'button_set',
				'default'  => 'full',
				'options'  => array(
					'full'  => esc_html__( 'Full', 'apollo13-framework' ),
					'boxed' => esc_html__( 'Boxed', 'apollo13-framework' ),
				),
				'required' => array( 'shop_no_major_pages_title', '=', 'on' ),
			),
			array(
				'id'         => 'shop_no_major_pages_title_bar_image',
				'title'      => esc_html__( 'Title bar custom background image', 'apollo13-framework' ),
				'default'    => '',
				'type'       => 'media',
				'full_width' => false,
				'mode'       => 'image',
				'required'   => array( 'shop_no_major_pages_title', '=', 'on' ),
			),
			array(
				'id'       => 'shop_no_major_pages_title_bar_image_fit',
				'title'    => esc_html__( 'How to fit background image', 'apollo13-framework' ),
				'default'  => 'repeat',
				'options'  => array(
					'cover'    => esc_html__( 'Cover', 'apollo13-framework' ),
					'contain'  => esc_html__( 'Contain', 'apollo13-framework' ),
					'fitV'     => esc_html__( 'Fit Vertically', 'apollo13-framework' ),
					'fitH'     => esc_html__( 'Fit Horizontally', 'apollo13-framework' ),
					'center'   => esc_html__( 'Just center', 'apollo13-framework' ),
					'repeat'   => esc_html__( 'Repeat', 'apollo13-framework' ),
					'repeat-x' => esc_html__( 'Repeat X', 'apollo13-framework' ),
					'repeat-y' => esc_html__( 'Repeat Y', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array( 'shop_no_major_pages_title', '=', 'on' ),
			),
			array(
				'id'       => 'shop_no_major_pages_title_bar_parallax',
				'title'    => esc_html__( 'Title bar parallax?', 'apollo13-framework' ),
				'default'  => 'off',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'type'     => 'button_set',
				'required' => array( 'shop_no_major_pages_title', '=', 'on' ),
			),
			array(
				'id'       => 'shop_no_major_pages_title_bar_parallax_type',
				'title'    => esc_html__( 'Parallax type', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'It defines how image will scroll in background while page is scrolled down.', 'apollo13-framework' ),
				'default'  => 'tb',
				'options'  => array(
					"tb"   => esc_html__( 'top to bottom', 'apollo13-framework' ),
					"bt"   => esc_html__( 'bottom to top', 'apollo13-framework' ),
					"lr"   => esc_html__( 'left to right', 'apollo13-framework' ),
					"rl"   => esc_html__( 'right to left', 'apollo13-framework' ),
					"tlbr" => esc_html__( 'top-left to bottom-right', 'apollo13-framework' ),
					"trbl" => esc_html__( 'top-right to bottom-left', 'apollo13-framework' ),
					"bltr" => esc_html__( 'bottom-left to top-right', 'apollo13-framework' ),
					"brtl" => esc_html__( 'bottom-right to top-left', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array(
					array( 'shop_no_major_pages_title', '=', 'on' ),
					array( 'shop_no_major_pages_title_bar_parallax', '=', 'on' ),
				)
			),
			array(
				'id'         => 'shop_no_major_pages_title_bar_parallax_speed',
				'title'      => esc_html__( 'Parallax speed', 'apollo13-framework' ),
				'subtitle'   => esc_html__( 'It will be only used for background that are repeated. If background is set to not repeat this value will be ignored.', 'apollo13-framework' ),
				'default'    => '1.00',
				'type'       => 'slider',
				'min'        => 0,
				'max'        => 1,
				'step'       => 0.01,
				'resolution' => 0.01,
				'required'   => array(
					array( 'shop_no_major_pages_title', '=', 'on' ),
					array( 'shop_no_major_pages_title_bar_parallax', '=', 'on' ),
				)
			),
			array(
				'id'       => 'shop_no_major_pages_title_bar_bg_color',
				'title'    => esc_html__( 'Title bar overlay color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'It will be put above image(if used)', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'shop_no_major_pages_title', '=', 'on' ),
			),
			array(
				'id'       => 'shop_no_major_pages_title_bar_title_color',
				'title'    => esc_html__( 'Titles color', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'shop_no_major_pages_title', '=', 'on' ),
			),
			array(
				'id'       => 'shop_no_major_pages_title_bar_color_1',
				'title'    => esc_html__( 'Second elements color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Used in breadcrumbs.', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'shop_no_major_pages_title', '=', 'on' ),
			),
			array(
				'id'       => 'shop_no_major_pages_title_bar_space_width',
				'title'    => esc_html__( 'Space in top and bottom', 'apollo13-framework' ),
				'default'  => '40',
				'min'      => 0,
				'max'      => 600,
				'step'     => 1,
				'type'     => 'slider',
				'required' => array( 'shop_no_major_pages_title', '=', 'on' ),
			),
			array(
				'id'       => 'shop_no_major_pages_breadcrumbs',
				'title'    => esc_html__( 'Breadcrumbs', 'apollo13-framework' ),
				'default'  => 'on',
				'type'     => 'button_set',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'required' => array( 'shop_no_major_pages_title', '=', 'on' ),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Pop up basket', 'apollo13-framework' ),
		'desc'       => esc_html__( 'When WooCommerce is activated, button opening this cart will appear in header. There also have to be some active widgets in "Basket sidebar" for this.', 'apollo13-framework' ),
		'id'         => 'subsection_basket_sidebars',
		'icon'       => 'fa fa-shopping-basket',
		'subsection' => true,
		'fields'     => array(

			array(
				'id'       => 'basket_sidebar_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Background color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => '',
			),
			array(
				'id'            => 'basket_sidebar_font_size',
				'type'          => 'slider',
				'title'         => esc_html__( 'Font size', 'apollo13-framework' ),
				'subtitle'      => '',
				'default'       => '',
				'min'           => 5,
				'step'          => 1,
				'max'           => 30,
				'display_value' => 'text',
			),
			array(
				'id'       => 'basket_sidebar_widgets_color',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Widgets colors', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Depending on what background you have setup, choose proper option.', 'apollo13-framework' ),
				'options'  => array(
					'dark-sidebar'  => esc_html__( 'On dark', 'apollo13-framework' ),
					'light-sidebar' => esc_html__( 'On light', 'apollo13-framework' ),
				),
				'default'  => 'light-sidebar',
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Buttons', 'apollo13-framework' ),
		'desc'       => esc_html__( 'You can change here colors of buttons used in shop. Alternative buttons colors are used in various places of shop.', 'apollo13-framework' ),
		'id'         => 'subsection_buttons_shop',
		'icon'       => 'fa fa-arrow-down',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'button_shop_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Background color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => array(
					'color' => '#524F51',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'button_shop_bg_hover_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Background hover color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => array(
					'color' => '#000',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'button_shop_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Text color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => array(
					'color' => '#cccccc',
					'alpha' => 1
				)
			),
			array(
				'id'       => 'button_shop_hover_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Text hover color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => array(
					'color' => '#ffffff',
					'alpha' => 1
				)
			),
			array(
				'id'       => 'button_shop_alt_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Alternative button: Background color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => array(
					'color' => '#524F51',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'button_shop_alt_bg_hover_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Alternative button: Background hover color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => array(
					'color' => '#000',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'button_shop_alt_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Alternative button: Text color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => array(
					'color' => '#cccccc',
					'alpha' => 1
				)
			),
			array(
				'id'       => 'button_shop_alt_hover_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Alternative button: Text hover color', 'apollo13-framework' ),
				'subtitle' => '',
				'default'  => array(
					'color' => '#ffffff',
					'alpha' => 1
				)
			),
			array(
				'id'            => 'button_shop_font_size',
				'type'          => 'slider',
				'title'         => esc_html__( 'Font size', 'apollo13-framework' ),
				'subtitle'      => '',
				'default'       => 13,
				'min'           => 10,
				'step'          => 1,
				'max'           => 60,
				'display_value' => 'text',
			),
			array(
				'id'       => 'button_shop_weight',
				'type'     => 'select',
				'title'    => esc_html__( 'Font weight', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'100'    => esc_html__( '100', 'apollo13-framework' ),
					'200'    => esc_html__( '200', 'apollo13-framework' ),
					'300'    => esc_html__( '300', 'apollo13-framework' ),
					'normal' => esc_html__( 'Normal 400', 'apollo13-framework' ),
					'500'    => esc_html__( '500', 'apollo13-framework' ),
					'600'    => esc_html__( '600', 'apollo13-framework' ),
					'bold'   => esc_html__( 'Bold 700', 'apollo13-framework' ),
					'800'    => esc_html__( '800', 'apollo13-framework' ),
					'900'    => esc_html__( '900', 'apollo13-framework' ),
				),
				'default'  => 'bold',
			),
			array(
				'id'       => 'button_shop_transform',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Text transform', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'none'      => esc_html__( 'None', 'apollo13-framework' ),
					'uppercase' => esc_html__( 'Uppercase', 'apollo13-framework' ),
				),
				'default'  => 'uppercase',
			),
			array(
				'id'             => 'button_shop_padding',
				'type'           => 'spacing',
				'mode'           => 'padding',
				'all'            => false,
				'top'            => false,
				'right'          => true,
				'bottom'         => false,
				'left'           => true,
				'units'          => array( 'px', 'em' ),
				'units_extended' => true,
				'display_units'  => true,
				'title'          => esc_html__( 'Padding', 'apollo13-framework' ),
				'desc'           => '',
				'default'        => array(
					'padding-left'  => '30px',
					'padding-right' => '30px',
				),
			),
		)
	) );

//PAGE SETTINGS
	Redux::setSection( $opt_name, array(
		'title'           => esc_html__( 'Page settings', 'apollo13-framework' ),
		'desc'            => '',
		'id'              => 'section_page',
		'icon'            => 'el el-file-edit',
		'priority'        => 6,
		'customizer_only' => $customizer_only,
		'fields'          => array()
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Single page', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_page',
		'icon'       => 'el el-file-edit',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'page_comments',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Comments', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'          => 'page_content_under_header',
				'title'       => esc_html__( 'Hide content under header', 'apollo13-framework' ),
				'description' => esc_html__( 'Only valid when using horizontal header.', 'apollo13-framework' ),
				'default'     => 'off',
				'type'        => 'select',
				'options'     => array(
					'content' => esc_html__( 'Yes hide content', 'apollo13-framework' ),
					'title'   => esc_html__( 'Yes hide content and add top padding to outside title bar.', 'apollo13-framework' ),
					'off'     => esc_html__( 'Turn it off', 'apollo13-framework' ),
				),
				'required'    => array( 'header_type', '=', 'horizontal' ),
			),
			array(
				'id'          => 'page_horizontal_header_color_variant',
				'title'       => esc_html__( 'Header color variant', 'apollo13-framework' ),
				'description' => esc_html__( 'Only valid when using horizontal header.', 'apollo13-framework' ),
				'default'     => 'normal',
				'type'        => 'select',
				'options'     => array(
					'normal' => esc_html__( 'Normal', 'apollo13-framework' ),
					'light'  => esc_html__( 'Light', 'apollo13-framework' ),
					'dark'   => esc_html__( 'Dark', 'apollo13-framework' ),
				),
				'required'    => array( 'header_type', '=', 'horizontal' ),
			),
			array(
				'id'       => 'page_content_layout',
				'type'     => 'select',
				'title'    => esc_html__( 'Content Layout', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'center'        => esc_html__( 'Center fixed width', 'apollo13-framework' ),
					'left'          => esc_html__( 'Left fixed width', 'apollo13-framework' ),
					'left_padding'  => esc_html__( 'Left fixed width + padding', 'apollo13-framework' ),
					'right'         => esc_html__( 'Right fixed width', 'apollo13-framework' ),
					'right_padding' => esc_html__( 'Right fixed width + padding', 'apollo13-framework' ),
					'full_fixed'    => esc_html__( 'Full width + fixed content', 'apollo13-framework' ),
					'full_padding'  => esc_html__( 'Full width + padding', 'apollo13-framework' ),
					'full'          => esc_html__( 'Full width', 'apollo13-framework' ),
				),
				'default'  => 'center',
			),
			array(
				'id'       => 'page_sidebar',
				'type'     => 'select',
				'title'    => esc_html__( 'Sidebar', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'You can change it in each page settings.', 'apollo13-framework' ),
				'options'  => array(
					'left-sidebar'          => esc_html__( 'Sidebar on the left', 'apollo13-framework' ),
					'left-sidebar_and_nav'  => esc_html__( 'Children Navigation + sidebar on the left', 'apollo13-framework' ),
					'left-nav'              => esc_html__( 'Only children Navigation on the left', 'apollo13-framework' ),
					'right-sidebar'         => esc_html__( 'Sidebar on the right', 'apollo13-framework' ),
					'right-sidebar_and_nav' => esc_html__( 'Children Navigation + sidebar on the right', 'apollo13-framework' ),
					'right-nav'             => esc_html__( 'Only children Navigation on the right', 'apollo13-framework' ),
					'off'                   => esc_html__( 'Off', 'apollo13-framework' ),
				),
				'default'  => 'off',
			),
			array(
				'id'       => 'page_custom_background',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Custom background', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
			),
			array(
				'id'         => 'page_body_image',
				'type'       => 'media',
				'title'      => esc_html__( 'Background image', 'apollo13-framework' ),
				'full_width' => false,
				'mode'       => 'image',
				'subtitle'   => '',
				'required'   => array( 'page_custom_background', '=', 'on' ),
			),
			array(
				'id'       => 'page_body_image_fit',
				'type'     => 'select',
				'title'    => esc_html__( 'How to fit background image', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'cover'    => esc_html__( 'Cover', 'apollo13-framework' ),
					'contain'  => esc_html__( 'Contain', 'apollo13-framework' ),
					'fitV'     => esc_html__( 'Fit Vertically', 'apollo13-framework' ),
					'fitH'     => esc_html__( 'Fit Horizontally', 'apollo13-framework' ),
					'center'   => esc_html__( 'Just center', 'apollo13-framework' ),
					'repeat'   => esc_html__( 'Repeat', 'apollo13-framework' ),
					'repeat-x' => esc_html__( 'Repeat X', 'apollo13-framework' ),
					'repeat-y' => esc_html__( 'Repeat Y', 'apollo13-framework' ),
				),
				'default'  => 'cover',
				'required' => array( 'page_custom_background', '=', 'on' ),
			),
			array(
				'id'       => 'page_body_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Background color', 'apollo13-framework' ),
				'subtitle' => '',
				'required' => array( 'page_custom_background', '=', 'on' ),
				'default'  => '',
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Single page - title bar', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_page_title',
		'icon'       => 'fa fa-text-width',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'page_title',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Title', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'page_title_bar_position',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Title position', 'apollo13-framework' ),
				'options'  => array(
					'outside' => esc_html__( 'Before content', 'apollo13-framework' ),
					'inside'  => esc_html__( 'Inside content', 'apollo13-framework' ),
				),
				'default'  => 'outside',
				'required' => array( 'page_title', '=', 'on' ),
			),
			array(
				'id'       => 'page_title_bar_variant',
				'title'    => esc_html__( 'Title bar variant', 'apollo13-framework' ),
				'type'     => 'button_set',
				'default'  => 'classic',
				'options'  => array(
					'classic'  => esc_html__( 'Classic(to side)', 'apollo13-framework' ),
					'centered' => esc_html__( 'Centered', 'apollo13-framework' ),
				),
				'required' => array(
					array( 'page_title', '=', 'on' ),
					array( 'page_title_bar_position', '!=', 'inside' ),
				)
			),
			array(
				'id'         => 'page_title_bar_image',
				'title'      => esc_html__( 'Title bar custom background image', 'apollo13-framework' ),
				'default'    => '',
				'type'       => 'media',
				'full_width' => false,
				'mode'       => 'image',
				'required'   => array(
					array( 'page_title', '=', 'on' ),
					array( 'page_title_bar_position', '!=', 'inside' ),
				)
			),
			array(
				'id'       => 'page_title_bar_image_fit',
				'title'    => esc_html__( 'How to fit background image', 'apollo13-framework' ),
				'default'  => 'repeat',
				'options'  => array(
					'cover'    => esc_html__( 'Cover', 'apollo13-framework' ),
					'contain'  => esc_html__( 'Contain', 'apollo13-framework' ),
					'fitV'     => esc_html__( 'Fit Vertically', 'apollo13-framework' ),
					'fitH'     => esc_html__( 'Fit Horizontally', 'apollo13-framework' ),
					'center'   => esc_html__( 'Just center', 'apollo13-framework' ),
					'repeat'   => esc_html__( 'Repeat', 'apollo13-framework' ),
					'repeat-x' => esc_html__( 'Repeat X', 'apollo13-framework' ),
					'repeat-y' => esc_html__( 'Repeat Y', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array(
					array( 'page_title', '=', 'on' ),
					array( 'page_title_bar_position', '!=', 'inside' ),
				)
			),
			array(
				'id'       => 'page_title_bar_parallax',
				'title'    => esc_html__( 'Title bar parallax?', 'apollo13-framework' ),
				'default'  => 'off',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'type'     => 'button_set',
				'required' => array(
					array( 'page_title', '=', 'on' ),
					array( 'page_title_bar_position', '!=', 'inside' ),
				)
			),
			array(
				'id'       => 'page_title_bar_parallax_type',
				'title'    => esc_html__( 'Parallax type', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'It defines how image will scroll in background while page is scrolled down.', 'apollo13-framework' ),
				'default'  => 'tb',
				'options'  => array(
					"tb"   => esc_html__( 'top to bottom', 'apollo13-framework' ),
					"bt"   => esc_html__( 'bottom to top', 'apollo13-framework' ),
					"lr"   => esc_html__( 'left to right', 'apollo13-framework' ),
					"rl"   => esc_html__( 'right to left', 'apollo13-framework' ),
					"tlbr" => esc_html__( 'top-left to bottom-right', 'apollo13-framework' ),
					"trbl" => esc_html__( 'top-right to bottom-left', 'apollo13-framework' ),
					"bltr" => esc_html__( 'bottom-left to top-right', 'apollo13-framework' ),
					"brtl" => esc_html__( 'bottom-right to top-left', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array(
					array( 'page_title', '=', 'on' ),
					array( 'page_title_bar_position', '!=', 'inside' ),
					array( 'page_title_bar_parallax', '=', 'on' ),
				)
			),
			array(
				'id'         => 'page_title_bar_parallax_speed',
				'title'      => esc_html__( 'Parallax speed', 'apollo13-framework' ),
				'subtitle'   => esc_html__( 'It will be only used for background that are repeated. If background is set to not repeat this value will be ignored.', 'apollo13-framework' ),
				'default'    => '1.00',
				'type'       => 'slider',
				'min'        => 0,
				'max'        => 1,
				'step'       => 0.01,
				'resolution' => 0.01,
				'required'   => array(
					array( 'page_title', '=', 'on' ),
					array( 'page_title_bar_position', '!=', 'inside' ),
					array( 'page_title_bar_parallax', '=', 'on' ),
				)
			),
			array(
				'id'       => 'page_title_bar_bg_color',
				'title'    => esc_html__( 'Title bar overlay color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'It will be put above image(if used)', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'page_title', '=', 'on' ),
			),
			array(
				'id'       => 'page_title_bar_title_color',
				'title'    => esc_html__( 'Titles color', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array(
					array( 'page_title', '=', 'on' ),
					array( 'page_title_bar_position', '!=', 'inside' ),
				)
			),
			array(
				'id'       => 'page_title_bar_color_1',
				'title'    => esc_html__( 'Second elements color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Used in breadcrumbs.', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array(
					array( 'page_title', '=', 'on' ),
					array( 'page_title_bar_position', '!=', 'inside' ),
				)
			),
			array(
				'id'       => 'page_title_bar_space_width',
				'title'    => esc_html__( 'Space in top and bottom', 'apollo13-framework' ),
				'default'  => '40',
				'min'      => 0,
				'max'      => 600,
				'step'     => 1,
				'type'     => 'slider',
				'required' => array(
					array( 'page_title', '=', 'on' ),
					array( 'page_title_bar_position', '!=', 'inside' ),
				)
			),
			array(
				'id'       => 'page_breadcrumbs',
				'title'    => esc_html__( 'Breadcrumbs', 'apollo13-framework' ),
				'default'  => 'on',
				'type'     => 'button_set',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'required' => array( 'page_title', '=', 'on' ),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( '404 page template', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_404_page',
		'icon'       => 'fa fa-exclamation-triangle',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'page_404_template_type',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Type', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'default' => esc_html__( 'Default', 'apollo13-framework' ),
					'custom'  => esc_html__( 'Custom', 'apollo13-framework' ),
				),
				'default'  => 'default',
			),
			array(
				'id'         => 'page_404_bg_image',
				'type'       => 'media',
				'title'      => esc_html__( 'Default but I want to change background image', 'apollo13-framework' ),
				'full_width' => false,
				'mode'       => 'image',
				'subtitle'   => '',
				'required'   => array( 'page_404_template_type', '=', 'default' ),
			),
			array(
				'id'       => 'page_404_template',
				'type'     => 'select',
				'data'     => 'pages',
				'args'     => array(
					'posts_per_page' => - 1
				),
				'title'    => esc_html__( 'Select page as your template', 'apollo13-framework' ),
				'subtitle' => '',
				'required' => array( 'page_404_template_type', '=', 'custom' ),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Maintenance mode', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_maintenance_page',
		'icon'       => 'fa fa-wrench',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'maintenance_mode',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Maintenance mode', 'apollo13-framework' ),
				'subtitle' => '',
				'desc'     => esc_html__( 'By enabling this feature your website will be forced to display the page of your choice. This can be used as Coming Soon feature as well.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
			),
			array(
				'id'       => 'maintenance_mode_page',
				'type'     => 'select',
				'data'     => 'pages',
				'args'     => array(
					'posts_per_page' => - 1
				),
				'title'    => esc_html__( 'Select page as your template', 'apollo13-framework' ),
				'subtitle' => '',
				'required' => array( 'maintenance_mode', '=', 'on' ),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Password protected page template', 'apollo13-framework' ),
		'desc'       => esc_html__( 'While using default type, top space &amp; title bar will be styled depending on what post type was password protected. Page like pages, post like posts etc.', 'apollo13-framework' ),
		'id'         => 'subsection_password_page',
		'icon'       => 'fa fa-lock',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'page_password_template_type',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Type', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'default' => esc_html__( 'Default', 'apollo13-framework' ),
					'custom'  => esc_html__( 'Custom', 'apollo13-framework' ),
				),
				'default'  => 'default',
			),
			array(
				'id'         => 'page_password_bg_image',
				'type'       => 'media',
				'title'      => esc_html__( 'Default but I want to change background image', 'apollo13-framework' ),
				'full_width' => false,
				'mode'       => 'image',
				'subtitle'   => '',
				'required'   => array( 'page_password_template_type', '=', 'default' ),
			),
			array(
				'id'       => 'page_password_template',
				'type'     => 'select',
				'data'     => 'pages',
				'args'     => array(
					'posts_per_page' => - 1
				),
				'title'    => esc_html__( 'Select page as your template', 'apollo13-framework' ),
				'subtitle' => '',
				'required' => array( 'page_password_template_type', '=', 'custom' ),
			),
		)
	) );

//WORKS SETTINGS
	Redux::setSection( $opt_name, array(
		'title'           => esc_html__( 'Works settings', 'apollo13-framework' ),
		'desc'            => '',
		'id'              => 'section_works',
		'icon'            => 'fa fa-cogs',
		'priority'        => 7,
		'customizer_only' => $customizer_only,
		'fields'          => array()
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Background', 'apollo13-framework' ),
		'desc'       => esc_html__( 'These will work for Works list and single work.', 'apollo13-framework' ),
		'id'         => 'subsection_works_general',
		'icon'       => 'fa fa-picture-o',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'works_custom_background',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Custom background', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
			),
			array(
				'id'         => 'works_body_image',
				'type'       => 'media',
				'title'      => esc_html__( 'Background image', 'apollo13-framework' ),
				'full_width' => false,
				'mode'       => 'image',
				'subtitle'   => '',
				'required'   => array( 'works_custom_background', '=', 'on' ),
			),
			array(
				'id'       => 'works_body_image_fit',
				'type'     => 'select',
				'title'    => esc_html__( 'How to fit background image', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'cover'    => esc_html__( 'Cover', 'apollo13-framework' ),
					'contain'  => esc_html__( 'Contain', 'apollo13-framework' ),
					'fitV'     => esc_html__( 'Fit Vertically', 'apollo13-framework' ),
					'fitH'     => esc_html__( 'Fit Horizontally', 'apollo13-framework' ),
					'center'   => esc_html__( 'Just center', 'apollo13-framework' ),
					'repeat'   => esc_html__( 'Repeat', 'apollo13-framework' ),
					'repeat-x' => esc_html__( 'Repeat X', 'apollo13-framework' ),
					'repeat-y' => esc_html__( 'Repeat Y', 'apollo13-framework' ),
				),
				'default'  => 'cover',
				'required' => array( 'works_custom_background', '=', 'on' ),
			),
			array(
				'id'       => 'works_body_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Background color', 'apollo13-framework' ),
				'subtitle' => '',
				'required' => array( 'works_custom_background', '=', 'on' ),
				'default'  => '',
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Works list', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_works_list',
		'icon'       => 'fa fa-list',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'works_list_page',
				'type'     => 'select',
				'data'     => 'pages',
				'args'     => array(
					'posts_per_page' => - 1
				),
				'title'    => esc_html__( 'Works list main page', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'This page will list all your works and also give main title for "work category" pages.', 'apollo13-framework' ),
			),
			array(
				'id'          => 'works_list_content_under_header',
				'title'       => esc_html__( 'Hide content under header', 'apollo13-framework' ),
				'description' => esc_html__( 'Only valid when using horizontal header.', 'apollo13-framework' ),
				'default'     => 'off',
				'type'        => 'select',
				'options'     => array(
					'content' => esc_html__( 'Yes hide content', 'apollo13-framework' ),
					'title'   => esc_html__( 'Yes hide content and add top padding to outside title bar.', 'apollo13-framework' ),
					'off'     => esc_html__( 'Turn it off', 'apollo13-framework' ),
				),
				'required'    => array( 'header_type', '=', 'horizontal' ),
			),
			array(
				'id'          => 'works_list_horizontal_header_color_variant',
				'title'       => esc_html__( 'Header color variant', 'apollo13-framework' ),
				'description' => esc_html__( 'Only valid when using horizontal header.', 'apollo13-framework' ),
				'default'     => 'normal',
				'type'        => 'select',
				'options'     => array(
					'normal' => esc_html__( 'Normal', 'apollo13-framework' ),
					'light'  => esc_html__( 'Light', 'apollo13-framework' ),
					'dark'   => esc_html__( 'Dark', 'apollo13-framework' ),
				),
				'required'    => array( 'header_type', '=', 'horizontal' ),
			),
			array(
				'id'       => 'works_list_work_how_to_open',
				'type'     => 'button_set',
				'title'    => esc_html__( 'How to open work', 'apollo13-framework' ),
				'subtitle' => esc_html__( '"In lightbox" will load work content dynamically with JavaScript. Cause of that use JavaScripts plugins is very limited in such works. If you need page builder elements, then use normal mode.', 'apollo13-framework' ),
				'options'  => array(
					'normal'      => esc_html__( 'Normal', 'apollo13-framework' ),
					'in-lightbox' => esc_html__( 'In lightbox', 'apollo13-framework' ),
				),
				'default'  => 'normal',
			),
			array(
				'id'       => 'works_list_work_look',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Work look', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'overlay' => esc_html__( 'Title over photo', 'apollo13-framework' ),
					'under'   => esc_html__( 'Title under photo', 'apollo13-framework' ),
				),
				'default'  => 'overlay',
			),
			array(
				'id'       => 'works_list_work_overlay_title_position',
				'type'     => 'select',
				'title'    => esc_html__( 'Texts position', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'top_left'      => esc_html__( 'Top left', 'apollo13-framework' ),
					'top_center'    => esc_html__( 'Top center', 'apollo13-framework' ),
					'top_right'     => esc_html__( 'Top right', 'apollo13-framework' ),
					'mid_left'      => esc_html__( 'Middle left', 'apollo13-framework' ),
					'mid_center'    => esc_html__( 'Middle center', 'apollo13-framework' ),
					'mid_right'     => esc_html__( 'Middle right', 'apollo13-framework' ),
					'bottom_left'   => esc_html__( 'Bottom left', 'apollo13-framework' ),
					'bottom_center' => esc_html__( 'Bottom center', 'apollo13-framework' ),
					'bottom_right'  => esc_html__( 'Bottom right', 'apollo13-framework' ),
				),
				'default'  => 'top_left',
				'required' => array( 'works_list_work_look', '=', 'overlay' ),
			),
			array(
				'id'       => 'works_list_work_overlay_cover',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Show cover when not hovering', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
				'required' => array( 'works_list_work_look', '=', 'overlay' ),
			),
			array(
				'id'       => 'works_list_work_overlay_cover_hover',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Show cover when hovering', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
				'required' => array( 'works_list_work_look', '=', 'overlay' ),
			),
			array(
				'id'       => 'works_list_work_overlay_gradient',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Show gradient when not hovering', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Its main function is to make texts more visible', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
				'required' => array( 'works_list_work_look', '=', 'overlay' ),
			),
			array(
				'id'       => 'works_list_work_overlay_gradient_hover',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Show gradient when hovering', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Its main function is to make texts more visible', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
				'required' => array( 'works_list_work_look', '=', 'overlay' ),
			),
			array(
				'id'       => 'works_list_work_overlay_texts',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Show texts when not hovering', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
				'required' => array( 'works_list_work_look', '=', 'overlay' ),
			),
			array(
				'id'       => 'works_list_work_overlay_texts_hover',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Show texts when hovering', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
				'required' => array( 'works_list_work_look', '=', 'overlay' ),
			),
			array(
				'id'       => 'works_list_work_under_title_position',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Texts position', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'left'   => esc_html__( 'Left', 'apollo13-framework' ),
					'center' => esc_html__( 'Center', 'apollo13-framework' ),
					'right'  => esc_html__( 'Right', 'apollo13-framework' ),
				),
				'default'  => 'left',
				'required' => array( 'works_list_work_look', '=', 'under' ),
			),
			array(
				'id'       => 'works_list_bricks_hover',
				'type'     => 'select',
				'title'    => esc_html__( 'Hover effect', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Hover on bricks in works list.', 'apollo13-framework' ),
				'options'  => array(
					'cross'      => esc_html__( 'Show cross', 'apollo13-framework' ),
					'drop'       => esc_html__( 'Drop', 'apollo13-framework' ),
					'shift'      => esc_html__( 'Shift', 'apollo13-framework' ),
					'pop'        => esc_html__( 'Pop text', 'apollo13-framework' ),
					'border'     => esc_html__( 'Border', 'apollo13-framework' ),
					'scale-down' => esc_html__( 'Scale down', 'apollo13-framework' ),
					'none'       => esc_html__( 'None', 'apollo13-framework' ),
				),
				'default'  => 'cross',
			),
			array(
				'id'            => 'works_list_items_per_page',
				'type'          => 'slider',
				'title'         => esc_html__( 'Works per page', 'apollo13-framework' ),
				'default'       => 12,
				'min'           => 1,
				'step'          => 1,
				'max'           => 30,
				'display_value' => 'text',
			),
			array(
				'id'       => 'works_list_layout_mode',
				'type'     => 'button_set',
				'title'    => esc_html__( 'How to place items in rows', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'It your items has various heights you may want to start each row of items from new line instead of masonry style.', 'apollo13-framework' ),
				'options'  => array(
					'packery' => esc_html__( 'Masonry', 'apollo13-framework' ),
					'fitRows' => esc_html__( 'Each row from new line', 'apollo13-framework' ),
				),
				'default'  => 'packery',
			),
			array(
				'id'            => 'works_list_brick_columns',
				'type'          => 'slider',
				'title'         => esc_html__( 'Bricks columns', 'apollo13-framework' ),
				'subtitle'      => esc_html__( 'It only affects wider screen resolutions.', 'apollo13-framework' ),
				'default'       => 3,
				'min'           => 1,
				'step'          => 1,
				'max'           => 4,
				'display_value' => 'text',
			),
			array(
				'id'            => 'works_list_bricks_max_width',
				'type'          => 'slider',
				'title'         => esc_html__( 'Max width of bricks content.', 'apollo13-framework' ),
				'subtitle'      => esc_html__( 'Depending on actual screen width and content style used for work, available space for bricks might be smaller, but newer greater then this number.', 'apollo13-framework' ),
				'default'       => 2000,
				'min'           => 200,
				'step'          => 1,
				'max'           => 2500,
				'display_value' => 'text',
			),
			array(
				'id'            => 'works_list_brick_margin',
				'type'          => 'slider',
				'title'         => esc_html__( 'Brick margin', 'apollo13-framework' ),
				'subtitle'      => '',
				'default'       => 10,
				'min'           => 0,
				'step'          => 1,
				'max'           => 100,
				'display_value' => 'text',
			),
			array(
				'id'      => 'works_list_bricks_proportions_size',
				'title'   => esc_html__( 'Choose brick proportion', 'apollo13-framework' ),
				'default' => '0',
				'options' => array(
					'0'    => esc_html__( 'Original size', 'apollo13-framework' ),
					'1/1'  => esc_html__( '1:1', 'apollo13-framework' ),
					'2/3'  => esc_html__( '2:3', 'apollo13-framework' ),
					'3/2'  => esc_html__( '3:2', 'apollo13-framework' ),
					'3/4'  => esc_html__( '3:4', 'apollo13-framework' ),
					'4/3'  => esc_html__( '4:3', 'apollo13-framework' ),
					'9/16' => esc_html__( '9:16', 'apollo13-framework' ),
					'16/9' => esc_html__( '16:9', 'apollo13-framework' ),
				),
				'type'    => 'select',
			),
			array(
				'id'       => 'works_list_lazy_load',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Lazy load', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'works_list_lazy_load_mode',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Lazy load mode', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'button' => esc_html__( 'By clicking button', 'apollo13-framework' ),
					'auto'   => esc_html__( 'On scroll', 'apollo13-framework' ),
				),
				'default'  => 'button',
				'required' => array( 'works_list_lazy_load', '=', 'on' ),
			),
			array(
				'id'       => 'works_list_categories',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Work meta: Categories', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'works_list_header_custom_sidebar',
				'type'     => 'select',
				'title'    => esc_html__( 'Custom header sidebar', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Works only with vertical header.', 'apollo13-framework' ),
				'options'  => $header_sidebars_off_global,
				'default'  => 'off',
				'required' => array( 'header_type', '=', 'vertical' ),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Works list - title bar', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_works_list_title',
		'icon'       => 'fa fa-text-width',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'works_list_title',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Title', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'works_list_title_bar_variant',
				'title'    => esc_html__( 'Title bar variant', 'apollo13-framework' ),
				'type'     => 'button_set',
				'default'  => 'classic',
				'options'  => array(
					'classic'  => esc_html__( 'Classic(to side)', 'apollo13-framework' ),
					'centered' => esc_html__( 'Centered', 'apollo13-framework' ),
				),
				'required' => array( 'works_list_title', '=', 'on' ),
			),
			array(
				'id'       => 'works_list_title_bar_width',
				'title'    => esc_html__( 'Title bar width', 'apollo13-framework' ),
				'type'     => 'button_set',
				'default'  => 'full',
				'options'  => array(
					'full'  => esc_html__( 'Full', 'apollo13-framework' ),
					'boxed' => esc_html__( 'Boxed', 'apollo13-framework' ),
				),
				'required' => array( 'works_list_title', '=', 'on' ),
			),
			array(
				'id'         => 'works_list_title_bar_image',
				'title'      => esc_html__( 'Title bar custom background image', 'apollo13-framework' ),
				'default'    => '',
				'type'       => 'media',
				'full_width' => false,
				'mode'       => 'image',
				'required'   => array( 'works_list_title', '=', 'on' ),
			),
			array(
				'id'       => 'works_list_title_bar_image_fit',
				'title'    => esc_html__( 'How to fit background image', 'apollo13-framework' ),
				'default'  => 'repeat',
				'options'  => array(
					'cover'    => esc_html__( 'Cover', 'apollo13-framework' ),
					'contain'  => esc_html__( 'Contain', 'apollo13-framework' ),
					'fitV'     => esc_html__( 'Fit Vertically', 'apollo13-framework' ),
					'fitH'     => esc_html__( 'Fit Horizontally', 'apollo13-framework' ),
					'center'   => esc_html__( 'Just center', 'apollo13-framework' ),
					'repeat'   => esc_html__( 'Repeat', 'apollo13-framework' ),
					'repeat-x' => esc_html__( 'Repeat X', 'apollo13-framework' ),
					'repeat-y' => esc_html__( 'Repeat Y', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array( 'works_list_title', '=', 'on' ),
			),
			array(
				'id'       => 'works_list_title_bar_parallax',
				'title'    => esc_html__( 'Title bar parallax?', 'apollo13-framework' ),
				'default'  => 'off',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'type'     => 'button_set',
				'required' => array( 'works_list_title', '=', 'on' ),
			),
			array(
				'id'       => 'works_list_title_bar_parallax_type',
				'title'    => esc_html__( 'Parallax type', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'It defines how image will scroll in background while page is scrolled down.', 'apollo13-framework' ),
				'default'  => 'tb',
				'options'  => array(
					"tb"   => esc_html__( 'top to bottom', 'apollo13-framework' ),
					"bt"   => esc_html__( 'bottom to top', 'apollo13-framework' ),
					"lr"   => esc_html__( 'left to right', 'apollo13-framework' ),
					"rl"   => esc_html__( 'right to left', 'apollo13-framework' ),
					"tlbr" => esc_html__( 'top-left to bottom-right', 'apollo13-framework' ),
					"trbl" => esc_html__( 'top-right to bottom-left', 'apollo13-framework' ),
					"bltr" => esc_html__( 'bottom-left to top-right', 'apollo13-framework' ),
					"brtl" => esc_html__( 'bottom-right to top-left', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array(
					array( 'works_list_title', '=', 'on' ),
					array( 'works_list_title_bar_parallax', '=', 'on' ),
				)
			),
			array(
				'id'         => 'works_list_title_bar_parallax_speed',
				'title'      => esc_html__( 'Parallax speed', 'apollo13-framework' ),
				'subtitle'   => esc_html__( 'It will be only used for background that are repeated. If background is set to not repeat this value will be ignored.', 'apollo13-framework' ),
				'default'    => '1.00',
				'type'       => 'slider',
				'min'        => 0,
				'max'        => 1,
				'step'       => 0.01,
				'resolution' => 0.01,
				'required'   => array(
					array( 'works_list_title', '=', 'on' ),
					array( 'works_list_title_bar_parallax', '=', 'on' ),
				)
			),
			array(
				'id'       => 'works_list_title_bar_bg_color',
				'title'    => esc_html__( 'Title bar overlay color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'It will be put above image(if used)', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'works_list_title', '=', 'on' ),
			),
			array(
				'id'       => 'works_list_title_bar_title_color',
				'title'    => esc_html__( 'Titles color', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'works_list_title', '=', 'on' ),
			),
			array(
				'id'       => 'works_list_title_bar_color_1',
				'title'    => esc_html__( 'Second elements color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Used in breadcrumbs.', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'works_list_title', '=', 'on' ),
			),
			array(
				'id'       => 'works_list_title_bar_space_width',
				'title'    => esc_html__( 'Space in top and bottom', 'apollo13-framework' ),
				'default'  => '40',
				'min'      => 0,
				'max'      => 600,
				'step'     => 1,
				'type'     => 'slider',
				'required' => array( 'works_list_title', '=', 'on' ),
			),
			array(
				'id'       => 'works_list_breadcrumbs',
				'title'    => esc_html__( 'Breadcrumbs', 'apollo13-framework' ),
				'default'  => 'on',
				'type'     => 'button_set',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'required' => array( 'works_list_title', '=', 'on' ),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Works list - filter', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_works_list_filter',
		'icon'       => 'fa fa-filter',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'      => 'works_list_filter',
				'type'    => 'button_set',
				'title'   => esc_html__( 'Filter', 'apollo13-framework' ),
				'options' => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default' => 'on',
			),
			array(
				'id'             => 'works_list_filter_padding',
				'type'           => 'spacing',
				'mode'           => 'padding',
				'all'            => false,
				'top'            => true,
				'right'          => false,
				'bottom'         => true,
				'left'           => false,
				'units'          => array( 'px', 'em' ),
				'units_extended' => true,
				'display_units'  => true,
				'title'          => esc_html__( 'Padding', 'apollo13-framework' ),
				'desc'           => '',
				'default'        => array(
					'padding-top'    => '40px',
					'padding-bottom' => '40px',
				),
				'required'       => array( 'works_list_filter', '=', 'on' ),
			),
			array(
				'id'       => 'works_list_filter_bg_color',
				'title'    => esc_html__( 'Background color', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'works_list_filter', '=', 'on' ),
			),
			array(
				'id'       => 'works_list_filter_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Links color', 'apollo13-framework' ),
				'subtitle' => '',
				'required' => array( 'works_list_filter', '=', 'on' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'works_list_filter_hover_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Links hover/active color', 'apollo13-framework' ),
				'subtitle' => '',
				'required' => array( 'works_list_filter', '=', 'on' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'works_list_filter_weight',
				'type'     => 'select',
				'title'    => esc_html__( 'Font weight', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'100'    => esc_html__( '100', 'apollo13-framework' ),
					'200'    => esc_html__( '200', 'apollo13-framework' ),
					'300'    => esc_html__( '300', 'apollo13-framework' ),
					'normal' => esc_html__( 'Normal 400', 'apollo13-framework' ),
					'500'    => esc_html__( '500', 'apollo13-framework' ),
					'600'    => esc_html__( '600', 'apollo13-framework' ),
					'bold'   => esc_html__( 'Bold 700', 'apollo13-framework' ),
					'800'    => esc_html__( '800', 'apollo13-framework' ),
					'900'    => esc_html__( '900', 'apollo13-framework' ),
				),
				'default'  => 'bold',
				'required' => array( 'works_list_filter', '=', 'on' ),
			),
			array(
				'id'       => 'works_list_filter_transform',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Text transform', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'none'      => esc_html__( 'None', 'apollo13-framework' ),
					'uppercase' => esc_html__( 'Uppercase', 'apollo13-framework' ),
				),
				'default'  => 'uppercase',
				'required' => array( 'works_list_filter', '=', 'on' ),
			),
			array(
				'id'       => 'works_list_filter_text_align',
				'title'    => esc_html__( 'Text align', 'apollo13-framework' ),
				'type'     => 'button_set',
				'default'  => 'center',
				'options'  => array(
					'left'   => esc_html__( 'Left', 'apollo13-framework' ),
					'center' => esc_html__( 'Center', 'apollo13-framework' ),
					'right'  => esc_html__( 'Right', 'apollo13-framework' ),
				),
				'required' => array( 'works_list_filter', '=', 'on' ),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Single work', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_single_work',
		'icon'       => 'fa fa-th',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'          => 'work_content_under_header',
				'title'       => esc_html__( 'Hide content under header', 'apollo13-framework' ),
				'description' => esc_html__( 'Only valid when using horizontal header.', 'apollo13-framework' ),
				'default'     => 'off',
				'type'        => 'select',
				'options'     => array(
					'content' => esc_html__( 'Yes hide content', 'apollo13-framework' ),
					'title'   => esc_html__( 'Yes hide content and add top padding to outside title bar.', 'apollo13-framework' ),
					'off'     => esc_html__( 'Turn it off', 'apollo13-framework' ),
				),
				'required'    => array( 'header_type', '=', 'horizontal' ),
			),
			array(
				'id'          => 'work_horizontal_header_color_variant',
				'title'       => esc_html__( 'Header color variant', 'apollo13-framework' ),
				'description' => esc_html__( 'Only valid when using horizontal header.', 'apollo13-framework' ),
				'default'     => 'normal',
				'type'        => 'select',
				'options'     => array(
					'normal' => esc_html__( 'Normal', 'apollo13-framework' ),
					'light'  => esc_html__( 'Light', 'apollo13-framework' ),
					'dark'   => esc_html__( 'Dark', 'apollo13-framework' ),
				),
				'required'    => array( 'header_type', '=', 'horizontal' ),
			),
			array(
				'id'       => 'work_content_layout',
				'type'     => 'select',
				'title'    => esc_html__( 'Content Layout', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'center'        => esc_html__( 'Center fixed width', 'apollo13-framework' ),
					'left'          => esc_html__( 'Left fixed width', 'apollo13-framework' ),
					'left_padding'  => esc_html__( 'Left fixed width + padding', 'apollo13-framework' ),
					'right'         => esc_html__( 'Right fixed width', 'apollo13-framework' ),
					'right_padding' => esc_html__( 'Right fixed width + padding', 'apollo13-framework' ),
					'full_fixed'    => esc_html__( 'Full width + fixed content', 'apollo13-framework' ),
					'full_padding'  => esc_html__( 'Full width + padding', 'apollo13-framework' ),
					'full'          => esc_html__( 'Full width', 'apollo13-framework' ),
				),
				'default'  => 'center',
			),
			array(
				'id'       => 'work_content_categories',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Categories in content', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'work_navigation',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Works navigation', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'work_navigate_by_categories',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Navigate by categories', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'If enabled then navigation in single work will lead to next/previous work in same category. If disabled then it will navigate through works by adding date order.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
				'required' => array( 'work_navigation', '=', 'on' ),
			),
			array(
				'id'       => 'work_similar_works',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Similar works', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Will display list(up to 3 items) of similar works at bottom of of work.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
			),
			array(
				'id'       => 'work_bricks_thumb_video',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Display thumbs instead of video', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Video will be displayed in lightbox if enabled.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Single work - title bar', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_single_work_title',
		'icon'       => 'fa fa-text-width',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'work_title',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Title', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'work_title_bar_position',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Title position', 'apollo13-framework' ),
				'options'  => array(
					'outside' => esc_html__( 'Before content', 'apollo13-framework' ),
//				'inside'  => esc_html__( 'Inside content', 'apollo13-framework' ), //for future if inside title will be also needed
				),
				'default'  => 'outside',
				'required' => array( 'work_title', '=', 'it_is_hidden' ),
				//way to make it hidden, but still have value, as Redux doesn't have "hidden" type of field
			),
			array(
				'id'       => 'work_title_bar_variant',
				'title'    => esc_html__( 'Title bar variant', 'apollo13-framework' ),
				'type'     => 'button_set',
				'default'  => 'classic',
				'options'  => array(
					'classic'  => esc_html__( 'Classic(to side)', 'apollo13-framework' ),
					'centered' => esc_html__( 'Centered', 'apollo13-framework' ),
				),
				'required' => array( 'work_title', '=', 'on' ),
			),
			array(
				'id'       => 'work_title_bar_width',
				'title'    => esc_html__( 'Title bar width', 'apollo13-framework' ),
				'type'     => 'button_set',
				'default'  => 'full',
				'options'  => array(
					'full'  => esc_html__( 'Full', 'apollo13-framework' ),
					'boxed' => esc_html__( 'Boxed', 'apollo13-framework' ),
				),
				'required' => array( 'work_title', '=', 'on' ),
			),
			array(
				'id'         => 'work_title_bar_image',
				'title'      => esc_html__( 'Title bar custom background image', 'apollo13-framework' ),
				'default'    => '',
				'type'       => 'media',
				'full_width' => false,
				'mode'       => 'image',
				'required'   => array( 'work_title', '=', 'on' ),
			),
			array(
				'id'       => 'work_title_bar_image_fit',
				'title'    => esc_html__( 'How to fit background image', 'apollo13-framework' ),
				'default'  => 'repeat',
				'options'  => array(
					'cover'    => esc_html__( 'Cover', 'apollo13-framework' ),
					'contain'  => esc_html__( 'Contain', 'apollo13-framework' ),
					'fitV'     => esc_html__( 'Fit Vertically', 'apollo13-framework' ),
					'fitH'     => esc_html__( 'Fit Horizontally', 'apollo13-framework' ),
					'center'   => esc_html__( 'Just center', 'apollo13-framework' ),
					'repeat'   => esc_html__( 'Repeat', 'apollo13-framework' ),
					'repeat-x' => esc_html__( 'Repeat X', 'apollo13-framework' ),
					'repeat-y' => esc_html__( 'Repeat Y', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array( 'work_title', '=', 'on' ),
			),
			array(
				'id'       => 'work_title_bar_parallax',
				'title'    => esc_html__( 'Title bar parallax?', 'apollo13-framework' ),
				'default'  => 'off',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'type'     => 'button_set',
				'required' => array( 'work_title', '=', 'on' ),
			),
			array(
				'id'       => 'work_title_bar_parallax_type',
				'title'    => esc_html__( 'Parallax type', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'It defines how image will scroll in background while page is scrolled down.', 'apollo13-framework' ),
				'default'  => 'tb',
				'options'  => array(
					"tb"   => esc_html__( 'top to bottom', 'apollo13-framework' ),
					"bt"   => esc_html__( 'bottom to top', 'apollo13-framework' ),
					"lr"   => esc_html__( 'left to right', 'apollo13-framework' ),
					"rl"   => esc_html__( 'right to left', 'apollo13-framework' ),
					"tlbr" => esc_html__( 'top-left to bottom-right', 'apollo13-framework' ),
					"trbl" => esc_html__( 'top-right to bottom-left', 'apollo13-framework' ),
					"bltr" => esc_html__( 'bottom-left to top-right', 'apollo13-framework' ),
					"brtl" => esc_html__( 'bottom-right to top-left', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array(
					array( 'work_title', '=', 'on' ),
					array( 'work_title_bar_parallax', '=', 'on' ),
				)
			),
			array(
				'id'         => 'work_title_bar_parallax_speed',
				'title'      => esc_html__( 'Parallax speed', 'apollo13-framework' ),
				'subtitle'   => esc_html__( 'It will be only used for background that are repeated. If background is set to not repeat this value will be ignored.', 'apollo13-framework' ),
				'default'    => '1.00',
				'type'       => 'slider',
				'min'        => 0,
				'max'        => 1,
				'step'       => 0.01,
				'resolution' => 0.01,
				'required'   => array(
					array( 'work_title', '=', 'on' ),
					array( 'work_title_bar_parallax', '=', 'on' ),
				)
			),
			array(
				'id'       => 'work_title_bar_bg_color',
				'title'    => esc_html__( 'Title bar overlay color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'It will be put above image(if used)', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'work_title', '=', 'on' ),
			),
			array(
				'id'       => 'work_title_bar_title_color',
				'title'    => esc_html__( 'Titles color', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'work_title', '=', 'on' ),
			),
			array(
				'id'       => 'work_title_bar_color_1',
				'title'    => esc_html__( 'Second elements color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Used in breadcrumbs.', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'work_title', '=', 'on' ),
			),
			array(
				'id'       => 'work_title_bar_space_width',
				'title'    => esc_html__( 'Space in top and bottom', 'apollo13-framework' ),
				'default'  => '40',
				'min'      => 0,
				'max'      => 600,
				'step'     => 1,
				'type'     => 'slider',
				'required' => array( 'work_title', '=', 'on' ),
			),
			array(
				'id'       => 'work_breadcrumbs',
				'title'    => esc_html__( 'Breadcrumbs', 'apollo13-framework' ),
				'default'  => 'on',
				'type'     => 'button_set',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'required' => array( 'work_title', '=', 'on' ),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Single work - slider', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_single_work_slider',
		'icon'       => 'fa fa-exchange',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'work_slider_autoplay',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Autoplay', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'If autoplay is on, slider will run on page load. Global setting, but you can change this in each work.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'            => 'work_slider_slide_interval',
				'type'          => 'slider',
				'title'         => esc_html__( 'Slide interval(ms)', 'apollo13-framework' ),
				'subtitle'      => esc_html__( 'Global for all works.', 'apollo13-framework' ),
				'default'       => 7000,
				'min'           => 0,
				'step'          => 1,
				'max'           => 15000,
				'display_value' => 'text',
			),
			array(
				'id'       => 'work_slider_transition_type',
				'type'     => 'select',
				'title'    => esc_html__( 'Transition type', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Animation between slides.', 'apollo13-framework' ),
				'options'  => array(
					'0' => esc_html__( 'None', 'apollo13-framework' ),
					'1' => esc_html__( 'Fade', 'apollo13-framework' ),
					'2' => esc_html__( 'Carousel', 'apollo13-framework' ),
					'3' => esc_html__( 'Zooming', 'apollo13-framework' ),
				),
				'default'  => '2',
			),
			array(
				'id'            => 'work_slider_transition_time',
				'type'          => 'slider',
				'title'         => esc_html__( 'Transition speed(ms)', 'apollo13-framework' ),
				'subtitle'      => esc_html__( 'Speed of transition.', 'apollo13-framework' ) . ' ' . esc_html__( 'Global for all works.', 'apollo13-framework' ),
				'default'       => 600,
				'min'           => 0,
				'step'          => 1,
				'max'           => 10000,
				'display_value' => 'text',
			),
			array(
				'id'       => 'work_slider_thumbs',
				'type'     => 'button_set',
				'title'    => esc_html__( 'List of Thumbs', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Global for all works.', 'apollo13-framework' ) . ' ' . esc_html__( 'Can be overwritten in each work.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),

		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Single work slug', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_work_slug',
		'icon'       => 'fa fa-pencil-square-o',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'cpt_post_type_work',
				'type'     => 'text',
				'title'    => esc_html__( 'Work slug name', 'apollo13-framework' ),
				'subtitle' => wp_kses( __( 'Do not change this if you do not have to. Remember that if you use nice permalinks(eg. <code>yoursite.com/page-about-me</code>, <code>yoursite.com/work/damn-empty/</code>) then <strong>NONE of your static pages</strong> should have same slug as this, or pagination will break and other problems may appear.', 'apollo13-framework' ), $valid_tags ),
				'default'  => 'work',
			),
		)
	) );

//ALBUMS SETTINGS
	Redux::setSection( $opt_name, array(
		'title'           => esc_html__( 'Albums settings', 'apollo13-framework' ),
		'desc'            => '',
		'id'              => 'section_albums',
		'icon'            => 'fa fa-picture-o',
		'priority'        => 8,
		'customizer_only' => $customizer_only,
		'fields'          => array()
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Background', 'apollo13-framework' ),
		'desc'       => esc_html__( 'These will work for Albums list and single album.', 'apollo13-framework' ),
		'id'         => 'subsection_albums_general',
		'icon'       => 'fa fa-picture-o',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'albums_custom_background',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Custom background', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
			),
			array(
				'id'         => 'albums_body_image',
				'type'       => 'media',
				'title'      => esc_html__( 'Background image', 'apollo13-framework' ),
				'full_width' => false,
				'mode'       => 'image',
				'subtitle'   => '',
				'required'   => array( 'albums_custom_background', '=', 'on' ),
			),
			array(
				'id'       => 'albums_body_image_fit',
				'type'     => 'select',
				'title'    => esc_html__( 'How to fit background image', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'cover'    => esc_html__( 'Cover', 'apollo13-framework' ),
					'contain'  => esc_html__( 'Contain', 'apollo13-framework' ),
					'fitV'     => esc_html__( 'Fit Vertically', 'apollo13-framework' ),
					'fitH'     => esc_html__( 'Fit Horizontally', 'apollo13-framework' ),
					'center'   => esc_html__( 'Just center', 'apollo13-framework' ),
					'repeat'   => esc_html__( 'Repeat', 'apollo13-framework' ),
					'repeat-x' => esc_html__( 'Repeat X', 'apollo13-framework' ),
					'repeat-y' => esc_html__( 'Repeat Y', 'apollo13-framework' ),
				),
				'default'  => 'cover',
				'required' => array( 'albums_custom_background', '=', 'on' ),
			),
			array(
				'id'       => 'albums_body_bg_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Background color', 'apollo13-framework' ),
				'subtitle' => '',
				'required' => array( 'albums_custom_background', '=', 'on' ),
				'default'  => '',
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Albums list', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_albums_list',
		'icon'       => 'fa fa-list',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'albums_list_page',
				'type'     => 'select',
				'data'     => 'pages',
				'args'     => array(
					'posts_per_page' => - 1
				),
				'title'    => esc_html__( 'Albums list main page', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'This page will list all your albums and also give main title for "album category" pages.', 'apollo13-framework' ),
			),
			array(
				'id'          => 'albums_list_content_under_header',
				'title'       => esc_html__( 'Hide content under header', 'apollo13-framework' ),
				'description' => esc_html__( 'Only valid when using horizontal header.', 'apollo13-framework' ),
				'default'     => 'off',
				'type'        => 'select',
				'options'     => array(
					'content' => esc_html__( 'Yes hide content', 'apollo13-framework' ),
					'title'   => esc_html__( 'Yes hide content and add top padding to outside title bar.', 'apollo13-framework' ),
					'off'     => esc_html__( 'Turn it off', 'apollo13-framework' ),
				),
				'required'    => array( 'header_type', '=', 'horizontal' ),
			),
			array(
				'id'          => 'albums_list_horizontal_header_color_variant',
				'title'       => esc_html__( 'Header color variant', 'apollo13-framework' ),
				'description' => esc_html__( 'Only valid when using horizontal header.', 'apollo13-framework' ),
				'default'     => 'normal',
				'type'        => 'select',
				'options'     => array(
					'normal' => esc_html__( 'Normal', 'apollo13-framework' ),
					'light'  => esc_html__( 'Light', 'apollo13-framework' ),
					'dark'   => esc_html__( 'Dark', 'apollo13-framework' ),
				),
				'required'    => array( 'header_type', '=', 'horizontal' ),
			),
			array(
				'id'       => 'albums_list_album_look',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Album look', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'overlay' => esc_html__( 'Title over photo', 'apollo13-framework' ),
					'under'   => esc_html__( 'Title under photo', 'apollo13-framework' ),
				),
				'default'  => 'overlay',
			),
			array(
				'id'       => 'albums_list_album_overlay_title_position',
				'type'     => 'select',
				'title'    => esc_html__( 'Texts position', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'top_left'      => esc_html__( 'Top left', 'apollo13-framework' ),
					'top_center'    => esc_html__( 'Top center', 'apollo13-framework' ),
					'top_right'     => esc_html__( 'Top right', 'apollo13-framework' ),
					'mid_left'      => esc_html__( 'Middle left', 'apollo13-framework' ),
					'mid_center'    => esc_html__( 'Middle center', 'apollo13-framework' ),
					'mid_right'     => esc_html__( 'Middle right', 'apollo13-framework' ),
					'bottom_left'   => esc_html__( 'Bottom left', 'apollo13-framework' ),
					'bottom_center' => esc_html__( 'Bottom center', 'apollo13-framework' ),
					'bottom_right'  => esc_html__( 'Bottom right', 'apollo13-framework' ),
				),
				'default'  => 'top_left',
				'required' => array( 'albums_list_album_look', '=', 'overlay' ),
			),
			array(
				'id'       => 'albums_list_album_overlay_cover',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Show cover when not hovering', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
				'required' => array( 'albums_list_album_look', '=', 'overlay' ),
			),
			array(
				'id'       => 'albums_list_album_overlay_cover_hover',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Show cover when hovering', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
				'required' => array( 'albums_list_album_look', '=', 'overlay' ),
			),
			array(
				'id'       => 'albums_list_album_overlay_gradient',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Show gradient when not hovering', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Its main function is to make texts more visible', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
				'required' => array( 'albums_list_album_look', '=', 'overlay' ),
			),
			array(
				'id'       => 'albums_list_album_overlay_gradient_hover',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Show gradient when hovering', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Its main function is to make texts more visible', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
				'required' => array( 'albums_list_album_look', '=', 'overlay' ),
			),
			array(
				'id'       => 'albums_list_album_overlay_texts',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Show texts when not hovering', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
				'required' => array( 'albums_list_album_look', '=', 'overlay' ),
			),
			array(
				'id'       => 'albums_list_album_overlay_texts_hover',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Show texts when hovering', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
				'required' => array( 'albums_list_album_look', '=', 'overlay' ),
			),
			array(
				'id'       => 'albums_list_album_under_title_position',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Texts position', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'left'   => esc_html__( 'Left', 'apollo13-framework' ),
					'center' => esc_html__( 'Center', 'apollo13-framework' ),
					'right'  => esc_html__( 'Right', 'apollo13-framework' ),
				),
				'default'  => 'left',
				'required' => array( 'albums_list_album_look', '=', 'under' ),
			),
			array(
				'id'       => 'albums_list_bricks_hover',
				'type'     => 'select',
				'title'    => esc_html__( 'Hover effect', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Hover on bricks in albums list.', 'apollo13-framework' ),
				'options'  => array(
					'cross'      => esc_html__( 'Show cross', 'apollo13-framework' ),
					'drop'       => esc_html__( 'Drop', 'apollo13-framework' ),
					'shift'      => esc_html__( 'Shift', 'apollo13-framework' ),
					'pop'        => esc_html__( 'Pop text', 'apollo13-framework' ),
					'border'     => esc_html__( 'Border', 'apollo13-framework' ),
					'scale-down' => esc_html__( 'Scale down', 'apollo13-framework' ),
					'none'       => esc_html__( 'None', 'apollo13-framework' ),
				),
				'default'  => 'cross',
			),
			array(
				'id'            => 'albums_list_items_per_page',
				'type'          => 'slider',
				'title'         => esc_html__( 'Albums per page', 'apollo13-framework' ),
				'default'       => 12,
				'min'           => 1,
				'step'          => 1,
				'max'           => 30,
				'display_value' => 'text',
			),
			array(
				'id'       => 'albums_list_layout_mode',
				'type'     => 'button_set',
				'title'    => esc_html__( 'How to place items in rows', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'It your items has various heights you may want to start each row of items from new line instead of masonry style.', 'apollo13-framework' ),
				'options'  => array(
					'packery' => esc_html__( 'Masonry', 'apollo13-framework' ),
					'fitRows' => esc_html__( 'Each row from new line', 'apollo13-framework' ),
				),
				'default'  => 'packery',
			),
			array(
				'id'            => 'albums_list_brick_columns',
				'type'          => 'slider',
				'title'         => esc_html__( 'Bricks columns', 'apollo13-framework' ),
				'subtitle'      => esc_html__( 'It only affects wider screen resolutions.', 'apollo13-framework' ),
				'default'       => 3,
				'min'           => 1,
				'step'          => 1,
				'max'           => 4,
				'display_value' => 'text',
			),
			array(
				'id'            => 'albums_list_bricks_max_width',
				'type'          => 'slider',
				'title'         => esc_html__( 'Max width of bricks content.', 'apollo13-framework' ),
				'subtitle'      => esc_html__( 'Depending on actual screen width and content style used for album, available space for bricks might be smaller, but newer greater then this number.', 'apollo13-framework' ),
				'default'       => 2000,
				'min'           => 200,
				'step'          => 1,
				'max'           => 2500,
				'display_value' => 'text',
			),
			array(
				'id'            => 'albums_list_brick_margin',
				'type'          => 'slider',
				'title'         => esc_html__( 'Brick margin', 'apollo13-framework' ),
				'subtitle'      => '',
				'default'       => 10,
				'min'           => 0,
				'step'          => 1,
				'max'           => 100,
				'display_value' => 'text',
			),
			array(
				'id'      => 'albums_list_bricks_proportions_size',
				'title'   => esc_html__( 'Choose brick proportion', 'apollo13-framework' ),
				'default' => '0',
				'options' => array(
					'0'    => esc_html__( 'Original size', 'apollo13-framework' ),
					'1/1'  => esc_html__( '1:1', 'apollo13-framework' ),
					'2/3'  => esc_html__( '2:3', 'apollo13-framework' ),
					'3/2'  => esc_html__( '3:2', 'apollo13-framework' ),
					'3/4'  => esc_html__( '3:4', 'apollo13-framework' ),
					'4/3'  => esc_html__( '4:3', 'apollo13-framework' ),
					'9/16' => esc_html__( '9:16', 'apollo13-framework' ),
					'16/9' => esc_html__( '16:9', 'apollo13-framework' ),
				),
				'type'    => 'select',
			),
			array(
				'id'       => 'albums_list_lazy_load',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Lazy load', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'albums_list_lazy_load_mode',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Lazy load mode', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'button' => esc_html__( 'By clicking button', 'apollo13-framework' ),
					'auto'   => esc_html__( 'On scroll', 'apollo13-framework' ),
				),
				'default'  => 'button',
				'required' => array( 'albums_list_lazy_load', '=', 'on' ),
			),
			array(
				'id'       => 'albums_list_categories',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Album meta: Categories', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'albums_list_header_custom_sidebar',
				'type'     => 'select',
				'title'    => esc_html__( 'Custom header sidebar', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Works only with vertical header.', 'apollo13-framework' ),
				'options'  => $header_sidebars_off_global,
				'default'  => 'off',
				'required' => array( 'header_type', '=', 'vertical' ),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Albums list - title bar', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_albums_list_title',
		'icon'       => 'fa fa-text-width',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'albums_list_title',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Title', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'albums_list_title_bar_variant',
				'title'    => esc_html__( 'Title bar variant', 'apollo13-framework' ),
				'type'     => 'button_set',
				'default'  => 'classic',
				'options'  => array(
					'classic'  => esc_html__( 'Classic(to side)', 'apollo13-framework' ),
					'centered' => esc_html__( 'Centered', 'apollo13-framework' ),
				),
				'required' => array( 'albums_list_title', '=', 'on' ),
			),
			array(
				'id'       => 'albums_list_title_bar_width',
				'title'    => esc_html__( 'Title bar width', 'apollo13-framework' ),
				'type'     => 'button_set',
				'default'  => 'full',
				'options'  => array(
					'full'  => esc_html__( 'Full', 'apollo13-framework' ),
					'boxed' => esc_html__( 'Boxed', 'apollo13-framework' ),
				),
				'required' => array( 'albums_list_title', '=', 'on' ),
			),
			array(
				'id'         => 'albums_list_title_bar_image',
				'title'      => esc_html__( 'Title bar custom background image', 'apollo13-framework' ),
				'default'    => '',
				'type'       => 'media',
				'full_width' => false,
				'mode'       => 'image',
				'required'   => array( 'albums_list_title', '=', 'on' ),
			),
			array(
				'id'       => 'albums_list_title_bar_image_fit',
				'title'    => esc_html__( 'How to fit background image', 'apollo13-framework' ),
				'default'  => 'repeat',
				'options'  => array(
					'cover'    => esc_html__( 'Cover', 'apollo13-framework' ),
					'contain'  => esc_html__( 'Contain', 'apollo13-framework' ),
					'fitV'     => esc_html__( 'Fit Vertically', 'apollo13-framework' ),
					'fitH'     => esc_html__( 'Fit Horizontally', 'apollo13-framework' ),
					'center'   => esc_html__( 'Just center', 'apollo13-framework' ),
					'repeat'   => esc_html__( 'Repeat', 'apollo13-framework' ),
					'repeat-x' => esc_html__( 'Repeat X', 'apollo13-framework' ),
					'repeat-y' => esc_html__( 'Repeat Y', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array( 'albums_list_title', '=', 'on' ),
			),
			array(
				'id'       => 'albums_list_title_bar_parallax',
				'title'    => esc_html__( 'Title bar parallax?', 'apollo13-framework' ),
				'default'  => 'off',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'type'     => 'button_set',
				'required' => array( 'albums_list_title', '=', 'on' ),
			),
			array(
				'id'       => 'albums_list_title_bar_parallax_type',
				'title'    => esc_html__( 'Parallax type', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'It defines how image will scroll in background while page is scrolled down.', 'apollo13-framework' ),
				'default'  => 'tb',
				'options'  => array(
					"tb"   => esc_html__( 'top to bottom', 'apollo13-framework' ),
					"bt"   => esc_html__( 'bottom to top', 'apollo13-framework' ),
					"lr"   => esc_html__( 'left to right', 'apollo13-framework' ),
					"rl"   => esc_html__( 'right to left', 'apollo13-framework' ),
					"tlbr" => esc_html__( 'top-left to bottom-right', 'apollo13-framework' ),
					"trbl" => esc_html__( 'top-right to bottom-left', 'apollo13-framework' ),
					"bltr" => esc_html__( 'bottom-left to top-right', 'apollo13-framework' ),
					"brtl" => esc_html__( 'bottom-right to top-left', 'apollo13-framework' ),
				),
				'type'     => 'select',
				'required' => array(
					array( 'albums_list_title', '=', 'on' ),
					array( 'albums_list_title_bar_parallax', '=', 'on' ),
				)
			),
			array(
				'id'         => 'albums_list_title_bar_parallax_speed',
				'title'      => esc_html__( 'Parallax speed', 'apollo13-framework' ),
				'subtitle'   => esc_html__( 'It will be only used for background that are repeated. If background is set to not repeat this value will be ignored.', 'apollo13-framework' ),
				'default'    => '1.00',
				'type'       => 'slider',
				'min'        => 0,
				'max'        => 1,
				'step'       => 0.01,
				'resolution' => 0.01,
				'required'   => array(
					array( 'albums_list_title', '=', 'on' ),
					array( 'albums_list_title_bar_parallax', '=', 'on' ),
				)
			),
			array(
				'id'       => 'albums_list_title_bar_bg_color',
				'title'    => esc_html__( 'Title bar overlay color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'It will be put above image(if used)', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'albums_list_title', '=', 'on' ),
			),
			array(
				'id'       => 'albums_list_title_bar_title_color',
				'title'    => esc_html__( 'Titles color', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'albums_list_title', '=', 'on' ),
			),
			array(
				'id'       => 'albums_list_title_bar_color_1',
				'title'    => esc_html__( 'Second elements color', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Used in breadcrumbs.', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'albums_list_title', '=', 'on' ),
			),
			array(
				'id'       => 'albums_list_title_bar_space_width',
				'title'    => esc_html__( 'Space in top and bottom', 'apollo13-framework' ),
				'default'  => '40',
				'min'      => 0,
				'max'      => 600,
				'step'     => 1,
				'type'     => 'slider',
				'required' => array( 'albums_list_title', '=', 'on' ),
			),
			array(
				'id'       => 'albums_list_breadcrumbs',
				'title'    => esc_html__( 'Breadcrumbs', 'apollo13-framework' ),
				'default'  => 'on',
				'type'     => 'button_set',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'required' => array( 'albums_list_title', '=', 'on' ),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Albums list - filter', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_albums_list_filter',
		'icon'       => 'fa fa-filter',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'      => 'albums_list_filter',
				'type'    => 'button_set',
				'title'   => esc_html__( 'Filter', 'apollo13-framework' ),
				'options' => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default' => 'on',
			),
			array(
				'id'             => 'albums_list_filter_padding',
				'type'           => 'spacing',
				'mode'           => 'padding',
				'all'            => false,
				'top'            => true,
				'right'          => false,
				'bottom'         => true,
				'left'           => false,
				'units'          => array( 'px', 'em' ),
				'units_extended' => true,
				'display_units'  => true,
				'title'          => esc_html__( 'Padding', 'apollo13-framework' ),
				'desc'           => '',
				'default'        => array(
					'padding-top'    => '40px',
					'padding-bottom' => '40px',
				),
				'required'       => array( 'albums_list_filter', '=', 'on' ),
			),
			array(
				'id'       => 'albums_list_filter_bg_color',
				'title'    => esc_html__( 'Background color', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'albums_list_filter', '=', 'on' ),
			),
			array(
				'id'       => 'albums_list_filter_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Links color', 'apollo13-framework' ),
				'subtitle' => '',
				'required' => array( 'albums_list_filter', '=', 'on' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'albums_list_filter_hover_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Links hover/active color', 'apollo13-framework' ),
				'subtitle' => '',
				'required' => array( 'albums_list_filter', '=', 'on' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'albums_list_filter_weight',
				'type'     => 'select',
				'title'    => esc_html__( 'Font weight', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'100'    => esc_html__( '100', 'apollo13-framework' ),
					'200'    => esc_html__( '200', 'apollo13-framework' ),
					'300'    => esc_html__( '300', 'apollo13-framework' ),
					'normal' => esc_html__( 'Normal 400', 'apollo13-framework' ),
					'500'    => esc_html__( '500', 'apollo13-framework' ),
					'600'    => esc_html__( '600', 'apollo13-framework' ),
					'bold'   => esc_html__( 'Bold 700', 'apollo13-framework' ),
					'800'    => esc_html__( '800', 'apollo13-framework' ),
					'900'    => esc_html__( '900', 'apollo13-framework' ),
				),
				'default'  => 'bold',
				'required' => array( 'albums_list_filter', '=', 'on' ),
			),
			array(
				'id'       => 'albums_list_filter_transform',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Text transform', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'none'      => esc_html__( 'None', 'apollo13-framework' ),
					'uppercase' => esc_html__( 'Uppercase', 'apollo13-framework' ),
				),
				'default'  => 'uppercase',
				'required' => array( 'albums_list_filter', '=', 'on' ),
			),
			array(
				'id'       => 'albums_list_filter_text_align',
				'title'    => esc_html__( 'Text align', 'apollo13-framework' ),
				'type'     => 'button_set',
				'default'  => 'center',
				'options'  => array(
					'left'   => esc_html__( 'Left', 'apollo13-framework' ),
					'center' => esc_html__( 'Center', 'apollo13-framework' ),
					'right'  => esc_html__( 'Right', 'apollo13-framework' ),
				),
				'required' => array( 'albums_list_filter', '=', 'on' ),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Single album - bricks', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_album_bricks',
		'icon'       => 'fa fa-th',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'          => 'album_content_under_header',
				'title'       => esc_html__( 'Hide content under header', 'apollo13-framework' ),
				'description' => esc_html__( 'Only valid when using horizontal header.', 'apollo13-framework' ),
				'default'     => 'off',
				'type'        => 'select',
				'options'     => array(
					'content' => esc_html__( 'Yes hide content', 'apollo13-framework' ),
					'off'     => esc_html__( 'Turn it off', 'apollo13-framework' ),
				),
				'required'    => array( 'header_type', '=', 'horizontal' ),
			),
			array(
				'id'          => 'album_horizontal_header_color_variant',
				'title'       => esc_html__( 'Header color variant', 'apollo13-framework' ),
				'description' => esc_html__( 'Only valid when using horizontal header.', 'apollo13-framework' ),
				'default'     => 'normal',
				'type'        => 'select',
				'options'     => array(
					'normal' => esc_html__( 'Normal', 'apollo13-framework' ),
					'light'  => esc_html__( 'Light', 'apollo13-framework' ),
					'dark'   => esc_html__( 'Dark', 'apollo13-framework' ),
				),
				'required'    => array( 'header_type', '=', 'horizontal' ),
			),
			array(
				'id'       => 'album_content',
				'type'     => 'select',
				'title'    => esc_html__( 'Content column', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'This will display separate block with title and text about album.', 'apollo13-framework' ),
				'options'  => array(
					'left'  => esc_html__( 'Show on left', 'apollo13-framework' ),
					'right' => esc_html__( 'Show on right', 'apollo13-framework' ),
					'off'   => esc_html__( 'Do not display it', 'apollo13-framework' ),
				),
				'default'  => 'right',
			),
			array(
				'id'       => 'album_content_title',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Title in content', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
				'required' => array( 'album_content', '!=', 'off' ),
			),
			array(
				'id'       => 'album_content_categories',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Categories in content', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
				'required' => array( 'album_content', '!=', 'off' ),
			),
			array(
				'id'       => 'album_navigation',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Albums navigation', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'album_navigate_by_categories',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Navigate by categories', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'If enabled then navigation in single album will lead to next/previous work in same category. If disabled then it will navigate through albums by adding date order.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
				'required' => array( 'album_navigation', '=', 'on' ),
			),
			array(
				'id'       => 'album_bricks_thumb_video',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Display thumbs instead of video', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Video will be displayed in lightbox if enabled.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Single album - bricks filter', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_album_bricks_filter',
		'icon'       => 'fa fa-filter',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'      => 'album_bricks_filter',
				'type'    => 'button_set',
				'title'   => esc_html__( 'Filter', 'apollo13-framework' ),
				'options' => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default' => 'on',
			),
			array(
				'id'             => 'album_bricks_filter_padding',
				'type'           => 'spacing',
				'mode'           => 'padding',
				'all'            => false,
				'top'            => true,
				'right'          => false,
				'bottom'         => true,
				'left'           => false,
				'units'          => array( 'px', 'em' ),
				'units_extended' => true,
				'display_units'  => true,
				'title'          => esc_html__( 'Padding', 'apollo13-framework' ),
				'desc'           => '',
				'default'        => array(
					'padding-top'    => '40px',
					'padding-bottom' => '40px',
				),
				'required'       => array( 'album_bricks_filter', '=', 'on' ),
			),
			array(
				'id'       => 'album_bricks_filter_bg_color',
				'title'    => esc_html__( 'Background color', 'apollo13-framework' ),
				'default'  => '',
				'type'     => 'color_rgba',
				'required' => array( 'album_bricks_filter', '=', 'on' ),
			),
			array(
				'id'       => 'album_bricks_filter_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Links color', 'apollo13-framework' ),
				'subtitle' => '',
				'required' => array( 'album_bricks_filter', '=', 'on' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'album_bricks_filter_hover_color',
				'type'     => 'color_rgba',
				'title'    => esc_html__( 'Links hover/active color', 'apollo13-framework' ),
				'subtitle' => '',
				'required' => array( 'album_bricks_filter', '=', 'on' ),
				'default'  => array(
					'color' => '#000000',
					'alpha' => 1
				),
			),
			array(
				'id'       => 'album_bricks_filter_weight',
				'type'     => 'select',
				'title'    => esc_html__( 'Font weight', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'100'    => esc_html__( '100', 'apollo13-framework' ),
					'200'    => esc_html__( '200', 'apollo13-framework' ),
					'300'    => esc_html__( '300', 'apollo13-framework' ),
					'normal' => esc_html__( 'Normal 400', 'apollo13-framework' ),
					'500'    => esc_html__( '500', 'apollo13-framework' ),
					'600'    => esc_html__( '600', 'apollo13-framework' ),
					'bold'   => esc_html__( 'Bold 700', 'apollo13-framework' ),
					'800'    => esc_html__( '800', 'apollo13-framework' ),
					'900'    => esc_html__( '900', 'apollo13-framework' ),
				),
				'default'  => 'bold',
				'required' => array( 'album_bricks_filter', '=', 'on' ),
			),
			array(
				'id'       => 'album_bricks_filter_transform',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Text transform', 'apollo13-framework' ),
				'subtitle' => '',
				'options'  => array(
					'none'      => esc_html__( 'None', 'apollo13-framework' ),
					'uppercase' => esc_html__( 'Uppercase', 'apollo13-framework' ),
				),
				'default'  => 'uppercase',
				'required' => array( 'album_bricks_filter', '=', 'on' ),
			),
			array(
				'id'       => 'album_bricks_filter_text_align',
				'title'    => esc_html__( 'Text align', 'apollo13-framework' ),
				'type'     => 'button_set',
				'default'  => 'center',
				'options'  => array(
					'left'   => esc_html__( 'Left', 'apollo13-framework' ),
					'center' => esc_html__( 'Center', 'apollo13-framework' ),
					'right'  => esc_html__( 'Right', 'apollo13-framework' ),
				),
				'required' => array( 'album_bricks_filter', '=', 'on' ),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Photo Proofing', 'apollo13-framework' ),
		'id'         => 'subsection_albums_proofing',
		'icon'       => 'fa fa-check',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'proofing_send_email',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Send e-mail when album is accepted', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'If enabled it will send e-mail to when client will mark album as finished.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'       => 'proofing_email',
				'type'     => 'text',
				'title'    => esc_html__( 'E-mail address to use', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'If empty, will use admin site e-mail.', 'apollo13-framework' ),
				'default'  => '',
				'required' => array( 'proofing_send_email', '=', 'on' ),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Single album - slider', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_album_slider',
		'icon'       => 'fa fa-exchange',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'album_slider_autoplay',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Autoplay', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'If autoplay is on, slider will run on page load. Global setting, but you can change this in each album.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),
			array(
				'id'            => 'album_slider_slide_interval',
				'type'          => 'slider',
				'title'         => esc_html__( 'Slide interval(ms)', 'apollo13-framework' ),
				'subtitle'      => esc_html__( 'Global for all albums.', 'apollo13-framework' ),
				'default'       => 7000,
				'min'           => 0,
				'step'          => 1,
				'max'           => 15000,
				'display_value' => 'text',
			),
			array(
				'id'       => 'album_slider_transition_type',
				'type'     => 'select',
				'title'    => esc_html__( 'Transition type', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Animation between slides.', 'apollo13-framework' ),
				'options'  => array(
					'0' => esc_html__( 'None', 'apollo13-framework' ),
					'1' => esc_html__( 'Fade', 'apollo13-framework' ),
					'2' => esc_html__( 'Carousel', 'apollo13-framework' ),
					'3' => esc_html__( 'Zooming', 'apollo13-framework' ),
				),
				'default'  => '2',
			),
			array(
				'id'            => 'album_slider_transition_time',
				'type'          => 'slider',
				'title'         => esc_html__( 'Transition speed(ms)', 'apollo13-framework' ),
				'subtitle'      => esc_html__( 'Speed of transition.', 'apollo13-framework' ) . ' ' . esc_html__( 'Global for all albums.', 'apollo13-framework' ),
				'default'       => 600,
				'min'           => 0,
				'step'          => 1,
				'max'           => 10000,
				'display_value' => 'text',
			),
			array(
				'id'       => 'album_slider_thumbs',
				'type'     => 'button_set',
				'title'    => esc_html__( 'List of Thumbs', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'Global for all albums.', 'apollo13-framework' ) . ' ' . esc_html__( 'Can be overwritten in each album.', 'apollo13-framework' ),
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'on',
			),

		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Single album social icons', 'apollo13-framework' ),
		'desc'       => esc_html__( 'If you are using AddToAny plugin for sharing, then you should check these options.', 'apollo13-framework' ),
		'id'         => 'subsection_album_socials',
		'icon'       => 'fa fa-facebook-official',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'      => 'album_social_icons',
				'type'    => 'button_set',
				'title'   => esc_html__( 'Use social icons in albums', 'apollo13-framework' ),
				'options' => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default' => 'on',
			),
			array(
				'id'       => 'album_share_type',
				'type'     => 'button_set',
				'title'    => esc_html__( 'Share link to album or to attachment page', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'When using share plugin choose one way of sharing. More details in documentation.', 'apollo13-framework' ),
				'options'  => array(
					'album'           => esc_html__( 'Album', 'apollo13-framework' ),
					'attachment_page' => esc_html__( 'Attachment page', 'apollo13-framework' ),
				),
				'default'  => 'album',
				'required' => array( 'album_social_icons', '=', 'on' ),
			),
		)
	) );

	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Single album slug', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_album_slug',
		'icon'       => 'fa fa-pencil-square-o',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'cpt_post_type_album',
				'type'     => 'text',
				'title'    => esc_html__( 'Album slug name', 'apollo13-framework' ),
				'subtitle' => wp_kses( __( 'Do not change this if you do not have to. Remember that if you use nice permalinks(eg. <code>yoursite.com/page-about-me</code>, <code>yoursite.com/album/damn-empty/</code>) then <strong>NONE of your static pages</strong> should have same slug as this, or pagination will break and other problems may appear.', 'apollo13-framework' ), $valid_tags ),
				'default'  => 'album',
			),
		)
	) );

//CUSTOM CSS
	Redux::setSection( $opt_name, array(
		'title'           => esc_html__( 'Custom CSS', 'apollo13-framework' ),
		'desc'            => '',
		'id'              => 'section_custom_css',
		'icon'            => 'fa fa-css3',
		'priority'        => 9,
		'customizer_only' => $customizer_only,
		'fields'          => array(

			array(
				'id'    => 'custom_css',
				'type'  => 'textarea',
				'title' => esc_html__( 'Custom CSS', 'apollo13-framework' ),
			)
		)
	) );

//ADD SIDEBARS
	Redux::setSection( $opt_name, array(
		'title'           => esc_html__( 'Add custom Sidebars', 'apollo13-framework' ),
		'desc'            => esc_html__( 'You can add here custom sidebars that can be used on pages for example.', 'apollo13-framework' ),
		'id'              => 'section_sidebars',
		'icon'            => 'fa fa-columns',
		'priority'        => 10,
		'customizer_only' => $customizer_only,
		'fields'          => array(

			array(
				'id'       => 'custom_sidebars',
				'type'     => 'multi_text',
				'title'    => esc_html__( 'Add custom sidebars', 'apollo13-framework' ),
				'subtitle' => '',
				'desc'     => '',
				'default'  => array(),
			),
		)
	) );

//miscellaneous
	Redux::setSection( $opt_name, array(
		'title'           => esc_html__( 'Miscellaneous', 'apollo13-framework' ),
		'desc'            => '',
		'id'              => 'section_miscellaneous',
		'icon'            => 'fa fa-question',
		'priority'        => 11,
		'customizer_only' => $customizer_only,
		'fields'          => array(),
	) );
	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'People Custom Post Type', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'miscellaneous_sub-people',
		'icon'       => 'fa fa-users',
		'subsection' => true,
		'fields'     => array(
			array(
				'title'   => esc_html__( 'Social icons - color', 'apollo13-framework' ),
				'id'      => 'people_socials_color',
				'default' => 'semi-transparent',
				'options' => array(
					'black'            => esc_html__( 'Black', 'apollo13-framework' ),
					'color'            => esc_html__( 'Color', 'apollo13-framework' ),
					'white'            => esc_html__( 'White', 'apollo13-framework' ),
					'semi-transparent' => esc_html__( 'Semi transparent', 'apollo13-framework' ),
				),
				'type'    => 'select',
			),
			array(
				'title'   => esc_html__( 'Social icons - hover color', 'apollo13-framework' ),
				'id'      => 'people_socials_color_hover',
				'default' => 'color',
				'options' => array(
					'black'            => esc_html__( 'Black', 'apollo13-framework' ),
					'color'            => esc_html__( 'Color', 'apollo13-framework' ),
					'white'            => esc_html__( 'White', 'apollo13-framework' ),
					'semi-transparent' => esc_html__( 'Semi transparent', 'apollo13-framework' ),
				),
				'type'    => 'select',
			),


		)
	) );
	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Apollo13 Image Resize', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_a13ir',
		'icon'       => 'fa fa-file-image-o',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'            => 'a13ir_image_quality',
				'type'          => 'slider',
				'title'         => esc_html__( 'Image quality', 'apollo13-framework' ),
				'subtitle'      => esc_html__( 'Use it to change quality of images used across theme. 100 is maximum quality.', 'apollo13-framework' ),
				'default'       => 90,
				'min'           => 1,
				'step'          => 1,
				'max'           => 100,
				'display_value' => 'text',
			),
		)
	) );
	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Address bar', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_address_bar',
		'icon'       => 'fa fa-external-link',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'anchors_in_bar',
				'title'    => esc_html__( 'Display anchors in address bar', 'apollo13-framework' ),
				'subtitle' => sprintf( esc_html__( 'If disabled it will not show anchors, in address bar of your browser, when they are clicked or entered. So address like %1$s will be displayed as %2$s.', 'apollo13-framework' ),'<code>https://apollo13themes.com/rife/#downloads</code>','<code>https://apollo13themes.com/rife/</code>'),
				'type'     => 'button_set',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
			),
		)
	) );
	Redux::setSection( $opt_name, array(
		'title'      => esc_html__( 'Writing effect', 'apollo13-framework' ),
		'desc'       => '',
		'id'         => 'subsection_writing_effect',
		'icon'       => 'fa fa-pencil',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'writing_effect_mobile',
				'title'    => esc_html__( 'Writing effect on mobile', 'apollo13-framework' ),
				'subtitle' => esc_html__( 'If disabled it will show all written lines as separate paragraphs on small devices. It is good to disable it to save CPU of your user devices, and to remove "jumping screen" effect on smaller screens.', 'apollo13-framework' ),
				'type'     => 'button_set',
				'options'  => array(
					'on'  => esc_html__( 'Enable', 'apollo13-framework' ),
					'off' => esc_html__( 'Disable', 'apollo13-framework' ),
				),
				'default'  => 'off',
			),
		)
	) );


	/*
 * <--- END SECTIONS
 */
}
apollo13framework_setup_theme_options();