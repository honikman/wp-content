<?php
/**
 * Functions that prints various elements across layout
 */


if(!function_exists('apollo13framework_page_preloader')){
	/**
	 * Prints page preloader screen
	 */
	function apollo13framework_page_preloader(){
        global $apollo13framework_a13;

        if($apollo13framework_a13->get_option( 'preloader' ) === 'on'){
	        $class_attr = '';
	        if($apollo13framework_a13->get_option( 'preloader_hide_event' )==='ready'){
		        $class_attr = 'onReady';
	        }
        ?>
<div id="preloader" class="<?php echo esc_attr($class_attr); ?>">
    <div class="preload-content">
        <div class="preloader-animation"><?php apollo13framework_preloader_animation_html($apollo13framework_a13->get_option(  'preloader_type' )); ?></div>
        <a class="skip-preloader icon-cross" href="#"></a>
    </div>
</div>
        <?php
        }
    }
}



if(!function_exists('apollo13framework_preloader_animation_html')){
	/**
	 * Prints one of few animations for preloader screen
	 *
	 * @param string $animation name of animation
	 */
	function apollo13framework_preloader_animation_html($animation) {
		switch($animation){
			case $animation === 'circle_illusion':
				?>
				<div class='blob-wrap'>
					<div class='translate'>
						<div class='scale'></div>
					</div>
				</div>
				<div class='blob-wrap'>
					<div class='translate'>
						<div class='scale'></div>
					</div>
				</div>
				<div class='blob-wrap'>
					<div class='translate'>
						<div class='scale'></div>
					</div>
				</div>
				<div class='blob-wrap'>
					<div class='translate'>
						<div class='scale'></div>
					</div>
				</div>
				<div class='blob-wrap'>
					<div class='translate'>
						<div class='scale'></div>
					</div>
				</div>
				<div class='blob-wrap'>
					<div class='translate'>
						<div class='scale'></div>
					</div>
				</div>
				<div class='blob-wrap'>
					<div class='translate'>
						<div class='scale'></div>
					</div>
				</div>
				<div class='blob-wrap'>
					<div class='translate'>
						<div class='scale'></div>
					</div>
				</div>
				<div class='blob-wrap'>
					<div class='translate'>
						<div class='scale'></div>
					</div>
				</div>
				<?php
				break;

			case $animation === 'square_of_squares':
				?>
				<div class="sos-load">
					<div class="blockcont">
						<div class="sos-block"></div>
						<div class="sos-block"></div>
						<div class="sos-block"></div>

						<div class="sos-block"></div>
						<div class="sos-block"></div>
						<div class="sos-block"></div>

						<div class="sos-block"></div>
						<div class="sos-block"></div>
						<div class="sos-block"></div>

					</div>
				</div>
				<?php
				break;

			case $animation === 'plus_minus':
				?>
				<div class="pm-top">
					<div class="square">
						<div class="square">
							<div class="square">
								<div class="square">
									<div class="square"><div class="square">

										</div></div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="pm-bottom">
					<div class="square">
						<div class="square">
							<div class="square">
								<div class="square">
									<div class="square"><div class="square">
										</div></div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="pm-left">
					<div class="square">
						<div class="square">
							<div class="square">
								<div class="square">
									<div class="square"><div class="square">
										</div></div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="pm-right">
					<div class="square">
						<div class="square">
							<div class="square">
								<div class="square">
									<div class="square"><div class="square">
										</div></div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php
				break;

			case $animation === 'hand':
				?>
				<div class="hand-loading">
					<div class="finger finger-1">
						<div class="finger-item">
							<span></span><i></i>
						</div>
					</div>
					<div class="finger finger-2">
						<div class="finger-item">
							<span></span><i></i>
						</div>
					</div>
					<div class="finger finger-3">
						<div class="finger-item">
							<span></span><i></i>
						</div>
					</div>
					<div class="finger finger-4">
						<div class="finger-item">
							<span></span><i></i>
						</div>
					</div>
					<div class="last-finger">
						<div class="last-finger-item"><i></i></div>
					</div>
				</div>
				<?php
				break;

			case $animation === 'blurry':
				?>
				<div class="blurry-box"></div>
				<?php
				break;

			case $animation === 'arcs':
				?>
				<div class="arc">
					<div class="arc-cube"></div>
				</div>
				<?php
				break;

			case $animation === 'tetromino':
				?>
				<div class='tetrominos'>
					<div class='tetromino box1'></div>
					<div class='tetromino box2'></div>
					<div class='tetromino box3'></div>
					<div class='tetromino box4'></div>
				</div>
				<?php
				break;

			case $animation === 'infinity':
				?>
				<div class='infinity-container'>
					<div class='inf-lt'></div>
					<div class='inf-rt'></div>
					<div class='inf-lb'></div>
					<div class='inf-rb'></div>
				</div>
				<?php
				break;

			case $animation === 'cloud_circle':
				?>
				<div class='cloud-circle-container'>
					<div class='cloud-circle'>
						<div class='inner'></div>
					</div>
					<div class='cloud-circle'>
						<div class='inner'></div>
					</div>
					<div class='cloud-circle'>
						<div class='inner'></div>
					</div>
					<div class='cloud-circle'>
						<div class='inner'></div>
					</div>
					<div class='cloud-circle'>
						<div class='inner'></div>
					</div>
				</div>
				<?php
				break;

			case $animation === 'dots':
				?>
				<div class='dots-loading'>
					<div class='bullet'></div>
					<div class='bullet'></div>
					<div class='bullet'></div>
					<div class='bullet'></div>
				</div>
				<?php
				break;

			case $animation === 'jet_pack_man':
				?>
				<div class="jet-pack-man-body">
				    <span>
				        <span></span>
				        <span></span>
				        <span></span>
				        <span></span>
				    </span>
					<div class="jet-pack-man-base">
						<span></span>
						<div class="jet-pack-man-face"></div>
					</div>
				</div>
				<div class="longfazers">
					<span></span>
					<span></span>
					<span></span>
					<span></span>
				</div>
				<?php
				break;

			case $animation === 'circle':
				?>
				<div class="circle-loader">Loading...</div>
				<?php
				break;

			default:
				?>
				<div class="pace-progress"><div class="pace-progress-inner"></div ></div>
		        <div class="pace-activity"></div>
				<?php
		}
	}
}



if(!function_exists('apollo13framework_page_background')){
	/**
	 * Prints page background element
	 */
	function apollo13framework_page_background(){
        ?>
        <div class="page-background to-move"></div>
        <?php
    }
}



if(!function_exists('apollo13framework_theme_borders')){
	/**
	 * Prints theme border if enabled
	 */
	function apollo13framework_theme_borders(){
		global $apollo13framework_a13;

		if($apollo13framework_a13->get_option( 'layout_type' ) === 'bordered') {
			?>
			<div class="theme-borders">
				<div class="top-border"></div>
				<div class="right-border"></div>
				<div class="bottom-border"></div>
				<div class="left-border"></div>
			</div>
			<?php
		}
    }
}



if(!function_exists('apollo13framework_bg_fit_helper')){
	/**
	 * Translates shortcuts to inline CSS for positioning background
	 *
	 * @param string $option short name
	 *
	 * @return string   inline CSS
	 */
	function apollo13framework_bg_fit_helper($option){
        static $options = array(
            'center'     => 'background-size: auto; background-repeat: no-repeat; background-position: 50% 50%;',
            'cover'      => 'background-size: cover; background-repeat: no-repeat; background-position: 50% 50%;',
            'contain'    => 'background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;',
            'fitV'       => 'background-size: 100% auto; background-repeat: no-repeat; background-position: 50% 50%;',
            'fitH'       => 'background-size:  auto 100%; background-repeat: no-repeat; background-position: 50% 50%;',
            'repeat'     => 'background-repeat: repeat; background-size:auto; background-position: 0 0;',
            'repeat-x'   => 'background-repeat: repeat-x; background-size:auto; background-position: 0 0;',
            'repeat-y'   => 'background-repeat: repeat-y; background-size:auto; background-position: 0 0;',
        );

        return $options[$option];
    }
}



if(!function_exists('apollo13framework_search_form')){
	/**
	 * Prints search form with custom id for each displayed form one one page
	 *
	 * @param string $form original form HTML
	 * @param bool $with_dynamic_results
	 *
	 * @return string HTML
	 */
	function apollo13framework_search_form(
		/** @noinspection PhpUnusedParameterInspection */ $form, $with_dynamic_results = false) {
        static $search_id = 1;
	    global $apollo13framework_a13;

	    $wpml_active = defined( 'ICL_SITEPRESS_VERSION');
		$live_search = $with_dynamic_results ? 'data-swplive="true" ' : '';
	    $shop_search_option = $apollo13framework_a13->get_option( 'shop_search' );
	    $shop_search = $shop_search_option === 'on';
        $helper_search = get_search_query() == '' ? true : false;
        $field_search = '<input' .
            ' placeholder="' . esc_attr( esc_html__('Search &hellip;', 'apollo13-framework' )) . '" ' .
            'type="search" name="s" id="s' . $search_id . '" '.$live_search.'value="' .
            esc_attr( $helper_search ? '' : get_search_query() ) .
            '" />';

        $form = '
                <form class="search-form" role="search" method="get" action="' . esc_url( home_url( '/' ) ) . '" >
                    <fieldset class="semantic">
                        ' . $field_search . '
                        <em class="icon-search"></em>
                        <input type="submit" id="searchsubmit' . $search_id . '" title="'. esc_attr( esc_html__( 'Search', 'apollo13-framework' ) ) .'" value="'. esc_attr( esc_html__( 'Search', 'apollo13-framework' ) ) .'" />
                        '.($shop_search? '<input type="hidden" value="product" name="post_type">' : '').'
                        '.($wpml_active? ('<input type="hidden" name="lang" value="'.ICL_LANGUAGE_CODE.'"/>') : '').'
                    </fieldset>
                </form>';

        //next call will have different ID
        $search_id++;
        return $form;
    }
}
add_filter( 'get_search_form','apollo13framework_search_form' );



if(!function_exists('apollo13framework_get_title_bar')){
	/**
	 * Prints Page title bar
	 *
	 * @param string $called_position   position of title bar in page
	 * @param string $title             title of page
	 * @param string $subtitle          subtitle of page
	 *
	 * @return string|void
	 */
	function apollo13framework_get_title_bar( $called_position = 'outside', $title = '', $subtitle = '') {
        global $apollo13framework_a13;

        $page_type = apollo13framework_what_page_type_is_it();
        $home = $page_type['home'];
		$title_bar_option = 'on';
		$tb_classes = '';
		$data_attr = '';
        $position = 'outside';
		$title_bar_variant = 'classic';
		$title_bar_width = 'full';
        $_subtitle = '';
		$display_breadcrumbs = true;
		$has_effect = true;
	    $is_password_protected = post_password_required();

        //prepare variables
        //albums list - type of page so first in list
        if($page_type['albums_list']){
	        $title_bar_option = $apollo13framework_a13->get_option( 'albums_list_title' );
	        //position is not overwritten
	        $display_breadcrumbs = $apollo13framework_a13->get_option( 'albums_list_breadcrumbs' ) === 'on';
	        $title_bar_variant = $apollo13framework_a13->get_option( 'albums_list_title_bar_variant' );
	        $title_bar_width = $apollo13framework_a13->get_option( 'albums_list_title_bar_width' );

	        //parallax
	        $parallax = $apollo13framework_a13->get_option( 'albums_list_title_bar_parallax' ) === 'on';

	        if ( $parallax ) {
		        $parallax_type = $apollo13framework_a13->get_option( 'albums_list_title_bar_parallax_type' );
		        $parallax_speed = $apollo13framework_a13->get_option( 'albums_list_title_bar_parallax_speed' );
		        $tb_classes .= ' a13-parallax';
		        $data_attr .= ' data-a13-parallax-type="'.esc_attr($parallax_type).'" data-a13-parallax-speed="'.esc_attr((float)$parallax_speed).'"';
	        }
        }
		//works list - before page cause it is also page type!
        elseif($page_type['works_list']){
	        $title_bar_option = $apollo13framework_a13->get_option( 'works_list_title' );
	        //position is not overwritten
	        $display_breadcrumbs = $apollo13framework_a13->get_option( 'works_list_breadcrumbs' ) === 'on';
	        $title_bar_variant = $apollo13framework_a13->get_option( 'works_list_title_bar_variant' );
	        $title_bar_width = $apollo13framework_a13->get_option( 'works_list_title_bar_width' );

	        //parallax
	        $parallax = $apollo13framework_a13->get_option( 'works_list_title_bar_parallax' ) === 'on';

	        if ( $parallax ) {
		        $parallax_type = $apollo13framework_a13->get_option( 'works_list_title_bar_parallax_type' );
		        $parallax_speed = $apollo13framework_a13->get_option( 'works_list_title_bar_parallax_speed' );
		        $tb_classes .= ' a13-parallax';
		        $data_attr .= ' data-a13-parallax-type="'.esc_attr($parallax_type).'" data-a13-parallax-speed="'.esc_attr((float)$parallax_speed).'"';
	        }
        }
        //shop product
        elseif($page_type['product']){
	        $position = false; //we don't display our title bar there
        }
        //cart and others not sidebar/title pages of woocommerce
        elseif( ( $page_type['shop'] && !apollo13framework_is_woocommerce_sidebar_page() ) ||
                //wish list
                ( class_exists( 'YITH_WCWL' ) && (get_the_ID() === (int)yith_wcwl_object_id( get_option( 'yith_wcwl_wishlist_page_id' ) ) ) ) ){

	        $title_bar_option = $apollo13framework_a13->get_option( 'shop_no_major_pages_title' );
	        //position is not overwritten
	        $display_breadcrumbs = $apollo13framework_a13->get_option( 'shop_no_major_pages_breadcrumbs' ) === 'on';
	        $title_bar_variant = $apollo13framework_a13->get_option( 'shop_no_major_pages_title_bar_variant' );
	        $title_bar_width = $apollo13framework_a13->get_option( 'shop_no_major_pages_title_bar_width' );

	        //parallax
	        $parallax = $apollo13framework_a13->get_option( 'shop_no_major_pages_title_bar_parallax' ) === 'on';

	        if ( $parallax ) {
		        $parallax_type = $apollo13framework_a13->get_option( 'shop_no_major_pages_title_bar_parallax_type' );
		        $parallax_speed = $apollo13framework_a13->get_option( 'shop_title_bar_parallax_speed' );
		        $tb_classes .= ' a13-parallax';
		        $data_attr .= ' data-a13-parallax-type="'.esc_attr($parallax_type).'" data-a13-parallax-speed="'.esc_attr((float)$parallax_speed).'"';
	        }
        }
        //shop
        elseif($page_type['shop']){
	        $title_bar_option = $apollo13framework_a13->get_option( 'shop_title' );
	        //position is not overwritten
	        $display_breadcrumbs = $apollo13framework_a13->get_option( 'shop_breadcrumbs' ) === 'on';
	        $title_bar_variant = $apollo13framework_a13->get_option( 'shop_title_bar_variant' );
	        $title_bar_width = $apollo13framework_a13->get_option( 'shop_title_bar_width' );

	        //parallax
	        $parallax = $apollo13framework_a13->get_option( 'shop_title_bar_parallax' ) === 'on';

	        if ( $parallax ) {
		        $parallax_type = $apollo13framework_a13->get_option( 'shop_title_bar_parallax_type' );
		        $parallax_speed = $apollo13framework_a13->get_option( 'shop_title_bar_parallax_speed' );
		        $tb_classes .= ' a13-parallax';
		        $data_attr .= ' data-a13-parallax-type="'.esc_attr($parallax_type).'" data-a13-parallax-speed="'.esc_attr((float)$parallax_speed).'"';
	        }
        }
        //blog type
        elseif($page_type['blog_type']){
	        $title_bar_option = $apollo13framework_a13->get_option( 'blog_title' );
	        //position is not overwritten
	        $display_breadcrumbs = $apollo13framework_a13->get_option( 'blog_breadcrumbs' ) === 'on';
	        $title_bar_variant = $apollo13framework_a13->get_option( 'blog_title_bar_variant' );
	        $title_bar_width = $apollo13framework_a13->get_option( 'blog_title_bar_width' );

	        //parallax
	        $parallax = $apollo13framework_a13->get_option( 'blog_title_bar_parallax' ) === 'on';

	        if ( $parallax ) {
		        $parallax_type = $apollo13framework_a13->get_option( 'blog_title_bar_parallax_type' );
		        $parallax_speed = $apollo13framework_a13->get_option( 'blog_title_bar_parallax_speed' );
		        $tb_classes .= ' a13-parallax';
		        $data_attr .= ' data-a13-parallax-type="'.esc_attr($parallax_type).'" data-a13-parallax-speed="'.esc_attr((float)$parallax_speed).'"';
	        }
        }
        elseif($is_password_protected){
	        $position = 'outside';
	        $display_breadcrumbs = false;
	        $title_bar_variant = 'centered';
	        $has_effect = false;
        }
        //attachments page
        elseif($page_type['attachment']){
	        $position = 'inside';
        }
		//album
        elseif($page_type['album']){
	        $position = false; //we don't display our title bar there
        }
        //pages, posts, works
        elseif($page_type['page'] || $page_type['post'] || $page_type['work']){
            $meta_id = get_the_ID();
            $_subtitle = $apollo13framework_a13->get_meta('_subtitle', $meta_id);
            $title_bar_option = $apollo13framework_a13->get_meta('_title_bar_settings', $meta_id);
			//if post was not "edited" yet, then use default settings
	        if($title_bar_option === ''){
		        $title_bar_option = 'global';
	        }

            //three way check which options to apply to title bar
            if( $title_bar_option === 'global' ){
	            if( $page_type['page'] ){
		            $post_type = 'page';
	            }
	            elseif( $page_type['post'] ){
		            $post_type = 'post';
	            }
	            else{
		            $post_type = 'work';
	            }

	            $title_bar_option    = $apollo13framework_a13->get_option( $post_type . '_title' );
	            $position            = $apollo13framework_a13->get_option( $post_type . '_title_bar_position' );
	            $title_bar_variant   = $apollo13framework_a13->get_option( $post_type . '_title_bar_variant' );
	            $title_bar_width     = $apollo13framework_a13->get_option( $post_type . '_title_bar_width' );
	            $display_breadcrumbs = $apollo13framework_a13->get_option( $post_type . '_breadcrumbs' ) === 'on';

	            //parallax
	            $parallax = $apollo13framework_a13->get_option( $post_type.'_title_bar_parallax' ) === 'on';

	            if ( $parallax ) {
		            $parallax_type = $apollo13framework_a13->get_option( $post_type.'_title_bar_parallax_type' );
		            $parallax_speed = $apollo13framework_a13->get_option( $post_type.'_title_bar_parallax_speed' );
		            $tb_classes .= ' a13-parallax';
		            $data_attr .= ' data-a13-parallax-type="'.esc_attr($parallax_type).'" data-a13-parallax-speed="'.esc_attr((float)$parallax_speed).'"';
	            }
            }
            else{
                //use settings from this page
                $position = $apollo13framework_a13->get_meta('_title_bar_position', $meta_id);
	            $title_bar_variant = $apollo13framework_a13->get_meta('_title_bar_variant', $meta_id);
	            $title_bar_width = $apollo13framework_a13->get_meta('_title_bar_width', $meta_id);
	            $display_breadcrumbs = $apollo13framework_a13->get_meta('_breadcrumbs', $meta_id) === 'on';

	            //parallax
		        $parallax = $apollo13framework_a13->get_meta('_title_bar_parallax', $meta_id) === 'on';

		        if ( $parallax ) {
			        $parallax_type = $apollo13framework_a13->get_meta('_title_bar_parallax_type', $meta_id);
			        $parallax_speed = $apollo13framework_a13->get_meta('_title_bar_parallax_speed', $meta_id);
			        $tb_classes .= ' a13-parallax';
			        $data_attr .= ' data-a13-parallax-type="'.esc_attr($parallax_type).'" data-a13-parallax-speed="'.esc_attr((float)$parallax_speed).'"';
		        }
            }
        }
		elseif($page_type['404']){
			$position = 'outside';
			$display_breadcrumbs = false;
			$title_bar_variant = 'centered';
		}


        //is it OFF?
        if(!apollo13framework_is_no_property_page() && !$is_password_protected){ //checks if page can have meta fields
            if($title_bar_option === 'off'){
	            return '';
            }
        }


        //check in which place we called for title bar(inside/outside content)
		if ( $position !== $called_position ) {
			return '';
		}

		//breadcrumbs
		$breadcrumbs_on = function_exists('bcn_display') && $display_breadcrumbs;

        //subtitle
        $subtitle    = empty($subtitle)? $_subtitle : $subtitle;
        $subtitle_on = strlen($subtitle);

        //title bar classes
		$tb_classes .= $subtitle_on? ' subtitle' : '';
		$tb_classes .= ' '.$position;
		$tb_classes .= $called_position === 'inside' ? '' : ' title_bar_variant_'.$title_bar_variant;
		$tb_classes .= $called_position === 'inside' ? '' : ' title_bar_width_'.$title_bar_width;
		$tb_classes .= $has_effect ? ' has-effect' : '';


		//use passed $title
		if(!empty( $title )){
			//change nothing
		}
		elseif(apollo13framework_is_woocommerce_products_list_page()){
			if(is_product_category()){
				$title = woocommerce_page_title(false);
			}
			else{
				$title = get_the_title(wc_get_page_id( 'shop' ));
			}
		}
		//album or work
		elseif ( $page_type['album'] || $page_type['work'] ){
			$title = get_the_title();
		}
		//blog
		elseif ( $home ){
			if(get_option('page_for_posts') === '0'){
				$title =  esc_html__( 'Blog', 'apollo13-framework' );
			}
			else{
				$title = get_the_title(get_option('page_for_posts'));
			}
		}
		//pages, blog post, etc.
		else{
			$title = get_the_title();
		}

		$html = '';

		if($position === 'inside'){
			$html .= apollo13framework_get_top_image_video(false, array('full_size' => true)); //so small images will look good instead of being stretched
		}

	    $html .= '<header class="title-bar'. esc_attr($tb_classes).'"'.$data_attr.'><div class="overlay-color"><div class="in">';

		$post_meta = '';
		if($page_type['post'] && !$is_password_protected){
			$post_meta = apollo13framework_post_meta_under_content() . apollo13framework_post_meta_above_content();
		}

		if($title_bar_variant === 'classic' && $called_position === 'outside'){
			$html .= '<div class="titles">';
			if(strlen($post_meta)){
				$html .= '<div class="metas">'.$post_meta.'</div>';
			}
		}
		else{
			if(strlen($post_meta)){
				$html .= '<div class="metas">'.$post_meta.'</div>';
			}
			$html .= '<div class="titles">';
		}

        //subtitle
        if($subtitle_on){
            $html .= '<h2>'.$subtitle.'</h2>';
        }

		//main title
		$html .= '<h1 class="page-title">'.$title.'</h1>';//sometimes we add html here, so don't escape!

		$html .='</div>';//.titles

		//breadcrumbs
		if($breadcrumbs_on){
			$html .= '<div class="breadcrumbs">'.bcn_display(true).'</div>';
		}

	    $html .='</div></div></header>';

		return $html;
    }
}

if(!function_exists('apollo13framework_title_bar')){
	/**
	 * Prints Page title bar
	 *
	 * @param string $called_position position of title bar in page
	 * @param string $title    title of page
	 * @param string $subtitle subtitle of page
	 *
	 */
	function apollo13framework_title_bar( $called_position = 'outside', $title = '', $subtitle = '') {
		echo apollo13framework_get_title_bar( $called_position, $title, $subtitle);
	}
}



if(!function_exists('apollo13framework_page_individual_look')){
	/**
	 * Prints CSS for title bar
	 */
	function apollo13framework_page_individual_look(){
        global $apollo13framework_a13;

        //checks if page can have meta fields
        //if not page will use styles defined in user.css
        if(!apollo13framework_is_no_property_page()){
            $css = '';
            $page_type = apollo13framework_what_page_type_is_it();
            $body_class = '.page';

	        //if this is not page, post or work, then have nothing to do here
            if(!($page_type['post'] || $page_type['page'] || $page_type['work'])){
                return;
            }

	        //we set style for these in customizer, so we don't use settings from "Page details"
	        if($page_type['albums_list'] || $page_type['works_list'] || $page_type['shop'] || $page_type['blog_type']){
		        return;
	        }

            //id from where
            $meta_id = false;
            if(is_404() && $apollo13framework_a13->get_option( 'page_404_template_type' ) === 'custom' ) {
                $meta_id = $apollo13framework_a13->get_option( 'page_404_template' );
            }

            if($page_type['page']){ //404 is not page so it is ok that they are not in the same if-else
                $meta_id = get_the_ID();
            }
            elseif($page_type['post']){
                $meta_id = get_the_ID();
                $body_class = '.single-post';
            }
            elseif($page_type['work']){
                $meta_id = get_the_ID();
                $body_class = '.single-work';
            }


            /***************************************/
            /* PAGE BACKGROUND */
            /***************************************/
            $page_bg_option = $apollo13framework_a13->get_meta('_page_bg_settings', $meta_id);

            if($page_bg_option === 'custom'){
                $bg_color       = get_post_meta($meta_id, '_page_bg_color', true);
                $bg_image       = get_post_meta($meta_id, '_page_image', true);
                $bg_image_fit   = apollo13framework_bg_fit_helper(get_post_meta($meta_id, '_page_image_fit', true));

                $css .= '
                    '.$body_class.' .page-background{
                        background-color:'.$bg_color.';
                        background-image: url('.$bg_image.');
                        '.$bg_image_fit.'
                    }
                ';
            }



            /***************************************/
            /* TITLE BAR */
            /***************************************/
            $title_bar_option = $apollo13framework_a13->get_meta( '_title_bar_settings', $meta_id );

	        //change everything
            if ( $title_bar_option === 'custom' ) {
                //where title bar should be displayed
                $position = $apollo13framework_a13->get_meta( '_title_bar_position', $meta_id );

                //we don't style "inside" title bars
	            if ( $position !== 'inside' ) {
		            $bg_color     = get_post_meta( $meta_id, '_title_bar_bg_color', true );
		            $bg_image     = apollo13framework_get_top_image_video(false, array('return_src' =>  true, 'force_image' => true, 'full_size' => true));
		            $bg_fit       = apollo13framework_bg_fit_helper( get_post_meta( $meta_id, '_title_bar_image_fit', true ) );
		            $title_color  = get_post_meta( $meta_id, '_title_bar_title_color', true );
		            $second_color = get_post_meta( $meta_id, '_title_bar_color_1', true );
		            $space        = get_post_meta( $meta_id, '_title_bar_space_width', true );

		            $css .= '
                        ' . $body_class . ' .title-bar.outside{
                            background-image:url(' . esc_url( $bg_image ) . ');
                            '.$bg_fit.'
                        }
                        ' . $body_class . ' .title-bar.outside .overlay-color{
                            background-color:' . $bg_color . ';
                            padding-top:' . $space . ';
                            padding-bottom:' . $space . ';
                        }
                        ' . $body_class . ' .title-bar.outside .page-title,
                        ' . $body_class . ' .title-bar.outside h2{
                            color:' . $title_color . ';
                        }
                        ' . $body_class . ' .title-bar.outside .metas,
			            ' . $body_class . ' .title-bar.outside .metas a,
			            ' . $body_class . ' .title-bar.outside .metas a:hover,
                        ' . $body_class . ' .title-bar.outside .breadcrumbs,
			            ' . $body_class . ' .title-bar.outside .breadcrumbs a,
			            ' . $body_class . ' .title-bar.outside .breadcrumbs a:hover{
			                color:' . $second_color . ';
			            }
                    ';
                }
            }
            //change only post thumbnail
	        elseif($title_bar_option === 'global' && has_post_thumbnail()){
				//where title bar should be displayed
		        if( $page_type['page'] ){
		            $post_type = 'page';
	            }
	            elseif( $page_type['post'] ){
		            $post_type = 'post';
	            }
	            else{
		            $post_type = 'work';
	            }

	            $position = $apollo13framework_a13->get_option( $post_type . '_title_bar_position' );

		        if ( $position !== 'inside' ){
			        $bg_image     = apollo13framework_get_top_image_video(false, array('return_src' =>  true, 'force_image' => true, 'full_size' => true));

			        $css .= '
                        ' . $body_class . ' .title-bar.outside{
                            background-image:url(' . esc_url( $bg_image ) . ');
                        }
                    ';
		        }
	        }

            //if we have some CSS then add it
            if(strlen($css)){
	            wp_add_inline_style( 'a13-user-css', $css );
            }
        }
    }
}
add_action( 'wp_enqueue_scripts', 'apollo13framework_page_individual_look', 27 );



if(!function_exists('apollo13framework_social_icons')){
	/**
	 * HTML for social icons
	 *
	 * @param string $normal         - color of icons for normal state
	 * @param string $hover          - color of icons for hover state
	 * @param string $socials_array  - array of social icons
	 * @param bool   $hide_on_mobile - should icons be hidden on small devices
	 *
	 * @return string HTML
	 *
	 */
	function apollo13framework_social_icons($normal, $hover, $socials_array = '', $hide_on_mobile = false ){
        global $apollo13framework_a13;

		if( is_array($socials_array) ){
			$socials = $socials_array;
		}else{
			$socials = json_decode($apollo13framework_a13->get_option( 'social_services' ), true);
		}

		$classes = 'socials '.$apollo13framework_a13->get_option( 'socials_variant' );
		$classes .= ' '.$normal;
		$classes .= ' '.$hover.'_hover';
		$classes .= $hide_on_mobile ? ' hide_on_mobile': '';
		$icons_classes = $apollo13framework_a13->get_social_icons_list('classes');

		$soc_html = '';
        $has_active = false;
        $protocols = wp_allowed_protocols();
        $protocols[] = 'skype';

        foreach( $socials as $service ){
            if( ! empty($service['link']) ){
	            $icon_class = 'a13_soc-'.$service['id'].' '.$icons_classes[$service['id']];
                $soc_html .= '<a target="_blank" href="' . esc_url($service['link'], $protocols) . '" class="'.esc_attr($icon_class).'"></a>';
                $has_active = true;
            }
        }

        if($has_active){
            $soc_html = '<div class="'.esc_attr($classes).'">'.$soc_html.'</div>';
        }

        return $soc_html;
    }
}



if(!function_exists('apollo13framework_page_like_content')){
	/**
	 * prints HTML for some special templates, that use static pages for layout
	 *
	 */
	function apollo13framework_page_like_content(){
		// almost copy of page.php
		the_post(); //before header to get proper classes of custom template!

		get_header();

		apollo13framework_title_bar();
		?>

		<article id="content" class="clearfix">
			<div class="content-limiter">
			    <div id="col-mask">

			        <div id="post-<?php the_ID(); ?>" <?php post_class('content-box'); ?>>
				        <div class="formatter">
					        <?php apollo13framework_title_bar( 'inside' ); ?>
				            <div class="real-content">
				                <?php the_content(); ?>
					            <div class="clear"></div>

				                <?php
				                wp_link_pages( array(
				                        'before' => '<div id="page-links">'.esc_html__( 'Pages: ', 'apollo13-framework' ),
				                        'after'  => '</div>')
				                );
				                ?>
				            </div>
			            </div>
			        </div>
			        <?php get_sidebar(); ?>
			    </div>
			</div>
		</article>

		<?php get_footer();
	}
}



if(!function_exists('apollo13framework_result_count')){
	/**
	 * returns number of post displayed on page from total number of posts
	 *
	 */
	function apollo13framework_result_count(){
		global $wp_query;
		?>
		<span class="result-count">
	<?php
	$paged    = max( 1, $wp_query->get( 'paged' ) );
	$total    = $wp_query->found_posts;
	$last     = min( $total, $wp_query->get( 'posts_per_page' ) * $paged );

	if ( 1 == $total ) {
		echo '1/1';
	} else {
		printf( '%1$d/%2$d', $last, $total );
	}
	?>
</span>
		<?php
	}
}


//only if plugin "SearchWP Live Ajax Search" is activated
if(class_exists('SearchWP_Live_Search')){

	if(!function_exists('apollo13framework_searchwp_live_search_posts_per_page')) {
		/**
		 *  Control how many results are returned
		 */
		function apollo13framework_searchwp_live_search_posts_per_page() {
			return 6;
		}
	}
	add_filter( 'searchwp_live_search_posts_per_page', 'apollo13framework_searchwp_live_search_posts_per_page' );



	if(!function_exists('apollo13framework_searchwp_live_search_configs')) {
		/**
		 *  change default configuration of Live Search plugin
		 *
		 * @param $configs - config which will edit
		 *
		 * @return
		 */
		function apollo13framework_searchwp_live_search_configs( $configs ) {
			// override some defaults
			$configs['default'] = array(
				'engine'                  => 'default',
				// search engine to use (if SearchWP is available)
				'input'                   => array(
					'delay'     => 500,                 // wait 500ms before triggering a search
					'min_chars' => 3,                   // wait for at least 3 characters before triggering a search
				),
				'results'                 => array(
					'position' => 'bottom',            // where to position the results (bottom|top)
					'width'    => 'css',              // whether the width should automatically match the input (auto|css)
					'offset'   => array(
						'x' => 0,                   // x offset (in pixels)
						'y' => 0                    // y offset (in pixels)
					),
				),
				'spinner'                 => array(                         // powered by http://fgnass.github.io/spin.js/
					'lines'     => 10,              // number of lines in the spinner
					'length'    => 8,               // length of each line
					'width'     => 4,               // line thickness
					'radius'    => 8,               // radius of inner circle
					'corners'   => 1,               // corner roundness (0..1)
					'rotate'    => 0,               // rotation offset
					'direction' => 1,               // 1: clockwise, -1: counterclockwise
					'color'     => '#000',          // #rgb or #rrggbb or array of colors
					'speed'     => 1,               // rounds per second
					'trail'     => 60,              // afterglow percentage
					'shadow'    => false,           // whether to render a shadow
					'hwaccel'   => false,           // whether to use hardware acceleration
					'className' => 'spinner',       // CSS class assigned to spinner
					'zIndex'    => 2000000000,      // z-index of spinner
					'top'       => '50%',           // top position (relative to parent)
					'left'      => '50%',           // left position (relative to parent)
				),
				'results_destroy_on_blur' => false,
				'parent_el'               => '#search-results-header'
			);

			return $configs;
		}
	}
	add_filter( 'searchwp_live_search_configs', 'apollo13framework_searchwp_live_search_configs' );

	if(!function_exists('apollo13framework_remove_searchwp_live_search_theme_css')) {
		/**
		 *  remove the default visual styling of Live Search plugin
		 */
		function apollo13framework_remove_searchwp_live_search_theme_css() {
			wp_dequeue_style( 'searchwp-live-search' );
		}
	}
	add_action( 'wp_enqueue_scripts', 'apollo13framework_remove_searchwp_live_search_theme_css', 20 );


	//disable default results pane positioning CSS
	add_filter( 'searchwp_live_search_base_styles', '__return_false' );
	//prevent SearchWP from automatically enabling live search on forms generated with get_search_form(),
	add_filter( 'searchwp_live_search_hijack_get_search_form', '__return_false' );
}

if(!function_exists('apollo13framework_waiting_page')){
	/**
	 * redirect to chosen page if needed
	 *
	 */
	function apollo13framework_waiting_page(){
		global $apollo13framework_a13;
		global $post;
		$waiting_mode = $apollo13framework_a13->get_option( 'maintenance_mode' );
		$wait_page = $apollo13framework_a13->get_option( 'maintenance_mode_page' );
		if ( $waiting_mode == 'on' ) {
			add_filter('apollo13framework_only_content','apollo13framework_only_content');
		}
		if ( $waiting_mode == 'on' && $wait_page > 0 && $post->ID != $wait_page ) {
			wp_redirect( get_permalink( $wait_page ) );
			exit;
		}
	}
}

function apollo13framework_only_content(){
	return true;
}


if(!function_exists('apollo13framework_make_post_grid_filter')) {
	function apollo13framework_make_post_grid_filter( $terms, $filter_class = '' ) {
		if ( count( $terms ) ):
			echo '<ul class="category-filter clearfix ' . esc_attr( $filter_class ) . '">';

			echo '<li class="selected" data-filter="__all"><a href="' . apollo13framework_current_url() . '">' . esc_html__( 'All', 'apollo13-framework' ) . '</a></li>';
			foreach ( $terms as $term ) {
				echo '<li data-filter="' . $term->term_id . '"><a href="' . esc_url( get_term_link( $term ) ) . '">' . $term->name . '</a></li>';
			}

			echo '</ul>';
		endif;
	}
}