<?php

/**
 * adds JS file to run in customizer view
 */
add_action( 'customize_controls_enqueue_scripts', 'apollo13framework_customizer_admin_js');
function apollo13framework_customizer_admin_js(){
	global $apollo13framework_a13;

	wp_enqueue_script('a13-admin-customizer', get_theme_file_uri( 'js/admin-customizer.js' ),
		array( 'jquery' ), //will load file only when redux is available
		A13FRAMEWORK_THEME_VER
	);

	$notices = get_option('a13_'.A13FRAMEWORK_TPL_SLUG.'_ajax_notices');
	$apollo_params = array(
		'ajaxurl' => admin_url( 'admin-ajax.php' ),
		'notices' => array(
			'header_color_variants' => array(
				'msg'     => __( '<p>Page that is visible in preview is using option "header color variant". Some changes made in header(like logo, social colors, etc.) might not be visible on this page cause of that.</p>', 'apollo13-framework' ) .
				             sprintf( __( '<p>For more information please check <a href="%s" target="_blank">this section in documentation</a> or below tutorial:</p>', 'apollo13-framework' ), esc_attr( $apollo13framework_a13->get_docs_link('header-color-variants') ) ) .
				             '<i'.'frame width="290" height="163" src="https://www.youtube.com/embed/kLP2V8Q6uo4?rel=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>',
				'enabled' => strlen($notices['header_color_variants']) ? $notices['header_color_variants'] : 1,
			),
		)
	);
	wp_localize_script( 'a13-admin-customizer', 'ApolloParams', $apollo_params );
}

/**
 * prints icons selector
 */
add_action( 'customize_controls_print_footer_scripts', 'apollo13framework_customizer_footer' );
function apollo13framework_customizer_footer() {
	echo '<div id="a13-fa-icons">';
	/** @noinspection PhpIncludeInspection */
	$classes = require_once( get_theme_file_path( 'advance/inc/font-awesome-icons' ));
	foreach($classes as $name){
		$name = trim($name);
		echo '<span class="a13-font-icon fa fa-'.$name.'" title="'.$name.'"></span>'."\n";
	}
	echo '</div>';
}
