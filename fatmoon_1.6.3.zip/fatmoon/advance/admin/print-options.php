<?php
/**
 * Checks single dependency if it is valid
 *
 * @param array $dependency  dependency to check in form of 3 fields array
 *
 * @return bool valid or not
 */

function apollo13framework_compare_dependency($dependency){
	global $apollo13framework_a13;

	$parent   = $dependency[0];
	$operator = $dependency[1];
	$value    = $dependency[2];
	$parent_value = $apollo13framework_a13->get_meta( '_'.$parent );

	//check if it is "new post" page
	global $pagenow;
	if('post-new.php' == $pagenow ) {
		$parent_value = $apollo13framework_a13->defaults_of_meta[$parent];
	}


	//check operators
	if($operator === '='){
		return $value === $parent_value;
	}
	elseif($operator === '!='){
		return $value !== $parent_value;
	}
	
	//for all other operators
	return false;
}


/**
 * @param array $required dependency to check in form of 3 fields array
 * @param bool $is_meta is it called for meta filed or option
 *
 * @return bool
 */
function apollo13framework_check_control_dependencies($required, $is_meta ){
	if($is_meta){
		//we have more then one required condition
		if(is_array($required[0]) ){
			foreach($required as $dependency){
				if(!apollo13framework_compare_dependency($dependency)){
					//some dependency were not met
					return false;
				}
			}
			//all dependencies were met
			return true;
		}
		//we have only one required condition
		else{
			return apollo13framework_compare_dependency($required);
		}
	}
	//classic option - not supported 
	else{
		return true;
	}
}


function apollo13framework_input_help_tip($message){
	?>
	<div class="input-tip">
		<span class="hover">?</span>

		<div class="tip"><?php echo balanceTags( $message ); ?></div>
	</div>
	<?php
}


/**
 * Generates input, selects and other form controls
 *
 * @param $option  : currently processed option with all attributes
 * @param $params  : params for meta type or option type
 * @param $is_meta : meta or option
 *
 * @return bool true if some field was used, false other way
 */
function apollo13framework_print_form_controls( $option, &$params, $is_meta = false ) {
	global $apollo13framework_a13;
	$input_prefix = A13FRAMEWORK_INPUT_PREFIX;

	$style  = '';

	if ( isset( $option['paid'] ) && !$apollo13framework_a13->check_for_valid_license() ) {
		return false;
	}

	$description = isset( $option['description'] ) ? $option['description'] : '';

	/* Extract some variables */
	if ( $is_meta ) {
		$value = $params['value'];
		$style = $params['style'];
	} //if run for theme options
	else {
		$value = $apollo13framework_a13->get_option( $option['id'] );
	}

	//check if field should be visible
	if ( isset( $option['required'] ) && is_array( $option['required'] ) ) {
		//display or not
		$style .= apollo13framework_check_control_dependencies( $option['required'], $is_meta ) ? '' : 'display: none;';
	}

	//any style to print?
	if(strlen($style)){
		$style = ' style="'.esc_attr($style).'"';
	}


	/* TYPES */
	if ( $option['type'] == 'upload' ) {
		$upload_button_text = ! empty( $option['button_text'] ) ? $option['button_text'] : esc_html__( 'Upload', 'apollo13-framework' );
		$data_attr          = '';
		if ( isset( $option['attachment_field'] ) && strlen( $option['attachment_field'] ) ) {
			$data_attr = ' data-attachment="'.esc_attr($option['attachment_field']).'"';
		}

		$media_button_text = '';
		if ( isset( $option['media_button_text'] ) && strlen( $option['media_button_text'] ) ) {
			$media_button_text = ' data-media-button-name="' . esc_attr($option['media_button_text']) . '"';
		}

		$media_type = '';
		if ( isset( $option['media_type'] ) && strlen( $option['media_type'] ) ) {
			$media_type = ' data-media-type="' . esc_attr($option['media_type']) . '"';
		}
		?>

		<div class="upload-input input-parent"<?php print $style; ?>>
			<label for="<?php echo esc_attr($input_prefix . $option['id']); ?>"><?php echo esc_html($option['name']); ?>&nbsp;</label>

			<div class="input-desc">
				<input id="<?php echo esc_attr($input_prefix . $option['id']); ?>"<?php print $data_attr; ?> type="text" size="36" name="<?php echo esc_attr($input_prefix . $option['id']); ?>" value="<?php echo stripslashes( esc_attr( $value ) ); ?>" />
				<input id="upload_<?php echo esc_attr($input_prefix . $option['id']); ?>" class="upload-image-button" type="button" value="<?php echo esc_attr($upload_button_text) ?>"<?php print $media_button_text; ?><?php print $media_type; ?> />
				<input id="clear_<?php echo esc_attr($input_prefix . $option['id']); ?>" class="clear-image-button" type="button" value="<?php echo esc_attr( esc_html__( 'Clear field', 'apollo13-framework' )) ?>" />

				<p class="desc"><?php print $description; ?></p>
			</div>
		</div>
		<?php
		return true;
	}
	elseif ( $option['type'] == 'text' ) {
		$inp_class   = isset( $option['input_class'] ) ? ( ' class="' . esc_attr($option['input_class']) . '"' ) : '';
		$placeholder = isset( $option['placeholder'] ) ? ( ' placeholder="' . $option['placeholder'] . '"' ) : '';
		?>
		<div class="text-input input-parent"<?php print $style; ?>>
			<label for="<?php echo esc_attr($input_prefix . $option['id']); ?>"><?php echo esc_html($option['name']); ?>&nbsp;</label>

			<div class="input-desc">
				<input id="<?php echo esc_attr($input_prefix . $option['id']); ?>"<?php print $inp_class . $placeholder; ?> type="text" size="36" name="<?php echo esc_attr($input_prefix . $option['id']); ?>" value="<?php echo stripslashes( esc_attr( $value ) ); ?>" />

				<p class="desc"><?php print $description; ?></p>
			</div>
		</div>
		<?php
		return true;
	}
	elseif ( $option['type'] == 'hidden' ) {
		?>
		<div class="hidden-input input-parent"<?php print $style; ?>>
			<input id="<?php echo esc_attr($input_prefix . $option['id']); ?>" type="hidden" name="<?php echo esc_attr($input_prefix . $option['id']); ?>" value="<?php echo esc_attr( $value ); ?>" />
		</div>
		<?php
		return true;
	}
	elseif ( $option['type'] == 'textarea' ) {
		?>
		<div class="textarea-input input-parent"<?php print $style; ?>>
			<label for="<?php echo esc_attr($input_prefix . $option['id']); ?>"><?php echo esc_html($option['name']); ?>&nbsp;</label>

			<div class="input-desc">
				<textarea rows="10" cols="20" class="large-text" id="<?php echo esc_attr($input_prefix . $option['id']); ?>" name="<?php echo esc_attr($input_prefix . $option['id']); ?>"><?php echo stripslashes( esc_textarea( $value ) ); ?></textarea>

				<p class="desc"><?php print $description; ?></p>
			</div>
		</div>
		<?php
		return true;
	}
	elseif ( $option['type'] == 'select' ) {
		$selected      = $value;
		$selected_prop = ' selected="selected"';
		?>
		<div class="select-input input-parent"<?php print $style; ?>>
			<label for="<?php echo esc_attr($input_prefix . $option['id']); ?>"><?php echo esc_html($option['name']); ?></label>

			<div class="input-desc">
				<select id="<?php echo esc_attr($input_prefix . $option['id']); ?>" name="<?php echo esc_attr($input_prefix . $option['id']); ?>">
					<?php
					foreach ( $option['options'] as $html_value => $html_option ) {
						echo '<option value="' . esc_attr( $html_value ) . '"' . ( (string) $html_value == (string) $selected ? $selected_prop : '' ) . '>' . $html_option . '</option>';
					}
					?>
				</select>

				<p class="desc"><?php print $description; ?></p>
			</div>
		</div>
		<?php
		return true;
	}
	elseif ( $option['type'] == 'radio' ) {
		$selected = $value;
		?>
		<div class="radio-input input-parent"<?php print $style; ?>>
			<span class="label-like"><?php echo esc_html($option['name']); ?></span>

			<div class="input-desc">
				<?php
				foreach ( $option['options'] as $html_value => $html_option ) {
					$selected_attr = '';
					$disabled = false;
					if ( (string) $html_value == (string) $selected ) {
						$selected_attr = ' checked="checked"';
					}
					if(isset($option['paid_options']) && in_array( $html_value, $option['paid_options'] ) ){
						$disabled = !$apollo13framework_a13->check_for_valid_license();
					}
					echo '<label'.($disabled?' class="disabled"' : '').'><input type="radio" name="' . $input_prefix . $option['id'] . '" value="' . esc_attr( $html_value ) . '" ' . $selected_attr . ($disabled? ' disabled' : '').' />' . $html_option . '</label>';
				}
				?>
				<p class="desc"><?php print $description; ?></p>
			</div>
		</div>
		<?php
		return true;
	}
	elseif ( $option['type'] == 'color' ) {
		?>
		<div class="color-input input-parent"<?php print $style; ?>>
			<label for="<?php echo esc_attr($input_prefix . $option['id']); ?>"><?php echo esc_html($option['name']); ?></label>

			<div class="input-desc">
				<div class="input-tip">
					<span class="hover">?</span>

					<p class="tip"><?php
						echo wp_kses(
							__( 'Use valid CSS <code>color</code> property values( <code>green, #33FF99, rgb(255,128,0)</code> ), or get your color with color picker tool.<br />Use <code>Transparent</code> button to insert transparent value.<br />Left empty to use default theme value.', 'apollo13-framework' ),
							array(
								'br' => array(),
								'code' => array(),
							));
						?></p>
				</div>
				<input id="<?php echo esc_attr($input_prefix . $option['id']); ?>" type="text" class="with-color" name="<?php echo esc_attr($input_prefix . $option['id']); ?>" value="<?php echo stripslashes( esc_attr( $value ) ); ?>" />
				<button class="transparent-value button-secondary"><?php esc_html_e( 'Transparent', 'apollo13-framework' ); ?></button>
				<p class="desc"><?php print $description; ?></p>
			</div>
		</div>
		<?php
		return true;
	}
	elseif ( $option['type'] == 'tag_media' ) {
		?>
		<div class="tag_media-input input-parent"<?php print $style; ?>>
			<label for="<?php echo esc_attr($input_prefix . $option['id']); ?>-helper"><?php echo esc_html($option['name']); ?>&nbsp;</label>

			<div class="input-desc">
				<textarea rows="1" cols="20" class="hide-if-js large-text" id="<?php echo esc_attr($input_prefix . $option['id']); ?>" name="<?php echo esc_attr($input_prefix . $option['id']); ?>"><?php echo stripslashes( esc_textarea( $value ) ); ?></textarea>
				<p><input id="<?php echo esc_attr($input_prefix . $option['id']); ?>-helper" class="not-to-collect newtag" size="16" value="" type="text">
					<input class="not-to-collect button tagadd" value="<?php esc_attr_e( esc_html__( 'Add', 'apollo13-framework' )); ?>" type="button"></p>
				<div class="current-tags tagchecklist"></div>
				<p class="desc"><?php print $description; ?></p>
			</div>
		</div>
		<?php
		return true;
	}
	elseif ( $option['type'] == 'slider' ) {
		$min = isset( $option['min'] ) ? $option['min'] : '';
		$max = isset( $option['max'] ) ? $option['max'] : '';
		$step = isset( $option['step'] ) ? $option['step'] : 1;
		?>
		<div class="slider-input input-parent"<?php print $style; ?>>
			<label for="<?php echo esc_attr($input_prefix . $option['id']); ?>"><?php echo esc_html($option['name']); ?></label>

			<div class="input-desc">
				<div class="input-tip">
					<span class="hover">?</span>

					<p class="tip"><?php esc_html_e( 'Use slider to set proper value. You can click on slider handle and then use arrows keys(on keyboard) to adjust value precisely. You can also type in input value that is in/out of range of slider, and it will be used.', 'apollo13-framework' ); ?></p>
				</div>
				<input class="slider-dump" id="<?php echo esc_attr($input_prefix . $option['id']); ?>" type="text" name="<?php echo esc_attr($input_prefix . $option['id']); ?>" value="<?php echo stripslashes( esc_textarea( $value ) ); ?>" />

				<div class="slider-place" data-min="<?php echo esc_attr($min); ?>" data-max="<?php echo esc_attr($max); ?>" data-unit="<?php echo esc_attr($option['unit']); ?>" data-step="<?php echo esc_attr($step); ?>"></div>
				<p class="desc"><?php print $description; ?></p>
			</div>
		</div>
		<?php
		return true;
	}
	elseif ( $option['type'] == 'wp_dropdown_pages' ) {
		$selected = $value;
		?>
		<div class="select-input input-parent"<?php print $style; ?>>
			<label for="<?php echo esc_attr($input_prefix . $option['id']); ?>"><?php echo esc_html($option['name']); ?></label>

			<div class="input-desc">
				<?php
				$wp_pages = wp_dropdown_pages( array(
					'selected'          => $selected,
					'name'              => $input_prefix . $option['id'],
					'show_option_none'  => esc_html__( 'Select page', 'apollo13-framework' ),
					'option_none_value' => '0',
					'echo'              => 0
				) );
				if ( strlen( $wp_pages ) ) {
					print $wp_pages;
				} else {
					echo '<span class="empty-type">'.esc_html__( 'There is no pages yet!', 'apollo13-framework' ).'</span>';
				}
				?>
				<p class="desc"><?php print $description; ?></p>
			</div>
		</div>
		<?php
		return true;
	}
	elseif ( $option['type'] == 'wp_dropdown_products' ) {
		?>
		<div class="select-input input-parent"<?php print $style; ?>>
			<label for="<?php echo esc_attr($input_prefix . $option['id']); ?>"><?php echo esc_html($option['name']); ?></label>

			<div class="input-desc">
				<?php
				global $post;

				$original_post = $post;

				$args = array(
					'post_type'				=> 'product',
					'post_status'			=> 'publish',
					'ignore_sticky_posts'	=> 1,
					'posts_per_page' 		=> -1,
					'orderby' => 'title'
				);

				$products = new WP_Query( apply_filters( 'woocommerce_shortcode_products_query', $args ) );

				if ( $products->have_posts() ){
					$wp_products = '<select name="'.esc_attr($input_prefix.$option['id']).'" id="'.esc_attr($input_prefix.$option['id']).'">';
					$wp_products .= '<option value="0">'.esc_html__( 'None', 'apollo13-framework' ).'</option>';

					while ( $products->have_posts() ) {
						$products->the_post();
						$id = get_the_ID();
						$wp_products .= '<option value="'.esc_attr($id).'" '.selected( $value, 1, false ).'>'.get_the_title().'</option>';
					}

					$wp_products .= '</select>';
				}
				else{
					$wp_products = '<span class="empty-type">'. esc_html__( 'There is no products yet!', 'apollo13-framework' ) . '</span>';
				}

				$post = $original_post;

				wp_reset_postdata();

				print $wp_products;

				?>
				<p class="desc"><?php print $description; ?></p>
			</div>
		</div>
		<?php
		return true;
	}
	elseif ( $option['type'] == 'wp_dropdown_revosliders' ) {
		//check if we have class of Revolution Sliders
		if ( ! class_exists( 'RevSlider' ) ) {
			return true;
		}

		$slider        = new RevSlider();
		$arrSliders    = $slider->getArrSliders();
		$selected      = $value;
		$selected_prop = ' selected="selected"';
		?>
		<div class="select-input input-parent"<?php print $style; ?>>
			<label for="<?php echo esc_attr($input_prefix . $option['id']); ?>"><?php echo esc_html($option['name']); ?></label>

			<div class="input-desc">
				<?php


				if ( sizeof( $arrSliders ) ) :
					echo '<select name="' . $input_prefix . $option['id'] . '" id="' . $input_prefix . $option['id'] . '">';
					foreach ( $arrSliders as $slider ) {
						/** @var RevSlider $slider */
						$title = $slider->getTitle();
						$alias = $slider->getAlias();

						echo '<option value="' . $alias . '"' . ( ( (string) $alias == (string) $selected ) ? $selected_prop : '' ) . '>' . $title . '</option>';
					}

					echo '</select>';


				else:
					echo '<span class="empty-type">'.esc_html__( 'There is no sliders yet!', 'apollo13-framework' ).'</span>';
				endif;
				?>
				<p class="desc"><?php print $description; ?></p>
			</div>
		</div>
		<?php
		return true;
	}
	elseif ( $option['type'] == 'wp_dropdown_layersliders' ) {
		//check if we have class of Revolution Sliders
		if ( ! function_exists( 'lsSliders' ) ) {
			return true;
		}

		$arrSliders    = lsSliders( 200, true, false );
		$selected      = $value;
		$selected_prop = ' selected="selected"';
		?>
		<div class="select-input input-parent"<?php print $style; ?>>
			<label for="<?php echo esc_attr($input_prefix . $option['id']); ?>"><?php echo esc_html($option['name']); ?></label>

			<div class="input-desc">
				<?php


				if ( sizeof( $arrSliders ) ) :
					echo '<select name="' . $input_prefix . $option['id'] . '" id="' . $input_prefix . $option['id'] . '">';

					foreach ( $arrSliders as $slider ) {
						$title = $slider['name'];
						$id    = $slider['id'];

						echo '<option value="' . $id . '"' . ( ( (string) $id === (string) $selected ) ? $selected_prop : '' ) . '>' . $title . '</option>';
					}

					echo '</select>';


				else:
					echo '<span class="empty-type">'.esc_html__( 'There is no sliders yet!', 'apollo13-framework' ).'</span>';
				endif;
				?>
				<p class="desc"><?php print $description; ?></p>
			</div>
		</div>
		<?php
		return true;
	}

	return false;
}