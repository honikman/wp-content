<?php

function apollo13framework__no_meta_posts_page_notice() {
    echo '<div class="notice notice-warning inline"><p>' . sprintf( __( 'Theme options for this page can be found in <a href="%s">Appearance -&gt; Customize -&gt; Blog settings</a>.', 'apollo13-framework' ), admin_url( '/customize.php?autofocus[panel]=section_blog_layout' )) . '</p></div>';
}

function apollo13framework__no_meta_shop_page_notice() {
    echo '<div class="notice notice-warning inline"><p>' . sprintf( __( 'Theme options for this page can be found in <a href="%s">Appearance -&gt; Customize -&gt; Shop(WooCommerce) settings</a>.', 'apollo13-framework' ), admin_url( '/customize.php?autofocus[panel]=section_shop_general' )) . '</p></div>';
}

function apollo13framework__no_meta_albums_page_notice() {
    echo '<div class="notice notice-warning inline"><p>' . sprintf( __( 'Theme options for this page can be found in <a href="%s">Appearance -&gt; Customize -&gt; Albums settings</a>.', 'apollo13-framework' ), admin_url( '/customize.php?autofocus[panel]=section_albums') ) . '</p></div>';
}

function apollo13framework__no_meta_works_page_notice() {
    echo '<div class="notice notice-warning inline"><p>' . sprintf( __( 'Theme options for this page can be found in <a href="%s">Appearance -&gt; Customize -&gt; Works settings</a>.', 'apollo13-framework' ), admin_url( '/customize.php?autofocus[panel]=section_works' )) . '</p></div>';
}

/**
 * Meta boxes in different post types
 */
function apollo13framework_admin_meta_boxes(){
    global $apollo13framework_a13;

    add_meta_box(
        'apollo13_theme_options',
         __( 'Blog post details', 'apollo13-framework' ),
        'apollo13framework_meta_main_opts',
        'post',
        'normal',
        'default',
        array('func' => 'apollo13framework_meta_boxes_post')//callback
    );

    //don't display page metaboxes on special pages
    $current_page_id = get_the_ID();
    //blog page
    if($current_page_id == get_option( 'page_for_posts' )){
        add_action( 'edit_form_after_editor', 'apollo13framework__no_meta_posts_page_notice' );
    }
    //shop page
    elseif(apollo13framework_is_woocommerce_activated() &&( $current_page_id == wc_get_page_id( 'shop' ) )){
        add_action( 'edit_form_after_editor', 'apollo13framework__no_meta_shop_page_notice' );
    }
    //albums list page
    elseif( $current_page_id == $apollo13framework_a13->get_option( 'albums_list_page' ) || basename( get_page_template(), '.php') == 'albums_template' ){
        add_action( 'edit_form_after_editor', 'apollo13framework__no_meta_albums_page_notice' );
    }
    //works list page
    elseif( $current_page_id == $apollo13framework_a13->get_option( 'works_list_page' ) || basename( get_page_template(), '.php') == 'works_template' ){
        add_action( 'edit_form_after_editor', 'apollo13framework__no_meta_works_page_notice' );
    }

    else{
        add_meta_box(
            'apollo13_theme_options',
             __( 'Page details', 'apollo13-framework' ),
            'apollo13framework_meta_main_opts',
            'page',
            'normal',
            'default',
            array('func' => 'apollo13framework_meta_boxes_page')//callback
        );
    }



    add_meta_box(
        'apollo13_theme_options',
         __( 'Album details', 'apollo13-framework' ),
        'apollo13framework_meta_main_opts',
        A13FRAMEWORK_CUSTOM_POST_TYPE_ALBUM,
        'normal',
        'default',
        array('func' => 'apollo13framework_meta_boxes_album')//callback
    );
    add_meta_box(
        'apollo13_theme_options_1',
         __( 'Album media - Add images/videos', 'apollo13-framework' ),
        'apollo13framework_meta_main_opts',
        A13FRAMEWORK_CUSTOM_POST_TYPE_ALBUM,
        'normal',
        'high',
        array('func' => 'apollo13framework_meta_boxes_images_manager')//callback
    );

    add_meta_box(
        'apollo13_theme_options',
        __( 'People details', 'apollo13-framework' ),
        'apollo13framework_meta_main_opts',
        A13FRAMEWORK_CUSTOM_POST_TYPE_PEOPLE,
        'normal',
        'low',
        array('func' => 'apollo13framework_meta_boxes_people')//callback
    );

    add_meta_box(
        'apollo13_theme_options',
        __( 'Work details', 'apollo13-framework' ),
        'apollo13framework_meta_main_opts',
        A13FRAMEWORK_CUSTOM_POST_TYPE_WORK,
        'normal',
        'low',
        array('func' => 'apollo13framework_meta_boxes_work')//callback
    );
    add_meta_box(
        'apollo13_theme_options_1',
        __( 'Work media - Add images/videos', 'apollo13-framework' ),
        'apollo13framework_meta_main_opts',
        A13FRAMEWORK_CUSTOM_POST_TYPE_WORK,
        'normal',
        'high',
        array('func' => 'apollo13framework_meta_boxes_images_manager')//callback
    );
}
add_action( 'add_meta_boxes', 'apollo13framework_admin_meta_boxes');


/**
 * Generates inputs in meta boxes
 *
 * @param object    $post
 * @param array     $meta_box
 */
function apollo13framework_meta_main_opts( $post, $meta_box ){

    // Use nonce for verification
    wp_nonce_field( 'apollo13_customization' , 'apollo13_noncename' );

    $input_prefix = A13FRAMEWORK_INPUT_PREFIX;

    /** @noinspection PhpIncludeInspection */
    require_once (get_theme_file_path( 'advance/meta.php' ));
    $callback_name = $meta_box['args']['func'];
    $meta_boxes = $callback_name();

    //collect defaults if it is "new post" page
    global $pagenow, $apollo13framework_a13;
    if('post-new.php' == $pagenow ) {
        foreach ( $meta_boxes as &$meta ) {
            if(isset($meta['id'])){
                $apollo13framework_a13->defaults_of_meta[$meta['id']] = isset( $meta['default'] ) ? $meta['default'] : '';
            }
        }
        unset($meta);// be safe, don't loose your hair :-)
    }


    $fieldset_open = false;
    $tabs_to_create = array();

    echo '<div class="apollo13-settings apollo13-metas">';

    foreach( $meta_boxes as &$meta ){
        //ASSIGNING VALUE
        $value = '';
        if ( isset( $meta['id'] ) ){
	        //get value
            $value = get_post_meta($post->ID, '_'.$meta['id'] , true);

            //use default if no value
            if( !strlen($value) ){
                $value = ( isset( $meta['default'] )? $meta['default'] : '' );
            }
        }

        $params = array(
            'style' => '',
            'value' => $value
        );

        /*
        * print tag according to type
        */

        if ( $meta['type'] === 'fieldset' ) {
            if ( isset( $meta['paid'] ) && !$apollo13framework_a13->check_for_valid_license() ) {
                continue;
            }
            if ( $fieldset_open ) {
	            echo '</div>';
            }

            $class = 'fieldset static';
	        if( isset( $meta['is_prototype'] ) ){
                $class .= ' prototype';
	        }

	        if( isset( $meta['tab'] ) && $meta['tab'] === true ){
                $class .= ' fieldset_tab';
                $tabs_to_create[] = $meta;
	        }

	        $id = '';
	        if( isset($meta['id'] ) ){
		        $id = ' id="'.$meta['id'].'"';
	        }

            echo '<div class="'.$class.'"'.$id.'>';

            if( isset( $meta['notice'] ) && strlen($meta['notice']) ){
                echo '<p class="fieldset_notice">'.wp_kses_data($meta['notice']).'</p>';
            }

            $fieldset_open = true;
        }

        //checks for all normal options
        elseif( apollo13framework_print_form_controls($meta, $params, true ) ){
            continue;
        }

        /***********************************************
         * SPECIAL field types
         ************************************************/
        elseif ( $meta['type'] === 'multi-upload' ) {
	        $media_type = '';
	        if ( isset( $meta['media_type'] ) && strlen( $meta['media_type'] ) ) {
		        $media_type = ' data-media-type="' . esc_attr($meta['media_type']) . '"';
	        }
	        ?>


	        <div class="a13-mu-container">
		        <input id="a13-multi-upload" class="button button-large button-primary" type="button" value="<?php echo esc_attr( __( 'Select/Upload images and videos', 'apollo13-framework' ) ); ?>" <?php print $media_type; ?> />
		        <span class="button button-large add-link-media"><?php esc_html_e( 'Add Video from Youtube/Vimeo', 'apollo13-framework' ); ?></span>
		        <label class="button button-large"><input type="checkbox" id="mu-prepend" value="1" /><?php esc_html_e( 'Add items at beginning of list', 'apollo13-framework' ); ?>
		        </label>
		        <input id="a13-multi-remove" class="button button-large" type="button" value="<?php echo esc_attr( __( 'Remove selected', 'apollo13-framework' ) ); ?>" disabled="disabled" />
                <?php if($apollo13framework_a13->check_for_valid_license()): ?>
                <p class="inline-part disabled" id="a13_multi_tags">
                    <label for="a13-bulk-tagging"><?php esc_html_e( 'Add tags to selected items', 'apollo13-framework' ); ?></label>
                    <input id="a13-bulk-tagging" class="newtag" size="16" value="" autocomplete="off" type="text" disabled="disabled" />
                    <input class="button tagadd" value="<?php esc_html_e( 'Add', 'apollo13-framework' ); ?>" type="button" disabled="disabled" />
                </p>
                <?php endif; ?>
		        <div class="input-tip">
			        <span class="hover">?</span>

			        <p class="tip"><?php
                        echo wp_kses(
                            __( 'To mark more items in Media Library and in below list, you can use <code>Ctrl</code>(<code>Cmd</code>) or <code>Shift</code> key while selecting them with mouse.', 'apollo13-framework' ),
                            array(
                                'code' => array(),
                            ));
                        ?></p>
		        </div>
		        <div id="a13-mu-notice"></div>
	        </div>


	        <?php
	        //hidden textarea with JSON of all images
	        echo '<textarea id="' . $input_prefix . $meta['id'] . '" name="' . $input_prefix . $meta['id'] . '">' . $value . '</textarea>';
	        //prototype of single linked item
	        echo '<div id="mu-single-item" class="fieldset prototype">'; //hide item
	        apollo13framework_admin_gallery_item_html( 'attachment-preview image', 'thumbnail', get_theme_file_uri( 'images/holders/video_150x100.png') );
	        echo '</div>';
	        ?>
			<ul id="mu-media" class="media-frame-content" data-columns="5">
				<?php echo apollo13framework_prepare_admin_gallery_html( apollo13framework_prepare_gallery_attachments( $value, true ) ); ?>
			</ul><?php
        }
    } //end foreach

    unset($meta);// be safe, don't loose your hair :-)

    //close fieldset
    if ( $fieldset_open ) {
	    echo '</div>';
    }

    echo '</div>';//.apollo13-settings .apollo13-metas

    if(count($tabs_to_create)){
        $html = '';
        foreach($tabs_to_create as $tab){
            $html .= '<li><span class="icon '.esc_attr($tab['icon']).'" title="'.esc_attr($tab['name']).'"></span><span class="tab-name">'.$tab['name'].'</span></li>';
        }

        echo '<ul class="meta-tabs">'.$html.'</ul>';
    }

    echo '<br class="clear" />';
}


/**
 * Saving meta's in post
 *
 * @param int $post_id
 */
function apollo13framework_save_post($post_id){
    static $done = 0;
    $done++;
    if( $done > 1 ){
        return;//no double saving same things
    }

    $input_prefix = A13FRAMEWORK_INPUT_PREFIX;

    // verify if this is an auto save routine.
    // If it is our form has not been submitted, so we do not want to do anything
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
        return;

    // verify this came from the our screen and with proper authorization,
    // because save_post can be triggered at other times
    if( ! isset( $_POST['apollo13_noncename'] ) )
        return;

    if ( !wp_verify_nonce( $_POST['apollo13_noncename'], 'apollo13_customization' ) )
        return;

	//lets get all fields that need to be saved
    /** @noinspection PhpIncludeInspection */
    require_once (get_theme_file_path( 'advance/meta.php' ));

    $meta_boxes = array();

    switch( $_POST['post_type'] ){
        case 'post':
            $meta_boxes = apollo13framework_meta_boxes_post();
            break;
        case 'page':
            $meta_boxes = apollo13framework_meta_boxes_page();
            break;
        case A13FRAMEWORK_CUSTOM_POST_TYPE_ALBUM:
            $meta_boxes = array_merge( apollo13framework_meta_boxes_album(), apollo13framework_meta_boxes_images_manager() );
            break;
        case A13FRAMEWORK_CUSTOM_POST_TYPE_WORK:
            $meta_boxes = array_merge( apollo13framework_meta_boxes_work(), apollo13framework_meta_boxes_images_manager() );
            break;
        case A13FRAMEWORK_CUSTOM_POST_TYPE_PEOPLE:
            $meta_boxes = apollo13framework_meta_boxes_people();
            break;
    }

    //saving meta
	$is_prototype = false;
    foreach( $meta_boxes as &$meta ){
	    //check is it prototype
	    if ( $meta['type'] === 'fieldset' ) {
		    if( isset( $meta['is_prototype'] ) ){
			    $is_prototype = true;
		    }
		    else{
			    $is_prototype = false;
		    }
		    continue;
	    }

        //don't save fields of prototype
        if($is_prototype){
            continue;
        }


        if( isset( $meta['id'] ) && isset( $_POST[ $input_prefix.$meta['id'] ] ) ){
            $val = $_POST[ $input_prefix.$meta['id'] ];
            update_post_meta( $post_id, '_'.$meta['id'] , $val );
        }
    }
}
add_action( 'save_post', 'apollo13framework_save_post' );