<?php
add_action( 'wp_ajax_apollo13framework_check_license_code', 'apollo13framework_check_license_code' );
function apollo13framework_check_license_code() {
	global $apollo13framework_a13;
	$out = $apollo13framework_a13->register_new_license_code(trim($_POST['code']));
	echo json_encode( $out, JSON_FORCE_OBJECT );
	exit;
}


add_action( 'wp_ajax_apollo13framework_import_demo_data', 'apollo13framework_import_demo_data' );


/**
 * Function leading demo data import process
 */
function apollo13framework_import_demo_data() {
	global $apollo13framework_a13;
	//check if we got license key
	if ( !$apollo13framework_a13->check_is_import_allowed() ) {
		$msg    = esc_html__( 'Import stopped - there is no valid Purchase/License Code', 'apollo13-framework' );
		$result = array(
			'log'           => $msg,
			'sublevel_name' => '',
			'level_name'    => $msg,
			'is_it_end'     => true
		);

		//send AJAX response
		echo json_encode( sizeof( $result ) ? $result : false );
		die(); //this is required to return a proper result
	}
	/** @noinspection PhpIncludeInspection */
	$file_system_check = require_once( get_theme_file_path( 'advance/admin/demo-data.php' ) );

	//error on file system access
	if(!$file_system_check){
		$result = array(
			'level'         => '',
			'level_name'    => esc_html__( 'Import Failed', 'apollo13-framework' ),
			'sublevel'      => '',
			'sublevel_name' => '',
			'log'           => esc_html__( 'Can not access File system!', 'apollo13-framework' ),
			'is_it_end'     => true,
			'alert'         => true
		);
	}
	else{
		$level         = $_POST['level'];
		$sublevel      = $_POST['sublevel'];
		$sublevel_name = '';
		$log           = '';
		$array_index   = 0;
		$alert         = false;

		$chosen_options = isset($_POST['import_options'])? $_POST['import_options'] : array();

		$levels = array(
			'_'                     => '', //empty to avoid bonus logic
			'start'                 => esc_html__( 'Starting import', 'apollo13-framework' ),
			'download_files'        => esc_html__( 'Downloading files', 'apollo13-framework' ),
			'clear_content'         => esc_html__( 'Removing content', 'apollo13-framework' ),
			'install_plugins'       => esc_html__( 'Installing plugins', 'apollo13-framework' ),
			'install_content'       => esc_html__( 'Importing content', 'apollo13-framework' ),
			'install_revo_sliders'  => esc_html__( 'Importing Revolution Slider', 'apollo13-framework' ),
			'setup_plugins_configs' => esc_html__( 'Setting up various plugins settings', 'apollo13-framework' ),
			'setup_wc'              => esc_html__( 'Setting up Woocommerce settings', 'apollo13-framework' ),
			'setup_fp'              => esc_html__( 'Setting up Front Page', 'apollo13-framework' ),
			'setup_menus'           => esc_html__( 'Setting menus to proper locations', 'apollo13-framework' ),
			'setup_widgets'         => esc_html__( 'Setting up widgets', 'apollo13-framework' ),
			'setup_permalinks'      => esc_html__( 'Setting up permalinks', 'apollo13-framework' ),
			'import_predefined_set' => esc_html__( 'Importing settings', 'apollo13-framework' ),
			'generate_custom_style' => esc_html__( 'Generate styles', 'apollo13-framework' ),
			'install_plugins_2'     => esc_html__( 'Installing plugins', 'apollo13-framework' ),
			'clean'                 => esc_html__( 'cleaning...', 'apollo13-framework' ),
			'end'                   => esc_html__( 'Everything done!', 'apollo13-framework' ),
		);

		//check what options are selected
		if(!isset($chosen_options['download_files'])){
			unset( $levels['download_files'] );
		}
		if(!isset($chosen_options['clear_content'])){
			unset( $levels['clear_content'] );
		}
		if(!isset($chosen_options['install_plugins'])){
			unset( $levels['install_plugins'] );
			unset( $levels['setup_plugins_configs'] );
			unset( $levels['setup_wc'] );
			unset( $levels['install_plugins_2'] );
		}
		if(!isset($chosen_options['import_shop'])){
			unset( $levels['setup_wc'] );
			unset( $levels['install_plugins_2'] );
		}
		if(!isset($chosen_options['install_content'])){
			unset( $levels['install_content'] );
		}
		if(!isset($chosen_options['install_revo_sliders'])){
			unset( $levels['install_revo_sliders'] );
		}
		if(!isset($chosen_options['install_site_settings'])){
			unset( $levels['setup_fp'] );
			unset( $levels['setup_menus'] );
			unset( $levels['setup_widgets'] );
			unset( $levels['setup_permalinks'] );
		}
		if(!isset($chosen_options['install_theme_settings'])){
			unset( $levels['import_predefined_set'] );
			unset( $levels['generate_custom_style'] );
		}
		if(!isset($chosen_options['clean'])){
			unset( $levels['clean'] );
		}

		//get current level key
		if ( strlen( $level ) === 0 ) {
			//get first level to process
			$level = key( $levels );
		}
		else {
			//move array pointer to current importing level
			while ( key( $levels ) !== $level ) {
				//and ask for next one
				next( $levels );
				$array_index++;
			}
			//save new current level
			$level = key( $levels );
		}

		//Execute current level function
		$function = 'apollo13framework_demo_data_' . $level;
		if ( function_exists( $function ) ) {
			//no notices or other "echos", we put it in $log
			ob_start();

			$functions_with_1_param = array(
				'apollo13framework_demo_data_import_predefined_set',
				'apollo13framework_demo_data_start',
				'apollo13framework_demo_data_clean',
				'apollo13framework_demo_data_install_revo_sliders'
			);

			//how many params should function receive
			if ( in_array($function, $functions_with_1_param ) ) {
				$sublevel = $function( $_POST['demo_id'] );
			}
			else {
				$sublevel = $function( $sublevel, $sublevel_name, $_POST['demo_id'], $chosen_options );
			}

			//collect all produced output to log
			$log = ob_get_contents();
			ob_end_clean();

			//should we move to next level
			if ( $sublevel === true ) {
				$sublevel = ''; //reset
				next( $levels );
				$level = key( $levels );
			}
		}
		//no function - move to next level. Some steps are just information without action
		else {
			next( $levels );
			$array_index ++;
			$level = key( $levels );
		}

		//check if this is last element
		$is_it_end = false;
		end( $levels );
		if ( key( $levels ) === $level ) {
			$is_it_end = true;
		}

		//prepare progress info
		$progress = round( 100 * ( 1 + $array_index ) / count( $levels ) );

		//special case - demo import files download failure
		$failure_codes = array(
			620,    // invalid purchase code
			621,    // trying to get paid demo
	//		1012,   // no available servers
			1013    // server directory no writable
		);
		if ( is_array( $sublevel ) && $sublevel['sublevel'] === false && in_array($sublevel['response']['code'], $failure_codes) ) {
			$log       = $sublevel['response']['message'];
			$sublevel  = false;
			$is_it_end = true;
			$alert     = true;
		}

		$result = array(
			'level'         => $level,
			'level_name'    => $levels[ $level ],
			'sublevel'      => $sublevel,
			'sublevel_name' => $sublevel_name,
			'log'           => $log,
			'progress'      => $progress,
			'is_it_end'     => $is_it_end,
			'alert'         => $alert
		);
	}

	//send AJAX response
	echo json_encode( sizeof( $result ) ? $result : false );

	die(); //this is required to return a proper result
}

add_action( 'wp_ajax_apollo13framework_prepare_gallery_items_html', 'apollo13framework_prepare_gallery_items_html' );

/**
 * Prints HTML for new items selected from WordPress media uploader
 */
function apollo13framework_prepare_gallery_items_html() {
	echo apollo13framework_prepare_admin_gallery_html( $_POST['items'] );

	die(); // this is required to return a proper result
}


add_action( 'wp_ajax_apollo13framework_rating_notice_action', 'apollo13framework_rating_notice_action' );

/**
 * Mark rating notice to be displayed later or disabled
 */
function apollo13framework_rating_notice_action() {
	$what_to_do = $_POST['what'];
	$new_value = '';

	if($what_to_do === 'remind-later'){
		$new_value = time();
	}
	elseif($what_to_do === 'disable-rating'){
		$new_value = 'disabled';
	}

	update_option('a13_'.A13FRAMEWORK_TPL_SLUG.'_rating', $new_value);

	echo esc_html( $what_to_do );

	die(); // this is required to return a proper result
}


add_action( 'wp_ajax_apollo13framework_proofing_notice_action', 'apollo13framework_proofing_notice_action' );

/**
 * Mark proofing notice to be disabled
 */
function apollo13framework_proofing_notice_action() {
	//clear data
	update_option('a13_proofed_albums', array());

	echo '';

	die(); // this is required to return a proper result
}


add_action( 'wp_ajax_apollo13framework_disable_ajax_notice', 'apollo13framework_disable_ajax_notice' );

/**
 * Mark notice to be displayed later or disabled
 */
function apollo13framework_disable_ajax_notice() {
	$id = $_POST['notice_id'];
	$option_name = 'a13_'.A13FRAMEWORK_TPL_SLUG.'_ajax_notices';

	//get notices
	$current_notices = get_option($option_name);
	//update mentioned notice
	$current_notices[$id] = 0;

	//save
	update_option($option_name, $current_notices);

	die(); // this is required to return a proper result
}

add_action( 'wp_ajax_apollo13framework_prepare_gallery_single_item_html', 'apollo13framework_prepare_gallery_single_item_html' );

/**
 * Just a helper to create item for gallery in album/work
 */
function apollo13framework_prepare_gallery_single_item_html() {
	$array[] = $_POST['item'];
	apollo13framework_prepare_external_media( $array );
	echo apollo13framework_prepare_admin_gallery_html( $array );

	die(); // this is required to return a proper result
}

add_action( 'wp_ajax_apollo13framework_mark_album_item', 'apollo13framework_mark_album_item' );
add_action( 'wp_ajax_nopriv_apollo13framework_mark_album_item', 'apollo13framework_mark_album_item' );
/**
 * Function to mark item as (not)selected by client
 */
function apollo13framework_mark_album_item() {
	$approve  = $_GET['approve'];
	$album_id = $_GET['album_id'];
	$item_id  = $_GET['item_id'];
	$link     = $_GET['link'];

	//check is it trusted call
	check_ajax_referer( 'proofing_ajax', 'security' );

	//get current proofing data
	$meta                = get_post_meta( $album_id, '_images_n_videos_proofing', true );
	$images_videos_array = strlen( $meta ) === 0 ? array() : json_decode( $meta, true );

	//external media
	if ( $item_id == 'external' ) {
		$images_videos_array[$link]['approved'] = $approve;
	}
	//numeric ID
	elseif(strlen($item_id)){
		$images_videos_array[$item_id]['approved'] = $approve;
	}

	//save changed data
	update_post_meta( $album_id, '_images_n_videos_proofing' , wp_slash( wp_json_encode($images_videos_array) ) );

	//album need to be marked as finished after change
	update_post_meta( $album_id, '_proofing_finished', 0 );

	//return JSON result
	echo wp_json_encode(array('approve' => (int)$approve));

	die(); // this is required to return a proper result
}


add_action( 'wp_ajax_apollo13framework_comment_album_item', 'apollo13framework_comment_album_item' );
add_action( 'wp_ajax_nopriv_apollo13framework_comment_album_item', 'apollo13framework_comment_album_item' );
/**
 * Function to add comment to item selected by client
 */
function apollo13framework_comment_album_item() {
	$comment  = $_REQUEST['comment'];
	$album_id = $_REQUEST['album_id'];
	$item_id  = $_REQUEST['item_id'];
	$link     = $_REQUEST['link'];

	//check is it trusted call
	check_ajax_referer( 'proofing_ajax', 'security' );

	//get current proofing data
	$meta                = get_post_meta( $album_id, '_images_n_videos_proofing', true );
	$images_videos_array = strlen( $meta ) === 0 ? array() : json_decode( $meta, true );

	//proceed comment
	$comment = esc_html( trim( stripslashes( $comment ) ) );

	//external media
	if ( $item_id == 'external' ) {
		$images_videos_array[$link]['comment'] = $comment;
	}
	//numeric ID
	elseif(strlen($item_id)){
		$images_videos_array[$item_id]['comment'] = $comment;
	}

	//save changed data
	update_post_meta( $album_id, '_images_n_videos_proofing' ,  wp_slash( wp_json_encode($images_videos_array) ) );

	//album need to be marked as finished after change
	update_post_meta( $album_id, '_proofing_finished', 0 );

	//return JSON result
	echo wp_json_encode(array('comment' => $comment));

	die(); // this is required to return a proper result
}


add_action( 'wp_ajax_apollo13framework_album_finished_proofing', 'apollo13framework_album_finished_proofing' );
add_action( 'wp_ajax_nopriv_apollo13framework_album_finished_proofing', 'apollo13framework_album_finished_proofing' );
/**
 * Function to mark album as finished for proofing process
 */
function apollo13framework_album_finished_proofing() {
	$album_id = $_REQUEST['album_id'];

	//check is it trusted call
	check_ajax_referer( 'proofing_ajax', 'security' );

	//save changed data
	update_post_meta( $album_id, '_proofing_finished', 1 );

	//prepare option with changed albums
	$proof_option = get_option('a13_proofed_albums');
	$proof_option[$album_id] = time();
	update_option('a13_proofed_albums', $proof_option, true);

	//send e-mail about new proofed album only if plugin is installed & active
	if(function_exists('apollo13framework_album_proofing_admin_mail')){
		apollo13framework_album_proofing_admin_mail($album_id);
	}

	//return JSON result
	echo wp_json_encode(array('done' => 1));

	die(); // this is required to return a proper result
}

/**
 * custom function to add/remove NAVA CPT post
 */
add_action( 'wp_ajax_apollo13framework_delete_post', 'apollo13framework_delete_post' );
function apollo13framework_delete_post() {
	if ( ! current_user_can( 'delete_posts' ) ) {
		exit;
	}
	wp_delete_post( $_REQUEST['id'] );
	echo 'success';

	die();

}

add_action( 'wp_ajax_apollo13framework_add_post', 'apollo13framework_add_post' );
function apollo13framework_add_post() {
	if ( ! current_user_can( 'edit_posts' ) ) {
		exit;
	}
	$new_nava    = array(
		'post_title'   => sanitize_title($_REQUEST['title']),
		'post_status'  => 'publish',
		'post_content' => '',
		'post_type'    => 'nava'
	);
	$new_post_ID = wp_insert_post( $new_nava );


	$response = array(
		'status'         => '200',
		'message'        => 'OK',
		'new_post_ID'    => $new_post_ID,
		'new_post_title' => $_REQUEST['title']
	);

	// normally, the script expects a json respone
	header( 'Content-Type: application/json; charset=utf-8' );
	echo json_encode( $response );

	exit; // important

}

//nava - add page slug to nava post
add_action( 'save_post', 'apollo13_after_page_save' );
function apollo13_after_page_save( $post_id ) {

	// If this is just a revision - exit
	if ( wp_is_post_revision( $post_id ) ) {
		return;
	}
	// avoid generating nava in case of page import
	if ( isset( $_SESSION['import_is_runnig'] ) && $_SESSION['import_is_runnig'] == 1 ) {
		return;
	}
	$page = get_post( $post_id );

	$a13_nava_page_slug = $page->post_name;
	//prepare array of params with a13_one_page_mode = 1
	//search for vc_row shortcodes inside page
	preg_match_all( '/\[(\[?)(vc_row)(?![\w-])([^\]\/]*(?:\/(?!\])[^\]\/]*)*?)(?:(\/)\]|\](?:([^\[]*+(?:\[(?!\/\2\])[^\[]*+)*+)\[\/\2\])?)(\]?)/s', $page->post_content, $matches );
	// array of shortcode's params
	$param_sets = $matches[3];

	if ( empty( $param_sets ) ) {

		//return;
	}

	foreach ( $param_sets as $param_set ) {
		if ( stripos( $param_set, 'a13_one_page_mode="1"' ) === false ) {
			continue;
		}
		$found       = false;
		$a13_nava_id = '';
		//get shortcode's params
		$params = explode( '" ', $param_set );
		foreach ( $params as $param ) {
			$parts = explode( '=', $param );
			if ( $parts[0] == 'a13_nava_id' ) {
				$a13_nava_id = str_replace( '"', '', $parts[1] );
				$found       = true;
			}
		}

		if ( $found ) {
			update_post_meta( $a13_nava_id, 'a13_nava_page_slug', $a13_nava_page_slug );
		}
	}

	//search for navas with this page slug - means that those navas were assigned to this page
	//and remove orphans


}