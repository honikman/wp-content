<?php

/**
 * Collection of all theme widgets
 */

/* to unify look of post in widgets */
if ( ! function_exists( 'apollo13framework_widget_posts' ) ) {
	/**
	 * @param WP_Query $r        post query
	 * @param array    $instance current widget options
	 * @param string   $type     type of widget it will be used for
	 */
	function apollo13framework_widget_posts( $r, $instance, $type = 'normal' ) {
		while ( $r->have_posts() ) : $r->the_post();
			$page_title = get_the_title();

			echo '<div class="item">';

			echo '<a class="post-title" href="' . esc_url( get_permalink() ) . '" title="' . esc_attr( $page_title ) . '">' . $page_title . '</a>';
			if ( $type === 'popular' ) {
				echo '<a class="comments" href="' . get_comments_link() . '" title="' . get_comments_number() . ' ' . esc_html__( 'comment(s)', 'apollo13-framework' ) . '">' . get_comments_number() . ' ' . esc_html__( 'comment(s)', 'apollo13-framework' ) . '</a>';
			} else {
				echo apollo13framework_posted_on();
			}

			//if user want excerpt also and post is not password protected
			if ( ! empty( $instance['content'] ) && ! post_password_required() ) {
				echo '<a class="content" href="' . get_permalink() . '" title="' . esc_attr( $page_title ) . '">';
				$text = get_the_content( '' );
				$text = strip_shortcodes( $text );
				$text = wp_trim_words( $text, 30, '' );
				echo esc_html($text);
				echo '</a>';
			}
			echo '</div>';

		endwhile;
	}
}


if ( ! function_exists( 'apollo13framework_add_sidebars' ) ) {
	/**
	 * Functions that register all theme sidebars and register all theme widgets
	 *
	 */
	function apollo13framework_add_sidebars() {
		//defined sidebars
		$widget_areas = array(
			// Shown on blog
			'blog-widget-area'   => array(
				'name'        => esc_html__( 'Blog sidebar', 'apollo13-framework' ),
				'description' => esc_html__( 'Widgets from this sidebar will appear on blog, search results, archive page and 404 error page.', 'apollo13-framework' ),
			),
			// Shown in post
			'post-widget-area'   => array(
				'name'        => esc_html__( 'Post sidebar', 'apollo13-framework' ),
				'description' => esc_html__( 'Widgets from this sidebar will appear in single posts.', 'apollo13-framework' ),
			),
			// Shown in pages
			'page-widget-area'   => array(
				'name'        => esc_html__( 'Page sidebar', 'apollo13-framework' ),
				'description' => esc_html__( 'Widgets from this sidebar will appear in static pages.', 'apollo13-framework' ),
			),
			// Shown in shop pages
			'shop-widget-area'   => array(
				'name'        => esc_html__( 'Shop sidebar', 'apollo13-framework' ),
				'description' => esc_html__( 'Widgets from this sidebar will appear only in shop pages. Woocommerce have to be installed and activated.', 'apollo13-framework' ),
			),
			// Shown everywhere
			'side-widget-area'   => array(
				'name'        => esc_html__( 'Hidden sidebar', 'apollo13-framework' ),
				'description' => esc_html__( 'It is always available sidebar, that is activated by clicking on icon in header. Good for some special menus or other tips, information for user.', 'apollo13-framework' ),
			),
			// Shown everywhere
			'basket-widget-area' => array(
				'name'        => esc_html__( 'Basket sidebar', 'apollo13-framework' ),
				'description' => esc_html__( 'It is always available sidebar (but only active if woocommerce is installed and activated), that is activated by clicking on icon in header. You should place there cart widget and also some promotions widgets for example.', 'apollo13-framework' ),
			),
			// Shown in header
			'header-widget-area' => array(
				'name'          => esc_html__( 'Header(vertical) default widget area', 'apollo13-framework' ),
				'description'   => esc_html__( 'Widgets from this area will appear in vertical header only.', 'apollo13-framework' ),
			),
			// Shown in footer
			'footer-widget-area' => array(
				'name'          => esc_html__( 'Footer widget area(Header horizontal)', 'apollo13-framework' ),
				'description'   => esc_html__( 'Widgets from this area will appear in footer, only if horizontal header is used.', 'apollo13-framework' ),
			),
		);

		//custom sidebars
		global $apollo13framework_a13;
		$custom_sidebars = unserialize( $apollo13framework_a13->get_option( 'custom_sidebars' ) );
		if($custom_sidebars === false ){
			$custom_sidebars = array();
		}
		else{
			$custom_sidebars = is_array($custom_sidebars)? $custom_sidebars : array($custom_sidebars);
		}
		$sidebars_count  = count( $custom_sidebars );
		if ( is_array( $custom_sidebars ) && $sidebars_count > 0 ) {
			foreach ( $custom_sidebars as $sidebar ) {
				$widget_areas[ $sidebar['id'] ] = array(
					'name'        => $sidebar['name'],
					'description' => esc_html__( 'Widgets from this sidebar will appear in static pages.', 'apollo13-framework' ),
				);
			}
		}

		/**
		 * Register widgets areas
		 */
		foreach ( $widget_areas as $id => $sidebar ) {
			register_sidebar( array(
				'name'          => $sidebar['name'],
				'id'            => $id,
				'description'   => $sidebar['description'],
				'before_widget' => ( isset( $sidebar['before_widget'] ) ? $sidebar['before_widget'] : '<div id="%1$s" class="widget %2$s">' ),
				'after_widget'  => '</div>',
				'before_title'  => '<h3 class="title"><span>',
				'after_title'   => '</span></h3>',
			) );
		}


		class Apollo13_Widget_Recent_Posts extends WP_Widget {

			function __construct() {
				$widget_ops = array( 'classname'   => 'widget_recent_posts widget_about_posts',
				                     'description' => esc_html__( 'The most recent posts on your site', 'apollo13-framework' )
				);
				parent::__construct( 'recent-posts', esc_html__( 'Apollo13 - Recent Posts', 'apollo13-framework' ), $widget_ops );
				$this->alt_option_name = 'widget_recent_entries';

				add_action( 'save_post', array( &$this, 'flush_midget_cache' ) );
				add_action( 'deleted_post', array( &$this, 'flush_midget_cache' ) );
				add_action( 'switch_theme', array( &$this, 'flush_midget_cache' ) );
			}

			function widget( $args, $instance ) {
				$before_widget = $after_widget = $before_title = $after_title = '';
				$cache         = wp_cache_get( 'widget_recent_entries', 'widget' );

				if ( ! is_array( $cache ) ) {
					$cache = array();
				}

				if ( isset( $cache[ $args['widget_id'] ] ) ) {
					print $cache[ $args['widget_id'] ];

					return;
				}

				ob_start();
				extract( $args );

				$title = apply_filters( 'widget_title', empty( $instance['title'] ) ? esc_html__( 'Recent Posts', 'apollo13-framework' ) : $instance['title'], $instance, $this->id_base );
				if ( ! $number = absint( $instance['number'] ) ) {
					$number = 10;
				}

				$r = new WP_Query( array( 'posts_per_page'      => $number,
				                          'no_found_rows'       => true,
				                          'post_status'         => 'publish',
				                          'ignore_sticky_posts' => true
				) );
				if ( $r->have_posts() ) :
					print $before_widget;

					if ( $title ) {
						print $before_title . $title . $after_title;
					}

					apollo13framework_widget_posts( $r, $instance );

					print $after_widget;

					// Reset the global $the_post as this query will have stomped on it
					wp_reset_postdata();

				endif;

				$cache[ $args['widget_id'] ] = ob_get_flush();
				wp_cache_set( 'widget_recent_entries', $cache, 'widget' );
			}

			function update( $new_instance, $old_instance ) {
				$instance            = $old_instance;
				$instance['title']   = strip_tags( $new_instance['title'] );
				$instance['number']  = (int) $new_instance['number'];
				$instance['content'] = isset( $new_instance['content'] );

				$this->flush_midget_cache();

				$alloptions = wp_cache_get( 'alloptions', 'options' );
				if ( isset( $alloptions['widget_recent_entries'] ) ) {
					delete_option( 'widget_recent_entries' );
				}

				return $instance;
			}

			function flush_midget_cache() {
				wp_cache_delete( 'widget_recent_entries', 'widget' );
			}

			function form( $instance ) {
				$title  = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
				$number = isset( $instance['number'] ) ? absint( $instance['number'] ) : 5;
				?>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'apollo13-framework' ); ?></label>
					<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
				</p>

				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php esc_html_e( 'Number of posts to show:', 'apollo13-framework' ); ?></label>
					<input id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" size="3" />
				</p>

				<p>
					<input id="<?php echo esc_attr( $this->get_field_id( 'content' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'content' ) ); ?>" type="checkbox" <?php checked( isset( $instance['content'] ) ? $instance['content'] : 0 ); ?> />&nbsp;<label for="<?php echo esc_attr( $this->get_field_id( 'content' ) ); ?>"><?php esc_html_e( 'Add posts excerpt', 'apollo13-framework' ); ?></label>
				</p>
				<?php
			}
		}

		register_widget( 'Apollo13_Widget_Recent_Posts' );


		class Apollo13_Widget_Popular_Posts extends WP_Widget {

			function __construct() {
				$widget_ops = array( 'classname'   => 'widget_popular_entries widget_about_posts',
				                     'description' => esc_html__( 'The most popular posts on your site', 'apollo13-framework' )
				);
				parent::__construct( 'popular-posts', esc_html__( 'Popular Posts', 'apollo13-framework' ), $widget_ops );
				$this->alt_option_name = 'widget_popular_entries';

				add_action( 'save_post', array( &$this, 'flush_midget_cache' ) );
				add_action( 'deleted_post', array( &$this, 'flush_midget_cache' ) );
				add_action( 'switch_theme', array( &$this, 'flush_midget_cache' ) );
			}

			function widget( $args, $instance ) {
				$before_widget = $after_widget = $before_title = $after_title = '';
				$cache         = wp_cache_get( 'widget_popular_entries', 'widget' );

				if ( ! is_array( $cache ) ) {
					$cache = array();
				}

				if ( isset( $cache[ $args['widget_id'] ] ) ) {
					print $cache[ $args['widget_id'] ];

					return;
				}

				ob_start();
				extract( $args );

				$title = apply_filters( 'widget_title', empty( $instance['title'] ) ? esc_html__( 'Popular Posts', 'apollo13-framework' ) : $instance['title'], $instance, $this->id_base );
				if ( ! $number = absint( $instance['number'] ) ) {
					$number = 10;
				}

				$r = new WP_Query( array( 'posts_per_page'      => $number,
				                          'no_found_rows'       => true,
				                          'orderby'             => 'comment_count',
				                          'post_status'         => 'publish',
				                          'ignore_sticky_posts' => true
				) );
				if ( $r->have_posts() ) :
					print $before_widget;

					if ( $title ) {
						print $before_title . $title . $after_title;
					}

					apollo13framework_widget_posts( $r, $instance, 'popular' );

					print $after_widget;

					// Reset the global $the_post as this query will have stomped on it
					wp_reset_postdata();

				endif;

				$cache[ $args['widget_id'] ] = ob_get_flush();
				wp_cache_set( 'widget_popular_entries', $cache, 'widget' );
			}

			function update( $new_instance, $old_instance ) {
				$instance            = $old_instance;
				$instance['title']   = strip_tags( $new_instance['title'] );
				$instance['number']  = (int) $new_instance['number'];
				$instance['content'] = isset( $new_instance['content'] );

				$this->flush_midget_cache();

				$alloptions = wp_cache_get( 'alloptions', 'options' );
				if ( isset( $alloptions['widget_popular_entries'] ) ) {
					delete_option( 'widget_popular_entries' );
				}

				return $instance;
			}

			function flush_midget_cache() {
				wp_cache_delete( 'widget_popular_entries', 'widget' );
			}

			function form( $instance ) {
				$title  = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
				$number = isset( $instance['number'] ) ? absint( $instance['number'] ) : 5;
				?>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'apollo13-framework' ); ?></label>
					<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
				</p>

				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php esc_html_e( 'Number of posts to show:', 'apollo13-framework' ); ?></label>
					<input id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" size="3" />
				</p>

				<p>
					<input id="<?php echo esc_attr( $this->get_field_id( 'content' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'content' ) ); ?>" type="checkbox" <?php checked( isset( $instance['content'] ) ? $instance['content'] : 0 ); ?> />&nbsp;<label for="<?php echo esc_attr( $this->get_field_id( 'content' ) ); ?>"><?php esc_html_e( 'Add posts excerpt', 'apollo13-framework' ); ?></label>
				</p>
				<?php
			}
		}

		register_widget( 'Apollo13_Widget_Popular_Posts' );


		class Apollo13_Widget_Related_Posts extends WP_Widget {

			function __construct() {
				$widget_ops = array( 'classname'   => 'widget_related_entries widget_about_posts',
				                     'description' => esc_html__( 'Related posts to current post', 'apollo13-framework' )
				);
				parent::__construct( 'related-posts', esc_html__( 'Related Posts', 'apollo13-framework' ), $widget_ops );
				$this->alt_option_name = 'widget_related_entries';

				add_action( 'save_post', array( &$this, 'flush_midget_cache' ) );
				add_action( 'deleted_post', array( &$this, 'flush_midget_cache' ) );
				add_action( 'switch_theme', array( &$this, 'flush_midget_cache' ) );
			}

			function widget( $args, $instance ) {
				$before_widget = $after_widget = $before_title = $after_title = '';
				$cache         = wp_cache_get( 'widget_related_entries', 'widget' );

				if ( ! is_array( $cache ) ) {
					$cache = array();
				}

				if ( isset( $cache[ $args['widget_id'] ] ) ) {
					print $cache[ $args['widget_id'] ];

					return;
				}

				ob_start();
				extract( $args );

				$title = apply_filters( 'widget_title', empty( $instance['title'] ) ? esc_html__( 'Related Posts', 'apollo13-framework' ) : $instance['title'], $instance, $this->id_base );
				if ( ! $number = absint( $instance['number'] ) ) {
					$number = 10;
				}

				global $post;

				$__search      = wp_get_post_tags( $post->ID );
				$search_string = 'tags__in';
				//if no tags try categories
				if ( ! count( $__search ) ) {
					$__search      = wp_get_post_categories( $post->ID );
					$search_string = 'category__in';
				}

				if ( count( $__search ) ) {

					$r = new WP_Query( array( $search_string        => $__search,
					                          'post__not_in'        => array( $post->ID ),
					                          'posts_per_page'      => $number,
					                          'no_found_rows'       => true,
					                          'post_status'         => 'publish',
					                          'ignore_sticky_posts' => true
					) );
					if ( $r->have_posts() ) :
						print $before_widget;

						if ( $title ) {
							print $before_title . $title . $after_title;
						}

						apollo13framework_widget_posts( $r, $instance );

						print $after_widget;

						// Reset the global $the_post as this query will have stomped on it
						wp_reset_postdata();

					endif;

				}

				$cache[ $args['widget_id'] ] = ob_get_flush();
				wp_cache_set( 'widget_related_entries', $cache, 'widget' );
			}

			function update( $new_instance, $old_instance ) {
				$instance            = $old_instance;
				$instance['title']   = strip_tags( $new_instance['title'] );
				$instance['number']  = (int) $new_instance['number'];
				$instance['content'] = isset( $new_instance['content'] );

				$this->flush_midget_cache();

				$alloptions = wp_cache_get( 'alloptions', 'options' );
				if ( isset( $alloptions['widget_related_entries'] ) ) {
					delete_option( 'widget_related_entries' );
				}

				return $instance;
			}

			function flush_midget_cache() {
				wp_cache_delete( 'widget_related_entries', 'widget' );
			}

			function form( $instance ) {
				$title  = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
				$number = isset( $instance['number'] ) ? absint( $instance['number'] ) : 5;
				?>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'apollo13-framework' ); ?></label>
					<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
				</p>

				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php esc_html_e( 'Number of posts to show:', 'apollo13-framework' ); ?></label>
					<input id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" size="3" />
				</p>

				<p>
					<input id="<?php echo esc_attr( $this->get_field_id( 'content' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'content' ) ); ?>" type="checkbox" <?php checked( isset( $instance['content'] ) ? $instance['content'] : 0 ); ?> />&nbsp;<label for="<?php echo esc_attr( $this->get_field_id( 'content' ) ); ?>"><?php esc_html_e( 'Add posts excerpt', 'apollo13-framework' ); ?></label>
				</p>
				<?php
			}
		}

		register_widget( 'Apollo13_Widget_Related_Posts' );


		class Apollo13_Nav_Menu_Widget extends WP_Widget {

			function __construct() {
				$widget_ops = array( 'description' => esc_html__( 'Use this widget to add one of your custom menus as a widget.', 'apollo13-framework' ) );
				parent::__construct( 'nav_menu', esc_html__( 'Apollo13 - Custom Menu', 'apollo13-framework' ), $widget_ops );
			}

			function widget( $args, $instance ) {
				// Get menu
				$nav_menu = ! empty( $instance['nav_menu'] ) ? wp_get_nav_menu_object( $instance['nav_menu'] ) : false;

				if ( ! $nav_menu ) {
					return;
				}

				$instance['title'] = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

				print $args['before_widget'];

				if ( ! empty( $instance['title'] ) ) {
					print $args['before_title'] . $instance['title'] . $args['after_title'];
				}

				wp_nav_menu( array( 'fallback_cb' => '', 'menu' => $nav_menu, 'walker' => new A13FRAMEWORK_custom_menu_widget_walker ) );

				print $args['after_widget'];
			}

			function update( $new_instance, $old_instance ) {
				$instance['title']    = strip_tags( stripslashes( $new_instance['title'] ) );
				$instance['nav_menu'] = (int) $new_instance['nav_menu'];

				return $instance;
			}

			function form( $instance ) {
				$title    = isset( $instance['title'] ) ? $instance['title'] : '';
				$nav_menu = isset( $instance['nav_menu'] ) ? $instance['nav_menu'] : '';

				// Get menus
				$menus = get_terms( array( 'taxonomy' => 'nav_menu', 'hide_empty' => false ) );

				// If no menus exists, direct the user to go and create some.
				if ( ! $menus ) {
					echo '<p>' . sprintf( wp_kses_data( __( 'No menus have been created yet. <a href="%s">Create some</a>.', 'apollo13-framework' ) ), esc_url( admin_url( 'nav-menus.php' ) ) ) . '</p>';

					return;
				}
				?>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'apollo13-framework' ); ?></label>
					<input type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" value="<?php echo esc_attr( $title ); ?>" />
				</p>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'nav_menu' ) ); ?>"><?php esc_html_e( 'Select Menu:', 'apollo13-framework' ); ?></label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'nav_menu' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'nav_menu' ) ); ?>">
						<?php
						foreach ( $menus as $menu ) {
							echo '<option value="' . esc_attr( $menu->term_id ) . '"'
							     . selected( $nav_menu, $menu->term_id, false )
							     . '>' . $menu->name . '</option>';
						}
						?>
					</select>
				</p>
				<?php
			}
		}

		register_widget( 'Apollo13_Nav_Menu_Widget' );


		class Apollo13_Widget_Recent_Albums extends WP_Widget {

			function __construct() {
				$widget_ops = array( 'classname'   => 'widget_recent_albums widget_recent_cpt',
				                     'description' => esc_html__( 'Your most recent added albums', 'apollo13-framework' )
				);
				parent::__construct( 'recent-albums', esc_html__( 'Recent Albums', 'apollo13-framework' ), $widget_ops );
				$this->alt_option_name = 'widget_recent_albums';

				add_action( 'save_post', array( &$this, 'flush_midget_cache' ) );
				add_action( 'deleted_post', array( &$this, 'flush_midget_cache' ) );
				add_action( 'switch_theme', array( &$this, 'flush_midget_cache' ) );
			}

			function widget( $args, $instance ) {
				$before_widget = $after_widget = $before_title = $after_title = '';
				$cache         = wp_cache_get( 'widget_recent_albums', 'widget' );

				if ( ! is_array( $cache ) ) {
					$cache = array();
				}

				if ( isset( $cache[ $args['widget_id'] ] ) ) {
					print $cache[ $args['widget_id'] ];

					return;
				}

				ob_start();
				extract( $args );

				$title = apply_filters( 'widget_title', empty( $instance['title'] ) ? esc_html__( 'Recent Albums', 'apollo13-framework' ) : $instance['title'], $instance, $this->id_base );
				if ( ! $number = absint( $instance['number'] ) ) {
					$number = 10;
				}

				$r = new WP_Query( array(
					'posts_per_page'      => $number,
					'no_found_rows'       => true,
					'post_type'           => A13FRAMEWORK_CUSTOM_POST_TYPE_ALBUM,
					'post_status'         => 'publish',
					'ignore_sticky_posts' => true,
					'orderby'             => 'date'
				) );
				if ( $r->have_posts() ) :
					print $before_widget;

					if ( $title ) {
						print $before_title . $title . $after_title;
					}

					echo '<div class="items clearfix">';

					while ( $r->have_posts() ) : $r->the_post();
						//title
						$page_title = get_the_title();

						//image
						$img = apollo13framework_make_album_image( get_the_ID(), array( 100, 100 ) );
						echo '<div class="item"><a href="' . get_permalink() . '" title="' . esc_attr( $page_title ) . '">' . $img . '</a></div>';

					endwhile;

					echo '</div>';

					print $after_widget;

					// Reset the global $the_post as this query will have stomped on it
					wp_reset_postdata();

				endif;

				$cache[ $args['widget_id'] ] = ob_get_flush();
				wp_cache_set( 'widget_recent_albums', $cache, 'widget' );
			}

			function update( $new_instance, $old_instance ) {
				$instance           = $old_instance;
				$instance['title']  = strip_tags( $new_instance['title'] );
				$instance['number'] = (int) $new_instance['number'];

				$this->flush_midget_cache();

				$alloptions = wp_cache_get( 'alloptions', 'options' );
				if ( isset( $alloptions['widget_recent_albums'] ) ) {
					delete_option( 'widget_recent_albums' );
				}

				return $instance;
			}

			function flush_midget_cache() {
				wp_cache_delete( 'widget_recent_albums', 'widget' );
			}

			function form( $instance ) {
				$title  = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
				$number = isset( $instance['number'] ) ? absint( $instance['number'] ) : 5;
				?>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'apollo13-framework' ); ?></label>
					<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
				</p>

				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php esc_html_e( 'Number of posts to show:', 'apollo13-framework' ); ?></label>
					<input id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" size="3" />
				</p>
				<?php
			}
		}

		register_widget( 'Apollo13_Widget_Recent_Albums' );


		class Apollo13_Widget_Recent_Works extends WP_Widget {

			function __construct() {
				$widget_ops = array( 'classname'   => 'widget_recent_works widget_recent_cpt',
				                     'description' => esc_html__( 'Your most recent added works', 'apollo13-framework' )
				);
				parent::__construct( 'recent-works', esc_html__( 'Recent Works', 'apollo13-framework' ), $widget_ops );
				$this->alt_option_name = 'widget_recent_works';

				add_action( 'save_post', array( &$this, 'flush_midget_cache' ) );
				add_action( 'deleted_post', array( &$this, 'flush_midget_cache' ) );
				add_action( 'switch_theme', array( &$this, 'flush_midget_cache' ) );
			}

			function widget( $args, $instance ) {
				$before_widget = $after_widget = $before_title = $after_title = '';
				$cache         = wp_cache_get( 'widget_recent_works', 'widget' );

				if ( ! is_array( $cache ) ) {
					$cache = array();
				}

				if ( isset( $cache[ $args['widget_id'] ] ) ) {
					print $cache[ $args['widget_id'] ];

					return;
				}

				ob_start();
				extract( $args );

				$title = apply_filters( 'widget_title', empty( $instance['title'] ) ? esc_html__( 'Recent Works', 'apollo13-framework' ) : $instance['title'], $instance, $this->id_base );
				if ( ! $number = absint( $instance['number'] ) ) {
					$number = 10;
				}

				$r = new WP_Query( array(
					'posts_per_page'      => $number,
					'no_found_rows'       => true,
					'post_type'           => A13FRAMEWORK_CUSTOM_POST_TYPE_WORK,
					'post_status'         => 'publish',
					'ignore_sticky_posts' => true,
					'orderby'             => 'date'
				) );
				if ( $r->have_posts() ) :
					print $before_widget;

					if ( $title ) {
						print $before_title . $title . $after_title;
					}

					echo '<div class="items clearfix">';

					while ( $r->have_posts() ) : $r->the_post();
						//title
						$page_title = get_the_title();

						//image
						$img = apollo13framework_make_work_image( get_the_ID(), array( 100, 100 ) );
						echo '<div class="item"><a href="' . get_permalink() . '" title="' . esc_attr( $page_title ) . '">' . $img . '</a></div>';

					endwhile;

					echo '</div>';

					print $after_widget;

					// Reset the global $the_post as this query will have stomped on it
					wp_reset_postdata();

				endif;

				$cache[ $args['widget_id'] ] = ob_get_flush();
				wp_cache_set( 'widget_recent_works', $cache, 'widget' );
			}

			function update( $new_instance, $old_instance ) {
				$instance           = $old_instance;
				$instance['title']  = strip_tags( $new_instance['title'] );
				$instance['number'] = (int) $new_instance['number'];

				$this->flush_midget_cache();

				$alloptions = wp_cache_get( 'alloptions', 'options' );
				if ( isset( $alloptions['widget_recent_works'] ) ) {
					delete_option( 'widget_recent_works' );
				}

				return $instance;
			}

			function flush_midget_cache() {
				wp_cache_delete( 'widget_recent_works', 'widget' );
			}

			function form( $instance ) {
				$title  = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
				$number = isset( $instance['number'] ) ? absint( $instance['number'] ) : 5;
				?>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'apollo13-framework' ); ?></label>
					<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
				</p>

				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php esc_html_e( 'Number of posts to show:', 'apollo13-framework' ); ?></label>
					<input id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" size="3" />
				</p>
				<?php
			}
		}

		register_widget( 'Apollo13_Widget_Recent_Works' );

		class Apollo13_Widget_Contact_Info extends WP_Widget {

			function __construct() {
				$widget_ops = array( 'classname'   => 'widget_contact_info',
				                     'description' => esc_html__( 'Contact information', 'apollo13-framework' )
				);
				parent::__construct( 'contact-info', esc_html__( 'Contact information', 'apollo13-framework' ), $widget_ops );
				$this->alt_option_name = 'widget_contact_info';

				add_action( 'save_post', array( &$this, 'flush_midget_cache' ) );
				add_action( 'deleted_post', array( &$this, 'flush_midget_cache' ) );
				add_action( 'switch_theme', array( &$this, 'flush_midget_cache' ) );
			}

			function widget( $args, $instance ) {
				$before_widget = $after_widget = $before_title = $after_title = '';
				$cache         = wp_cache_get( 'widget_contact_info', 'widget' );

				if ( ! is_array( $cache ) ) {
					$cache = array();
				}

				if ( isset( $cache[ $args['widget_id'] ] ) ) {
					print $cache[ $args['widget_id'] ];

					return;
				}

				ob_start();
				extract( $args );

				$title = apply_filters( 'widget_title', empty( $instance['title'] ) ? esc_html__( 'Contact information', 'apollo13-framework' ) : $instance['title'], $instance, $this->id_base );

				print $before_widget;

				if ( $title ) {
					print $before_title . $title . $after_title;
				}

				echo '<div class="info">';

				if ( ! empty( $instance['content'] ) ) {
					echo '<div class="content-text">' . nl2br( wp_kses_data( balanceTags( $instance['content'], true ) ) )  . '</div>';
				}
				if ( ! empty( $instance['phone'] ) ) {
					echo '<div class="phone with_icon"><i class="fa fa-phone"></i>' . esc_html( $instance['phone'] ) . '</div>';
				}
				if ( ! empty( $instance['fax'] ) ) {
					echo '<div class="fax with_icon"><i class="fa fa-print"></i>' . esc_html( $instance['fax'] ) . '</div>';
				}
				if ( ! empty( $instance['email'] ) ) {
					$email = $instance['email'];
					$email = sanitize_email($email);
					echo '<a class="email with_icon" href="mailto:'.antispambot($email,1).'"><i class="fa fa-envelope-o"></i>'.antispambot($email).'</a>';
				}
				if ( ! empty( $instance['www'] ) ) {
					echo '<a class="www with_icon" href="' . esc_url( $instance['www'] ) . '"><i class="fa fa-external-link"></i>' . esc_html( $instance['www'] ) . '</a>';
				}
				if ( ! empty( $instance['open'] ) ) {
					echo '<div class="content-open with_icon"><i class="fa fa-clock-o"></i>' . nl2br( wp_kses_data( balanceTags( $instance['open'], true ) ) ) . '</div>';
				}

				echo '</div>';

				print $after_widget;

				$cache[ $args['widget_id'] ] = ob_get_flush();
				wp_cache_set( 'widget_related_entries', $cache, 'widget' );
			}

			function update( $new_instance, $old_instance ) {
				$instance            = $old_instance;
				$instance['title']   = strip_tags( $new_instance['title'] );
				$instance['phone']   = strip_tags( $new_instance['phone'] );
				$instance['email']   = strip_tags( $new_instance['email'] );
				$instance['fax']     = strip_tags( $new_instance['fax'] );
				$instance['www']     = strip_tags( $new_instance['www'] );
				$instance['content'] = $new_instance['content'];
				$instance['open']    = strip_tags( $new_instance['open'] );

				$this->flush_midget_cache();

				$alloptions = wp_cache_get( 'alloptions', 'options' );
				if ( isset( $alloptions['widget_contact_info'] ) ) {
					delete_option( 'widget_contact_info' );
				}

				return $instance;
			}

			function flush_midget_cache() {
				wp_cache_delete( 'widget_contact_info', 'widget' );
			}

			function form( $instance ) {
				$title   = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
				$phone   = isset( $instance['phone'] ) ? esc_attr( $instance['phone'] ) : '';
				$email   = isset( $instance['email'] ) ? esc_attr( $instance['email'] ) : '';
				$fax     = isset( $instance['fax'] ) ? esc_attr( $instance['fax'] ) : '';
				$www     = isset( $instance['www'] ) ? esc_attr( $instance['www'] ) : '';
				$content = isset( $instance['content'] ) ? esc_textarea( $instance['content'] ) : '';
				$open    = isset( $instance['open'] ) ? esc_textarea( $instance['open'] ) : '';
				?>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'apollo13-framework' ); ?></label>
					<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
				</p>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'content' ) ); ?>"><?php esc_html_e( 'Content:', 'apollo13-framework' ); ?></label>
					<textarea class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'content' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'content' ) ); ?>" cols="20" rows="8"><?php echo esc_textarea( $content ); ?></textarea>
				</p>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'phone' ) ); ?>"><?php esc_html_e( 'Phone:', 'apollo13-framework' ); ?></label>
					<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'phone' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'phone' ) ); ?>" type="text" value="<?php echo esc_attr( $phone ); ?>" />
				</p>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'fax' ) ); ?>"><?php esc_html_e( 'Fax:', 'apollo13-framework' ); ?></label>
					<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'fax' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'fax' ) ); ?>" type="text" value="<?php echo esc_attr( $fax ); ?>" />
				</p>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'email' ) ); ?>"><?php esc_html_e( 'E-mail:', 'apollo13-framework' ); ?></label>
					<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'email' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'email' ) ); ?>" type="text" value="<?php echo esc_attr( $email ); ?>" />
				</p>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'www' ) ); ?>"><?php esc_html_e( 'Site:', 'apollo13-framework' ); ?></label>
					<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'www' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'www' ) ); ?>" type="text" value="<?php echo esc_attr( $www ); ?>" />
				</p>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'open' ) ); ?>"><?php esc_html_e( 'Open hours info:', 'apollo13-framework' ); ?></label>
					<textarea class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'open' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'open' ) ); ?>" cols="20" rows="8"><?php echo esc_textarea( $open ); ?></textarea>
				</p>

				<?php
			}
		}

		register_widget( 'Apollo13_Widget_Contact_Info' );


		class Apollo13_Widget_Shortcodes extends WP_Widget {

			function __construct() {
				$widget_ops  = array(
					'classname'   => 'widget_shortcodes',
					'description' => esc_html__( 'Widget to put shortcodes in', 'apollo13-framework' )
				);
				$control_ops = array( 'width' => 400, 'height' => 350 );
				parent::__construct( 'a13-shortcodes', esc_html__( 'Shortcodes', 'apollo13-framework' ), $widget_ops, $control_ops );
			}

			function widget( $args, $instance ) {
				$before_widget = $after_widget = $before_title = $after_title = '';
				extract( $args );
				$title = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );
				$text  = apply_filters( 'widget_text', empty( $instance['text'] ) ? '' : $instance['text'], $instance );
				print $before_widget;
				if ( ! empty( $title ) ) {
					print $before_title . $title . $after_title;
				} ?>
				<div class="textwidget"><?php echo do_shortcode( $text ); ?></div>
				<?php
				print $after_widget;
			}

			function update( $new_instance, $old_instance ) {
				$instance          = $old_instance;
				$instance['title'] = strip_tags( $new_instance['title'] );
				if ( current_user_can( 'unfiltered_html' ) ) {
					$instance['text'] = $new_instance['text'];
				} else {
					$instance['text'] = stripslashes( wp_filter_post_kses( addslashes( $new_instance['text'] ) ) );
				} // wp_filter_post_kses() expects slashed
				$instance['filter'] = isset( $new_instance['filter'] );

				return $instance;
			}

			function form( $instance ) {
				$instance = wp_parse_args( (array) $instance, array( 'title' => '', 'text' => '' ) );
				$title    = strip_tags( $instance['title'] );
				$text     = esc_textarea( $instance['text'] );
				?>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'apollo13-framework' ); ?></label>
					<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
				</p>

				<label for="<?php echo esc_attr( $this->get_field_id( 'text' ) ); ?>"><?php esc_html_e( 'Content:', 'apollo13-framework' ); ?></label>
				<textarea class="widefat" rows="16" cols="20" id="<?php echo esc_attr( $this->get_field_id( 'text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'text' ) ); ?>"><?php echo esc_textarea( $text ); ?></textarea>

				<p>
					<input id="<?php echo esc_attr( $this->get_field_id( 'filter' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'filter' ) ); ?>" type="checkbox" <?php checked( isset( $instance['filter'] ) ? $instance['filter'] : 0 ); ?> />&nbsp;<label for="<?php echo esc_attr( $this->get_field_id( 'filter' ) ); ?>"><?php esc_html_e( 'Automatically add paragraphs', 'apollo13-framework' ); ?></label>
				</p>
				<?php
			}
		}

		register_widget( 'Apollo13_Widget_Shortcodes' );

		class Apollo13_Widget_Social_Icons extends WP_Widget {

			function __construct() {
				$widget_ops = array( 'classname'   => 'widget_a13_social_icons',
				                     'description' => esc_html__( 'Social icons form theme settings', 'apollo13-framework' )
				);
				parent::__construct( 'a13-social-icons', esc_html__( 'Apollo13 Social Icons', 'apollo13-framework' ), $widget_ops );
				$this->alt_option_name = 'widget_a13_social_icons';

				add_action( 'save_post', array( &$this, 'flush_midget_cache' ) );
				add_action( 'deleted_post', array( &$this, 'flush_midget_cache' ) );
				add_action( 'switch_theme', array( &$this, 'flush_midget_cache' ) );
			}

			function widget( $args, $instance ) {
				$before_widget = $after_widget = $before_title = $after_title = '';
				$cache         = wp_cache_get( 'widget_a13_social_icons', 'widget' );

				if ( ! is_array( $cache ) ) {
					$cache = array();
				}

				if ( isset( $cache[ $args['widget_id'] ] ) ) {
					print $cache[ $args['widget_id'] ];

					return;
				}

				ob_start();
				extract( $args );

				$title = apply_filters( 'widget_title', $instance['title'], $instance, $this->id_base );

				$icons = apollo13framework_social_icons( $instance['icons_color'], $instance['icons_color_hover'] );
				if ( strlen( $icons ) ) :
					print $before_widget;

					if ( $title ) {
						print $before_title . $title . $after_title;
					}

					print $icons;

					print $after_widget;

				endif;

				$cache[ $args['widget_id'] ] = ob_get_flush();
				wp_cache_set( 'widget_a13_social_icons', $cache, 'widget' );
			}

			function update( $new_instance, $old_instance ) {
				$instance                = $old_instance;
				$instance['title']       = strip_tags( $new_instance['title'] );
				$instance['icons_color'] = $new_instance['icons_color'];
				$instance['icons_color_hover'] = $new_instance['icons_color_hover'];

				$this->flush_midget_cache();

				$alloptions = wp_cache_get( 'alloptions', 'options' );
				if ( isset( $alloptions['widget_a13_social_icons'] ) ) {
					delete_option( 'widget_a13_social_icons' );
				}

				return $instance;
			}

			function flush_midget_cache() {
				wp_cache_delete( 'widget_a13_social_icons', 'widget' );
			}

			function form( $instance ) {
				$title = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
				$color = isset( $instance['icons_color'] ) ? esc_attr( $instance['icons_color'] ) : '';
				$color_hover = isset( $instance['icons_color_hover'] ) ? esc_attr( $instance['icons_color_hover'] ) : '';
				$options = array(
					'black'    => esc_html__( 'Black', 'apollo13-framework' ),
					'color'    => esc_html__( 'Color', 'apollo13-framework' ),
					'white'    => esc_html__( 'White', 'apollo13-framework' ),
					'outlined' => esc_html__( 'Outlined', 'apollo13-framework' ),
				);
				?>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'apollo13-framework' ); ?></label>
					<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
				</p>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'icons_color' ) ); ?>"><?php esc_html_e( 'Icons color:', 'apollo13-framework' ); ?></label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'icons_color' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'icons_color' ) ); ?>">
						<?php foreach($options as $id => $name){
							echo '<option value="'.$id.'"'.selected( $color, $id ).'>'.$name.'</option>';
						} ?>
					</select>
				</p>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'icons_color_hover' ) ); ?>"><?php esc_html_e( 'Icons color on hover:', 'apollo13-framework' ); ?></label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'icons_color_hover' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'icons_color_hover' ) ); ?>">
						<?php foreach($options as $id => $name){
							echo '<option value="'.$id.'"'.selected( $color_hover, $id ).'>'.$name.'</option>';
						} ?>
					</select>
				</p>
				<?php
			}
		}

		register_widget( 'Apollo13_Widget_Social_Icons' );

		class Apollo13_Widget_Filter extends WP_Widget {

			function __construct() {
				$widget_ops = array( 'classname'   => 'widget_filter',
				                     'description' => esc_html__( 'Filter Albums, Works or Posts', 'apollo13-framework' )
				);
				parent::__construct( 'filter', esc_html__( 'Filter', 'apollo13-framework' ), $widget_ops );
				$this->alt_option_name = 'widget_contact_info';

				add_action( 'save_post', array( &$this, 'flush_midget_cache' ) );
				add_action( 'deleted_post', array( &$this, 'flush_midget_cache' ) );
				add_action( 'switch_theme', array( &$this, 'flush_midget_cache' ) );
			}

			function widget( $args, $instance ) {
				$before_widget = $after_widget = $before_title = $after_title = '';
				$cache         = wp_cache_get( 'widget_contact_info', 'widget' );

				if ( ! is_array( $cache ) ) {
					$cache = array();
				}

				if ( isset( $cache[ $args['widget_id'] ] ) ) {
					print $cache[ $args['widget_id'] ];

					return;
				}

				ob_start();
				extract( $args );

				$page_type = apollo13framework_what_page_type_is_it();
				//get field
				$filter      = $instance['filter'];
				$albums_list = $filter === 'albums' && $page_type['albums_list'];
				$works_list = $filter === 'works' && $page_type['works_list'];
				$posts_list  = $filter === 'blog' && $page_type['blog_type'];

				if($page_type['search']){
					//we don't display filter on search reasult page
					return;
				}

				//filter will be usable here?
				if ( $albums_list || $works_list || $posts_list ) {
					$terms = array();
					//albums
					if ( $albums_list ) {
						$category_template = defined( 'A13FRAMEWORK_ALBUM_GENRE_TEMPLATE' );

						//prepare filter
						$query_args = array(
							'taxonomy' => A13FRAMEWORK_CPT_ALBUM_TAXONOMY,
							'hide_empty' => true,
							'parent'     => 0,
						);

						if ( $category_template === true ) {
							$term_slug = get_query_var( 'term' );
							if ( ! empty( $term_slug ) ) {
								$term_obj             = get_term_by( 'slug', $term_slug, A13FRAMEWORK_CPT_ALBUM_TAXONOMY );
								$term_id              = $term_obj->term_id;
								$query_args['parent'] = $term_id;
							}
						}
						$terms = get_terms( $query_args );
					}
					//works
					if ( $works_list ) {
						$category_template = defined( 'A13FRAMEWORK_WORK_GENRE_TEMPLATE' );

						//prepare filter
						$query_args = array(
							'taxonomy' => A13FRAMEWORK_CPT_WORK_TAXONOMY,
							'hide_empty' => true,
							'parent'     => 0,
						);

						if ( $category_template === true ) {
							$term_slug = get_query_var( 'term' );
							if ( ! empty( $term_slug ) ) {
								$term_obj             = get_term_by( 'slug', $term_slug, A13FRAMEWORK_CPT_WORK_TAXONOMY );
								$term_id              = $term_obj->term_id;
								$query_args['parent'] = $term_id;
							}
						}
						$terms = get_terms( $query_args );
					}
					//blog
					elseif ( $posts_list ) {
						$category_template = is_category();

						$query_args = array(
							'hide_empty' => true,
							'parent'     => 0,
						);

						if ( $category_template === true ) {
							$term_id = get_query_var( 'cat' );
							if ( ! empty( $term_id ) ) {
								$query_args['parent'] = $term_id;
							}
						}

						$terms = get_categories( $query_args );
					}

					if ( count( $terms ) ):
						$title = apply_filters( 'widget_title', empty( $instance['title'] ) ? esc_html__( 'Filter', 'apollo13-framework' ) : $instance['title'], $instance, $this->id_base );

						print $before_widget;

						if ( $title ) {
							print $before_title . $title . $after_title;
						}


						echo '<ul class="' . $filter . '-filter">';

						echo '<li class="selected" data-filter="__all"><a href="' . apollo13framework_current_url() . '"><i class="fa fa-square-o"></i>' . esc_html__( 'All', 'apollo13-framework' ) . '</a></li>';
						foreach ( $terms as $term ) {
							echo '<li data-filter="' . $term->term_id . '"><a href="' . esc_url( get_term_link( $term ) ) . '"><i class="fa fa-square-o"></i>' . $term->name . '</a></li>';
						}

						echo '</ul>';

						print $after_widget;
					endif;


				}

				$cache[ $args['widget_id'] ] = ob_get_flush();
				wp_cache_set( 'widget_related_entries', $cache, 'widget' );
			}

			function update( $new_instance, $old_instance ) {
				$instance           = $old_instance;
				$instance['filter'] = $new_instance['filter'];

				$this->flush_midget_cache();

				$alloptions = wp_cache_get( 'alloptions', 'options' );
				if ( isset( $alloptions['widget_filter'] ) ) {
					delete_option( 'widget_filter' );
				}

				return $instance;
			}

			function flush_midget_cache() {
				wp_cache_delete( 'widget_filter', 'widget' );
			}

			function form( $instance ) {
				$filter  = isset( $instance['filter'] ) ? esc_attr( $instance['filter'] ) : '';
				$options = array(
					'blog'   => esc_html__( 'Blog - will appear in sidebar only if current page is main blog page.', 'apollo13-framework' ),
					'albums' => esc_html__( 'Albums - will appear in sidebar only if current page is albums list, or category of Albums.', 'apollo13-framework' ),
					'works' => esc_html__( 'Works - will appear in sidebar only if current page is works list, or category of Works.', 'apollo13-framework' )
				);
				?>
				<p><?php esc_html_e( 'Filter for:', 'apollo13-framework' ); ?></p>
				<?php
				foreach ( $options as $id => $name ) {
					$checked = $id === $filter ? 'checked="checked"' : '';
					echo '<p><label><input class="widefat" name="' . esc_attr( $this->get_field_name( 'filter' ) ) . '" type="radio" value="' . $id . '" ' . $checked . ' />' . $name . '</label></p>';
				}
				?>
				<hr />
				<p><em><?php esc_html_e( 'It filters by categories', 'apollo13-framework' ); ?></em></p>

				<?php
			}
		}

		register_widget( 'Apollo13_Widget_Filter' );

	}
}

add_action( 'widgets_init', 'apollo13framework_add_sidebars' );
?>