<?php

function apollo13framework_meta_boxes_post() {
	global $apollo13framework_a13;

	$header_sidebars = array(
		'G'   => __( 'Global settings', 'apollo13-framework' ),
		'off' => __( 'Off', 'apollo13-framework' ),
	);

	$custom_sidebars = unserialize( $apollo13framework_a13->get_option( 'custom_sidebars' ) );
	$custom_sidebars = is_array($custom_sidebars)? $custom_sidebars : array($custom_sidebars);
	$sidebars_count  = count( $custom_sidebars );
	if ( is_array( $custom_sidebars ) && $sidebars_count > 0 ) {
		foreach ( $custom_sidebars as $sidebar ) {
			$header_sidebars[ $sidebar['id'] ] = $sidebar['name'];
		}
	}

	$meta = array(
		/*
		 *
		 * Tab: Posts list
		 *
		 */
		array(
			'name' => __('Posts list', 'apollo13-framework'),
			'type' => 'fieldset',
			'tab'   => true,
			'icon'  => 'fa fa-list'
		),
		array(
			'name'        => __( 'Alternative Link', 'apollo13-framework' ),
			'description' => __( 'If you fill this then when selecting post from Blog(post list), it will lead to this link instead of opening post.', 'apollo13-framework' ),
			'id'          => 'alt_link',
			'default'     => '',
			'type'        => 'text',
		),
		array(
			'name'        => __( 'Size of brick', 'apollo13-framework' ),
			'description' => __( 'How many bricks area should take this post in posts list.', 'apollo13-framework' ),
			'id'          => 'brick_ratio_x',
			'default'     => 1,
			'unit'        => '',
			'min'         => 1,
			'max'         => 4,
			'type'        => 'slider'
		),


		/*
		 *
		 * Tab: Featured media
		 *
		 */
		array(
			'name' => __('Featured media', 'apollo13-framework'),
			'type' => 'fieldset',
			'tab'   => true,
			'icon'  => 'fa fa-star'
		),
		array(
			'name'        => __( 'Post media', 'apollo13-framework' ),
			'description' => __( 'Choose between Image, Video and Sliders. For image use Featured Image Option. For <strong>Images slider</strong> you need plugin <a href="https://wordpress.org/plugins/featured-galleries/" target="_blank">Featured galleries</a>.', 'apollo13-framework' ),
			'id'          => 'image_or_video',
			'default'     => 'post_image',
			'options'     => array(
				'post_image'  => __( 'Image', 'apollo13-framework' ),
				'post_slider' => __( 'Images slider', 'apollo13-framework' ),
				'post_video'  => __( 'Video', 'apollo13-framework' ),
			),
			'type'        => 'radio',
		),
		array(
			'name'        => __( 'Featured image parallax', 'apollo13-framework' ),
			'description' => __( 'It will limit image height, so parallax could take effect.', 'apollo13-framework' ),
			'id'          => 'image_parallax',
			'default'     => 'off',
			'type'        => 'radio',
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'required'    => array( 'image_or_video', '=', 'post_image' ),
		),
		array(
			'name'     => __( 'Parallax area height', 'apollo13-framework' ),
			'id'       => 'image_parallax_height',
			'default'  => '260',
			'unit'     => 'px',
			'min'      => 100,
			'max'      => 600,
			'type'     => 'slider',
			'required' => array(
				array( 'image_or_video', '=', 'post_image' ),
				array( 'image_parallax', '=', 'on' ),
			)
		),
		array(
			'name'              => __( 'Link to video', 'apollo13-framework' ),
			'description'       => __( 'Insert here link to your video file or upload it. You can also add video from youtube or vimeo by pasting here link to movie.', 'apollo13-framework' ),
			'id'                => 'post_video',
			'default'           => '',
			'type'              => 'upload',
			'button_text'       => __( 'Upload media file', 'apollo13-framework' ),
			'media_button_text' => __( 'Insert media file', 'apollo13-framework' ),
			'media_type'        => 'video', /* 'audio,video' */
			'required'          => array( 'image_or_video', '=', 'post_video' ),
		),

		/*
		 *
		 * Tab: Header
		 *
		 */
		array(
			'name' => __('Header', 'apollo13-framework'),
			'type' => 'fieldset',
			'tab'   => true,
			'icon'  => 'fa fa-cogs'
		),
		array(
			'name'          => __( 'Hide content under header', 'apollo13-framework' ),
			'description'   => __( 'Only valid when using horizontal header.', 'apollo13-framework' ),
			'id'            => 'content_under_header',
			'global_value'  => 'G',
			'default'       => 'G',
			'parent_option' => 'post_content_under_header',
			'type'          => 'select',
			'options'       => array(
				'G'       => __( 'Global settings', 'apollo13-framework' ),
				'content' => __( 'Yes hide content', 'apollo13-framework' ),
				'title'   => __( 'Yes hide content and add top padding to outside title bar.', 'apollo13-framework' ),
				'off'     => __( 'Turn it off', 'apollo13-framework' ),
			),
		),
		array(
			'name'          => __( 'Header color variant', 'apollo13-framework' ),
			'description'   => __( 'Only valid when using horizontal header.', 'apollo13-framework' ),
			'id'            => 'horizontal_header_color_variant',
			'global_value'  => 'G',
			'default'       => 'G',
			'parent_option' => 'post_horizontal_header_color_variant',
			'paid'          => 1,
			'type'          => 'select',
			'options'       => array(
				'G'      => __( 'Global settings', 'apollo13-framework' ),
				'normal' => __( 'Normal', 'apollo13-framework' ),
				'light'  => __( 'Light', 'apollo13-framework' ),
				'dark'   => __( 'Dark', 'apollo13-framework' ),
			),
		),
		array(
			'name'          => __( 'Header custom sidebar', 'apollo13-framework' ),
			'description'   => __( 'Works only with vertical header. Special widgets that should be shown on this page in header.', 'apollo13-framework' ),
			'id'            => 'header_custom_sidebar',
			'global_value'  => 'G',
			'default'       => 'G',
			'parent_option' => 'header_custom_sidebar',
			'options'       => $header_sidebars,
			'paid'          => 1,
			'type'          => 'select',
		),

		/*
		 *
		 * Tab: Title bar
		 *
		 */
		array(
			'name' => __('Title bar', 'apollo13-framework'),
			'type' => 'fieldset',
			'tab'   => true,
			'icon'  => 'fa fa-text-width'
		),
		array(
			'name'        => __( 'Title bar look', 'apollo13-framework' ),
			'description' => __( 'You can use global settings or overwrite them here', 'apollo13-framework' ),
			'id'          => 'title_bar_settings',
			'default'     => 'global',
			'type'        => 'radio',
			'options'     => array(
				'global' => __( 'Global settings', 'apollo13-framework' ),
				'custom' => __( 'Use custom settings', 'apollo13-framework' ),
				'off'    => __( 'Turn it off', 'apollo13-framework' ),
			),
		),
		array(
			'name'        => __( 'Position', 'apollo13-framework' ),
			'id'          => 'title_bar_position',
			'default'     => 'outside',
			'type'        => 'radio',
			'options'     => array(
				'outside' => __( 'Before content', 'apollo13-framework' ),
				'inside'  => __( 'Inside content', 'apollo13-framework' ),
			),
			'description' => __( 'To set background image for "Before content" option, use <strong>featured image</strong>.', 'apollo13-framework' ),
			'required'    => array( 'title_bar_settings', '=', 'custom' ),
		),
		array(
			'name'        => __( 'Variant', 'apollo13-framework' ),
			'description' => '',
			'id'          => 'title_bar_variant',
			'default'     => 'classic',
			'options'     => array(
				'classic'  => __( 'Classic(to side)', 'apollo13-framework' ),
				'centered' => __( 'Centered', 'apollo13-framework' ),
			),
			'type'        => 'radio',
			'required'    => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
			)
		),
		array(
			'name'        => __( 'Width', 'apollo13-framework' ),
			'description' => '',
			'id'          => 'title_bar_width',
			'default'     => 'full',
			'options'     => array(
				'full'  => __( 'Full', 'apollo13-framework' ),
				'boxed' => __( 'Boxed', 'apollo13-framework' ),
			),
			'type'        => 'radio',
			'required'    => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
			)
		),
		array(
			'name'     => __( 'How to fit background image', 'apollo13-framework' ),
			'id'       => 'title_bar_image_fit',
			'default'  => 'repeat',
			'options'  => array(
				'cover'    => __( 'Cover', 'apollo13-framework' ),
				'contain'  => __( 'Contain', 'apollo13-framework' ),
				'fitV'     => __( 'Fit Vertically', 'apollo13-framework' ),
				'fitH'     => __( 'Fit Horizontally', 'apollo13-framework' ),
				'center'   => __( 'Just center', 'apollo13-framework' ),
				'repeat'   => __( 'Repeat', 'apollo13-framework' ),
				'repeat-x' => __( 'Repeat X', 'apollo13-framework' ),
				'repeat-y' => __( 'Repeat Y', 'apollo13-framework' ),
			),
			'type'     => 'select',
			'required' => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
			)
		),
		array(
			'name'        => __( 'Enable parallax?', 'apollo13-framework' ),
			'description' => '',
			'id'          => 'title_bar_parallax',
			'default'     => 'off',
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'type'        => 'radio',
			'required'    => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
			)
		),
		array(
			'name'        => __( 'Parallax type', 'apollo13-framework' ),
			'description' => __( 'It defines how image will scroll in background while page is scrolled down.', 'apollo13-framework' ),
			'id'          => 'title_bar_parallax_type',
			'default'     => 'tb',
			'options'     => array(
				"tb"   => __( 'top to bottom', 'apollo13-framework' ),
				"bt"   => __( 'bottom to top', 'apollo13-framework' ),
				"lr"   => __( 'left to right', 'apollo13-framework' ),
				"rl"   => __( 'right to left', 'apollo13-framework' ),
				"tlbr" => __( 'top-left to bottom-right', 'apollo13-framework' ),
				"trbl" => __( 'top-right to bottom-left', 'apollo13-framework' ),
				"bltr" => __( 'bottom-left to top-right', 'apollo13-framework' ),
				"brtl" => __( 'bottom-right to top-left', 'apollo13-framework' ),
			),
			'type'        => 'select',
			'required'    => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
				array( 'title_bar_parallax', '=', 'on' ),
			)
		),
		array(
			'name'        => __( 'Parallax speed', 'apollo13-framework' ),
			'description' => __( 'It will be only used for background that are repeated. If background is set to not repeat this value will be ignored.', 'apollo13-framework' ),
			'id'          => 'title_bar_parallax_speed',
			'default'     => '1.00',
			'type'        => 'text',
			'required'    => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
				array( 'title_bar_parallax', '=', 'on' ),
			)
		),
		array(
			'name'        => __( 'Overlay color', 'apollo13-framework' ),
			'description' => __( 'It will be put above image(if used)', 'apollo13-framework' ),
			'id'          => 'title_bar_bg_color',
			'default'     => '',
			'type'        => 'color',
			'required'    => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
			)
		),
		array(
			'name'     => __( 'Titles color', 'apollo13-framework' ),
			'id'       => 'title_bar_title_color',
			'default'  => '',
			'type'     => 'color',
			'required' => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
			)
		),
		array(
			'name'        => __( 'Second elements color', 'apollo13-framework' ),
			'description' => __( 'Used in breadcrumbs.', 'apollo13-framework' ),
			'id'          => 'title_bar_color_1',
			'default'     => '',
			'type'        => 'color',
			'required'    => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
			)
		),
		array(
			'name'        => __( 'Space in top and bottom', 'apollo13-framework' ),
			'description' => '',
			'id'          => 'title_bar_space_width',
			'default'     => '40px',
			'unit'        => 'px',
			'min'         => 0,
			'max'         => 600,
			'type'        => 'slider',
			'required'    => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
			)
		),
		array(
			'name'        => __( 'Breadcrumbs', 'apollo13-framework' ),
			'description' => '',
			'id'          => 'breadcrumbs',
			'default'     => 'on',
			'type'        => 'radio',
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'required'    => array( 'title_bar_settings', '=', 'custom' ),
		),

		/*
		 *
		 * Tab: Page background
		 *
		 */
		array(
			'name' => __('Page background', 'apollo13-framework'),
			'type' => 'fieldset',
			'tab'   => true,
			'icon'  => 'fa fa-picture-o'
		),
		array(
			'name'        => __( 'Page background', 'apollo13-framework' ),
			'description' => __( 'You can use global settings or overwrite them here', 'apollo13-framework' ),
			'id'          => 'page_bg_settings',
			'default'     => 'global',
			'type'        => 'radio',
			'options'     => array(
				'global' => __( 'Global settings', 'apollo13-framework' ),
				'custom' => __( 'Use custom settings', 'apollo13-framework' ),
			),
		),
		array(
			'name'        => __( 'Page Background image file', 'apollo13-framework' ),
			'id'          => 'page_image',
			'default'     => '',
			'button_text' => __( 'Upload Image', 'apollo13-framework' ),
			'type'        => 'upload',
			'required'    => array( 'page_bg_settings', '=', 'custom' ),
		),
		array(
			'name'     => __( 'How to fit background image', 'apollo13-framework' ),
			'id'       => 'page_image_fit',
			'default'  => 'cover',
			'options'  => array(
				'cover'    => __( 'Cover', 'apollo13-framework' ),
				'contain'  => __( 'Contain', 'apollo13-framework' ),
				'fitV'     => __( 'Fit Vertically', 'apollo13-framework' ),
				'fitH'     => __( 'Fit Horizontally', 'apollo13-framework' ),
				'center'   => __( 'Just center', 'apollo13-framework' ),
				'repeat'   => __( 'Repeat', 'apollo13-framework' ),
				'repeat-x' => __( 'Repeat X', 'apollo13-framework' ),
				'repeat-y' => __( 'Repeat Y', 'apollo13-framework' ),
			),
			'type'     => 'select',
			'required' => array( 'page_bg_settings', '=', 'custom' ),
		),
		array(
			'name'     => __( 'Page Background color', 'apollo13-framework' ),
			'id'       => 'page_bg_color',
			'default'  => '',
			'type'     => 'color',
			'required' => array( 'page_bg_settings', '=', 'custom' ),
		),
	);

	return $meta;
}



function apollo13framework_meta_boxes_page() {
	global $apollo13framework_a13;
	$sidebars        = array(
		'default' => __( 'Default for pages', 'apollo13-framework' ),
	);
	$header_sidebars = array(
		'G'   => __( 'Global settings', 'apollo13-framework' ),
		'off' => __( 'Off', 'apollo13-framework' ),
	);

	$custom_sidebars = unserialize( $apollo13framework_a13->get_option( 'custom_sidebars' ) );
	$custom_sidebars = is_array($custom_sidebars)? $custom_sidebars : array($custom_sidebars);
	$sidebars_count  = count( $custom_sidebars );
	if ( is_array( $custom_sidebars ) && $sidebars_count > 0 ) {
		foreach ( $custom_sidebars as $sidebar ) {
			$sidebars[ $sidebar['id'] ]        = $sidebar['name'];
			$header_sidebars[ $sidebar['id'] ] = $sidebar['name'];
		}
	}

	$meta = array(
		/*
		 *
		 * Tab: Layout &amp; Sidebar
		 *
		 */
		array(
			'name' => __('Layout &amp; Sidebar', 'apollo13-framework'),
			'type' => 'fieldset',
			'tab'   => true,
			'icon'  => 'fa fa-wrench'
		),
		array(
			'name'          => __( 'Content Layout', 'apollo13-framework' ),
			'id'            => 'content_layout',
			'default'       => 'global',
			'global_value'  => 'global',
			'parent_option' => 'page_content_layout',
			'type'          => 'select',
			'options'       => array(
				'global'        => __( 'Global settings', 'apollo13-framework' ),
				'center'        => __( 'Center fixed width', 'apollo13-framework' ),
				'left'          => __( 'Left fixed width', 'apollo13-framework' ),
				'left_padding'  => __( 'Left fixed width + padding', 'apollo13-framework' ),
				'right'         => __( 'Right fixed width', 'apollo13-framework' ),
				'right_padding' => __( 'Right fixed width + padding', 'apollo13-framework' ),
				'full_fixed'    => __( 'Full width + fixed content', 'apollo13-framework' ),
				'full_padding'  => __( 'Full width + padding', 'apollo13-framework' ),
				'full'          => __( 'Full width', 'apollo13-framework' ),
			),
		),
		array(
			'name'        => __( 'Content top/bottom padding', 'apollo13-framework' ),
			'description' => __( 'Enable or disable top and bottom padding of content. It is helpful in achieving some neat layout effects:-).', 'apollo13-framework' ),
			'id'          => 'content_padding',
			'default'     => 'both',
			'type'        => 'select',
			'options'     => array(
				'both'   => __( 'Both on', 'apollo13-framework' ),
				'top'    => __( 'Only top', 'apollo13-framework' ),
				'bottom' => __( 'Only bottom', 'apollo13-framework' ),
				'off'    => __( 'Both off', 'apollo13-framework' ),
			),
		),
		array(
			'name'        => __( 'Content side padding', 'apollo13-framework' ),
			'description' => __( 'It is helpful in achieving some neat layout effects:-).', 'apollo13-framework' ),
			'id'          => 'content_side_padding',
			'default'     => 'both',
			'type'        => 'radio',
			'options'     => array(
				'both'   => __( 'Both on', 'apollo13-framework' ),
				'off'    => __( 'Both off', 'apollo13-framework' ),
			),
		),
		array(
			'name'          => __( 'Sidebar', 'apollo13-framework' ),
			'description'   => __( 'If turned off, content will take full width.', 'apollo13-framework' ),
			'id'            => 'widget_area',
			'global_value'  => 'G',
			'default'       => 'G',
			'parent_option' => 'page_sidebar',
			'options'       => array(
				'G'                     => __( 'Global settings', 'apollo13-framework' ),
				'left-sidebar'          => __( 'Sidebar on the left', 'apollo13-framework' ),
				'left-sidebar_and_nav'  => __( 'Children Navigation + sidebar on the left', 'apollo13-framework' ),
				'left-nav'              => __( 'Only children Navigation on the left', 'apollo13-framework' ),
				'right-sidebar'         => __( 'Sidebar on the right', 'apollo13-framework' ),
				'right-sidebar_and_nav' => __( 'Children Navigation + sidebar on the right', 'apollo13-framework' ),
				'right-nav'             => __( 'Only children Navigation on the right', 'apollo13-framework' ),
				'off'                   => __( 'Off', 'apollo13-framework' ),
			),
			'type'          => 'select',
		),
		array(
			'name'     => __( 'Sidebar to show', 'apollo13-framework' ),
			'id'       => 'sidebar_to_show',
			'default'  => 'default',
			'options'  => $sidebars,
			'type'     => 'select',
			'required' => array( 'widget_area', '!=', 'off' ),
		),

		/*
		 *
		 * Tab: Header
		 *
		 */
		array(
			'name' => __('Header', 'apollo13-framework'),
			'type' => 'fieldset',
			'tab'   => true,
			'icon'  => 'fa fa-cogs'
		),
		array(
			'name'          => __( 'Hide content under header', 'apollo13-framework' ),
			'description'   => __( 'Only valid when using horizontal header.', 'apollo13-framework' ),
			'id'            => 'content_under_header',
			'global_value'  => 'G',
			'default'       => 'G',
			'parent_option' => 'page_content_under_header',
			'type'          => 'select',
			'options'       => array(
				'G'       => __( 'Global settings', 'apollo13-framework' ),
				'content' => __( 'Yes hide content', 'apollo13-framework' ),
				'title'   => __( 'Yes hide content and add top padding to outside title bar.', 'apollo13-framework' ),
				'off'     => __( 'Turn it off', 'apollo13-framework' ),
			),
		),
		array(
			'name'          => __( 'Header color variant', 'apollo13-framework' ),
			'description'   => __( 'Only valid when using horizontal header.', 'apollo13-framework' ),
			'id'            => 'horizontal_header_color_variant',
			'global_value'  => 'G',
			'default'       => 'G',
			'parent_option' => 'page_horizontal_header_color_variant',
			'paid'          => 1,
			'type'          => 'select',
			'options'       => array(
				'G'      => __( 'Global settings', 'apollo13-framework' ),
				'normal' => __( 'Normal', 'apollo13-framework' ),
				'light'  => __( 'Light', 'apollo13-framework' ),
				'dark'   => __( 'Dark', 'apollo13-framework' ),
			),
		),
		array(
			'name'          => __( 'Show header from Nth row', 'apollo13-framework' ),
			'description'   => __( 'Only valid when using horizontal header. <br />If you use Elementor or WPBakery Page Builder, then you can decide to show header after content is scrolled to Nth row. Thanks to that you can have clean welcome screen.', 'apollo13-framework' ),
			'id'            => 'horizontal_header_show_header_at',
			'default'       => '0',
			'type'          => 'select',
			'options'       => array(
				'0' => __( 'Show always', 'apollo13-framework' ),
				'1' => __( 'from 1st row', 'apollo13-framework' ),
				'2' => __( 'from 2nd row', 'apollo13-framework' ),
				'3' => __( 'from 3rd row', 'apollo13-framework' ),
				'4' => __( 'from 4th row', 'apollo13-framework' ),
				'5' => __( 'from 5th row', 'apollo13-framework' ),
			),
		),
		array(
			'name'          => __( 'Header custom sidebar', 'apollo13-framework' ),
			'description'   => __( 'Works only with vertical header. Special widgets that should be shown on this page in header.', 'apollo13-framework' ),
			'id'            => 'header_custom_sidebar',
			'global_value'  => 'G',
			'default'       => 'G',
			'parent_option' => 'header_custom_sidebar',
			'options'       => $header_sidebars,
			'paid'          => 1,
			'type'          => 'select',
		),

		/*
		 *
		 * Tab: Title bar
		 *
		 */
		array(
			'name' => __('Title bar', 'apollo13-framework'),
			'type' => 'fieldset',
			'tab'   => true,
			'icon'  => 'fa fa-text-width'
		),
		array(
			'name'    => __( 'Subtitle', 'apollo13-framework' ),
			'id'      => 'subtitle',
			'default' => '',
			'type'    => 'text'
		),
		array(
			'name'        => __( 'Title bar look', 'apollo13-framework' ),
			'description' => __( 'You can use global settings or overwrite them here', 'apollo13-framework' ),
			'id'          => 'title_bar_settings',
			'default'     => 'global',
			'type'        => 'radio',
			'options'     => array(
				'global' => __( 'Global settings', 'apollo13-framework' ),
				'custom' => __( 'Use custom settings', 'apollo13-framework' ),
				'off'    => __( 'Turn it off', 'apollo13-framework' ),
			),
		),
		array(
			'name'        => __( 'Position', 'apollo13-framework' ),
			'id'          => 'title_bar_position',
			'default'     => 'outside',
			'type'        => 'radio',
			'options'     => array(
				'outside' => __( 'Before content', 'apollo13-framework' ),
				'inside'  => __( 'Inside content', 'apollo13-framework' ),
			),
			'description' => __( 'To set background image for "Before content" option, use <strong>featured image</strong>.', 'apollo13-framework' ),
			'required'    => array( 'title_bar_settings', '=', 'custom' ),
		),
		array(
			'name'        => __( 'Variant', 'apollo13-framework' ),
			'description' => '',
			'id'          => 'title_bar_variant',
			'default'     => 'classic',
			'options'     => array(
				'classic'  => __( 'Classic(to side)', 'apollo13-framework' ),
				'centered' => __( 'Centered', 'apollo13-framework' ),
			),
			'type'        => 'radio',
			'required'    => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
			)
		),
		array(
			'name'        => __( 'Width', 'apollo13-framework' ),
			'description' => '',
			'id'          => 'title_bar_width',
			'default'     => 'full',
			'options'     => array(
				'full'  => __( 'Full', 'apollo13-framework' ),
				'boxed' => __( 'Boxed', 'apollo13-framework' ),
			),
			'type'        => 'radio',
			'required'    => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
			)
		),
		array(
			'name'     => __( 'How to fit background image', 'apollo13-framework' ),
			'id'       => 'title_bar_image_fit',
			'default'  => 'repeat',
			'options'  => array(
				'cover'    => __( 'Cover', 'apollo13-framework' ),
				'contain'  => __( 'Contain', 'apollo13-framework' ),
				'fitV'     => __( 'Fit Vertically', 'apollo13-framework' ),
				'fitH'     => __( 'Fit Horizontally', 'apollo13-framework' ),
				'center'   => __( 'Just center', 'apollo13-framework' ),
				'repeat'   => __( 'Repeat', 'apollo13-framework' ),
				'repeat-x' => __( 'Repeat X', 'apollo13-framework' ),
				'repeat-y' => __( 'Repeat Y', 'apollo13-framework' ),
			),
			'type'     => 'select',
			'required' => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
			)
		),
		array(
			'name'        => __( 'Enable parallax?', 'apollo13-framework' ),
			'description' => '',
			'id'          => 'title_bar_parallax',
			'default'     => 'off',
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'type'        => 'radio',
			'required'    => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
			)
		),
		array(
			'name'        => __( 'Parallax type', 'apollo13-framework' ),
			'description' => __( 'It defines how image will scroll in background while page is scrolled down.', 'apollo13-framework' ),
			'id'          => 'title_bar_parallax_type',
			'default'     => 'tb',
			'options'     => array(
				"tb"   => __( 'top to bottom', 'apollo13-framework' ),
				"bt"   => __( 'bottom to top', 'apollo13-framework' ),
				"lr"   => __( 'left to right', 'apollo13-framework' ),
				"rl"   => __( 'right to left', 'apollo13-framework' ),
				"tlbr" => __( 'top-left to bottom-right', 'apollo13-framework' ),
				"trbl" => __( 'top-right to bottom-left', 'apollo13-framework' ),
				"bltr" => __( 'bottom-left to top-right', 'apollo13-framework' ),
				"brtl" => __( 'bottom-right to top-left', 'apollo13-framework' ),
			),
			'type'        => 'select',
			'required'    => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
				array( 'title_bar_parallax', '=', 'on' ),
			)
		),
		array(
			'name'        => __( 'Parallax speed', 'apollo13-framework' ),
			'description' => __( 'It will be only used for background that are repeated. If background is set to not repeat this value will be ignored.', 'apollo13-framework' ),
			'id'          => 'title_bar_parallax_speed',
			'default'     => '1.00',
			'type'        => 'text',
			'required'    => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
				array( 'title_bar_parallax', '=', 'on' ),
			)
		),
		array(
			'name'        => __( 'Overlay color', 'apollo13-framework' ),
			'description' => __( 'It will be put above image(if used)', 'apollo13-framework' ),
			'id'          => 'title_bar_bg_color',
			'default'     => '',
			'type'        => 'color',
			'required'    => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
			)
		),
		array(
			'name'     => __( 'Titles color', 'apollo13-framework' ),
			'id'       => 'title_bar_title_color',
			'default'  => '',
			'type'     => 'color',
			'required' => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
			)
		),
		array(
			'name'        => __( 'Second elements color', 'apollo13-framework' ),
			'description' => __( 'Used in breadcrumbs.', 'apollo13-framework' ),
			'id'          => 'title_bar_color_1',
			'default'     => '',
			'type'        => 'color',
			'required'    => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
			)
		),
		array(
			'name'        => __( 'Space in top and bottom', 'apollo13-framework' ),
			'description' => '',
			'id'          => 'title_bar_space_width',
			'default'     => '40px',
			'unit'        => 'px',
			'min'         => 0,
			'max'         => 600,
			'type'        => 'slider',
			'required'    => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
			)
		),
		array(
			'name'        => __( 'Breadcrumbs', 'apollo13-framework' ),
			'description' => '',
			'id'          => 'breadcrumbs',
			'default'     => 'on',
			'type'        => 'radio',
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'required'    => array( 'title_bar_settings', '=', 'custom' ),
		),

		/*
		 *
		 * Tab: Featured media
		 *
		 */
		array(
			'name' => __('Featured media', 'apollo13-framework'),
			'type' => 'fieldset',
			'tab'   => true,
			'icon'  => 'fa fa-star'
		),
		array(
			'name'        => __( 'Post media', 'apollo13-framework' ),
			'description' => __( 'Choose between Image, Video and Sliders. For image use Featured Image Option. For <strong>Images slider</strong> you need plugin <a href="https://wordpress.org/plugins/featured-galleries/" target="_blank">Featured galleries</a>.', 'apollo13-framework' ),
			'id'          => 'image_or_video',
			'default'     => 'post_image',
			'options'     => array(
				'post_image'  => __( 'Image', 'apollo13-framework' ),
				'post_slider' => __( 'Images slider', 'apollo13-framework' ),
				'post_video'  => __( 'Video', 'apollo13-framework' ),
			),
			'type'        => 'radio',
		),
		array(
			'name'        => __( 'Featured image parallax', 'apollo13-framework' ),
			'description' => __( 'It will limit image height, so parallax could take effect.', 'apollo13-framework' ),
			'id'          => 'image_parallax',
			'default'     => 'off',
			'type'        => 'radio',
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'required'    => array( 'image_or_video', '=', 'post_image' ),
		),
		array(
			'name'     => __( 'Parallax area height', 'apollo13-framework' ),
			'id'       => 'image_parallax_height',
			'default'  => '260',
			'unit'     => 'px',
			'min'      => 100,
			'max'      => 600,
			'type'     => 'slider',
			'required' => array(
				array( 'image_or_video', '=', 'post_image' ),
				array( 'image_parallax', '=', 'on' ),
			)
		),
		array(
			'name'              => __( 'Link to video', 'apollo13-framework' ),
			'description'       => __( 'Insert here link to your video file or upload it. You can also add video from youtube or vimeo by pasting here link to movie.', 'apollo13-framework' ),
			'id'                => 'post_video',
			'default'           => '',
			'type'              => 'upload',
			'button_text'       => __( 'Upload media file', 'apollo13-framework' ),
			'media_button_text' => __( 'Insert media file', 'apollo13-framework' ),
			'media_type'        => 'video', /* 'audio,video' */
			'required'          => array( 'image_or_video', '=', 'post_video' ),
		),

		/*
		 *
		 * Tab: Page background
		 *
		 */
		array(
			'name' => __('Page background', 'apollo13-framework'),
			'type' => 'fieldset',
			'tab'   => true,
			'icon'  => 'fa fa-picture-o'
		),
		array(
			'name'        => __( 'Page background', 'apollo13-framework' ),
			'description' => __( 'You can use global settings or overwrite them here', 'apollo13-framework' ),
			'id'          => 'page_bg_settings',
			'default'     => 'global',
			'type'        => 'radio',
			'options'     => array(
				'global' => __( 'Global settings', 'apollo13-framework' ),
				'custom' => __( 'Use custom settings', 'apollo13-framework' ),
			),
		),
		array(
			'name'        => __( 'Page Background image file', 'apollo13-framework' ),
			'id'          => 'page_image',
			'default'     => '',
			'button_text' => __( 'Upload Image', 'apollo13-framework' ),
			'type'        => 'upload',
			'required'    => array( 'page_bg_settings', '=', 'custom' ),
		),
		array(
			'name'     => __( 'How to fit background image', 'apollo13-framework' ),
			'id'       => 'page_image_fit',
			'default'  => 'cover',
			'options'  => array(
				'cover'    => __( 'Cover', 'apollo13-framework' ),
				'contain'  => __( 'Contain', 'apollo13-framework' ),
				'fitV'     => __( 'Fit Vertically', 'apollo13-framework' ),
				'fitH'     => __( 'Fit Horizontally', 'apollo13-framework' ),
				'center'   => __( 'Just center', 'apollo13-framework' ),
				'repeat'   => __( 'Repeat', 'apollo13-framework' ),
				'repeat-x' => __( 'Repeat X', 'apollo13-framework' ),
				'repeat-y' => __( 'Repeat Y', 'apollo13-framework' ),
			),
			'type'     => 'select',
			'required' => array( 'page_bg_settings', '=', 'custom' ),
		),
		array(
			'name'     => __( 'Page Background color', 'apollo13-framework' ),
			'id'       => 'page_bg_color',
			'default'  => '',
			'type'     => 'color',
			'required' => array( 'page_bg_settings', '=', 'custom' ),
		),

		/*
		 *
		 * Tab: Sticky one page mode
		 *
		 */
		array(
			'name' => __('Sticky one page mode', 'apollo13-framework'),
			'type' => 'fieldset',
			'tab'   => true,
			'icon'  => 'fa fa-anchor'
		),
		array(
			'name'        => __( 'Sticky One Page mode', 'apollo13-framework' ),
			'description' => __( 'This works only when page is designed with WPBakery Page Builder. By enabling this the page will turn into vertical full-page slider and each row of content created by WPBakery Page Builder is a single slide.', 'apollo13-framework' ),
			'id'          => 'content_sticky_one_page',
			'default'     => 'off',
			'type'        => 'radio',
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
		),
		array(
			'name'     => __( 'Sticky One Page mode - color of navigation bullets', 'apollo13-framework' ),
			'id'       => 'content_sticky_one_page_bullet_color',
			'default'  => 'rgba(0,0,0,1)',
			'type'     => 'color',
			'required' => array(
				array( 'content_sticky_one_page', '=', 'on' )
			)
		),
		array(
			'name'        => __( 'Sticky One Page mode - default bullets icon', 'apollo13-framework' ),
			'description' => __( 'Select icon by clicking on input.', 'apollo13-framework' ),
			'id'          => 'content_sticky_one_page_bullet_icon',
			'default'     => '',
			'type'        => 'text',
			'input_class' => 'a13-fa-icon a13-full-class',
			'required'    => array(
				array( 'content_sticky_one_page', '=', 'on' )
			)
		),
	);

	return $meta;
}



function apollo13framework_meta_boxes_album() {
	global $apollo13framework_a13;

	$header_sidebars = array(
		'G'   => __( 'Global settings', 'apollo13-framework' ),
		'off' => __( 'Off', 'apollo13-framework' ),
	);

	$custom_sidebars = unserialize( $apollo13framework_a13->get_option( 'custom_sidebars' ) );
	$custom_sidebars = is_array($custom_sidebars)? $custom_sidebars : array($custom_sidebars);
	$sidebars_count  = count( $custom_sidebars );
	if ( is_array( $custom_sidebars ) && $sidebars_count > 0 ) {
		foreach ( $custom_sidebars as $sidebar ) {
			$header_sidebars[ $sidebar['id'] ] = $sidebar['name'];
		}
	}

	$meta = array(
		/*
		 *
		 * Tab: Albums list
		 *
		 */
		array(
			'name' => __('Albums list', 'apollo13-framework'),
			'type' => 'fieldset',
			'tab'   => true,
			'icon'  => 'fa fa-list'
		),
		array(
			'name'        => __( 'Alternative Link', 'apollo13-framework' ),
			'description' => __( 'If you fill this then clicking in your album on albums list will not lead to single album page but to link from this field.', 'apollo13-framework' ),
			'id'          => 'alt_link',
			'default'     => '',
			'type'        => 'text',
		),
		array(
			'name'    => __( 'Subtitle', 'apollo13-framework' ),
			'id'      => 'subtitle',
			'default' => '',
			'type'    => 'text'
		),
		array(
			'name'        => __( 'Size of brick', 'apollo13-framework' ),
			'description' => __( 'How many bricks area should take this album in albums list.', 'apollo13-framework' ),
			'id'          => 'brick_ratio_x',
			'default'     => 1,
			'unit'        => '',
			'min'         => 1,
			'max'         => 4,
			'type'        => 'slider'
		),
		array(
			'name'        => __( 'Cover color', 'apollo13-framework' ),
			'id'          => 'cover_color',
			'description' => __( 'Works only when titles are displayed over images in Albums list.', 'apollo13-framework' ),
			'default'     => 'rgba(0,0,0, 0.7)',
			'type'        => 'color'
		),
		array(
			'name'        => __( 'Exclude from Albums list page', 'apollo13-framework' ),
			'description' => __( 'If enabled, then this album wont be listed on Albums list page, but you can still select it for front page or in other places.', 'apollo13-framework' ),
			'id'          => 'exclude_in_albums_list',
			'default'     => 'off',
			'type'        => 'radio',
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
		),

		/*
		 *
		 * Tab: Album media
		 *
		 */
		array(
			'name' => __('Album media', 'apollo13-framework'),
			'type' => 'fieldset',
			'tab'   => true,
			'icon'  => 'fa fa-th',
			'notice' => $apollo13framework_a13->check_for_valid_license() ? '' :
				apply_filters('apollo13framework_valid_license_notice_in_meta', sprintf( __( 'You have to provide valid license for theme to enable <strong>scroller feature</strong>. You can do it <a href="%s">here</a>.', 'apollo13-framework' ), admin_url( 'themes.php?page=apollo13_info')))
		),
		array(
			'name'        => __( 'Items order', 'apollo13-framework' ),
			'description' => __( 'It will display your images/videos from first to last, or another way.', 'apollo13-framework' ),
			'id'          => 'order',
			'default'     => 'ASC',
			'options'     => array(
				'ASC'    => __( 'First on list, first displayed', 'apollo13-framework' ),
				'DESC'   => __( 'First on list, last displayed', 'apollo13-framework' ),
				'random' => __( 'Random', 'apollo13-framework' ),
			),
			'type'        => 'select',
		),
		array(
			'name'        => __( 'Show title and description of album items', 'apollo13-framework' ),
			'description' => __( 'If enabled, then it will affect displaying in bricks and slider option, and also in lightbox.', 'apollo13-framework' ),
			'id'          => 'enable_desc',
			'default'     => 'on',
			'type'        => 'radio',
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
		),
		array(
			'name'    => __( 'Present media in:', 'apollo13-framework' ),
			'description'   => ($apollo13framework_a13->check_for_valid_license() ? '' :
				apply_filters('apollo13framework_valid_license_description_in_meta', sprintf( __( 'You have to provide valid license for theme to enable <strong>scroller feature</strong>. You can do it <a href="%s">here</a>.', 'apollo13-framework' ), admin_url( 'themes.php?page=apollo13_info')).'<br />' )).
				__( 'Scrollers work only with images! Slider and Bricks work with images and videos.', 'apollo13-framework' ),
			'id'      => 'theme',
			'default' => 'bricks',
			'options' => array(
				'bricks' => __( 'Bricks', 'apollo13-framework' ),
				'slider' => __( 'Slider', 'apollo13-framework' ),
				'scroller' => __( 'Scroller', 'apollo13-framework' ),
				'scroller-parallax' => __( 'Scroller parallax', 'apollo13-framework' ),
			),
			'paid_options' => array(
				'scroller',
				'scroller-parallax'
			),
			'type'    => 'radio',
		),
		array(
			'name'          => __( 'Content column', 'apollo13-framework' ),
			'description'   => __( 'This will display separate block with title and text about album.', 'apollo13-framework' ),
			'id'            => 'album_content',
			'default'       => 'G',
			'global_value'  => 'G',
			'parent_option' => 'album_content',
			'options'       => array(
				'G'     => __( 'Global settings', 'apollo13-framework' ),
				'left'  => __( 'Show on left', 'apollo13-framework' ),
				'right' => __( 'Show on right', 'apollo13-framework' ),
				'off'   => __( 'Do not display it', 'apollo13-framework' ),
			),
			'type'          => 'select',
			'required'      => array( 'theme', '=', 'bricks' ),
		),
		array(
			'name'        => __( 'Bricks columns', 'apollo13-framework' ),
			'id'          => 'brick_columns',
			'default'     => '3',
			'unit'        => '',
			'min'         => 1,
			'max'         => 6,
			'type'        => 'slider',
			'required'    => array( 'theme', '=', 'bricks' ),
		),
		array(
			'name'        => __( 'Max width of bricks content.', 'apollo13-framework' ),
			'description' => __( 'Depending on actual screen width, available space for bricks might be smaller, but newer greater then this number.', 'apollo13-framework' ),
			'id'          => 'bricks_max_width',
			'default'     => '1920px',
			'unit'        => 'px',
			'min'         => 200,
			'max'         => 2500,
			'type'        => 'slider',
			'required'    => array( 'theme', '=', 'bricks' ),
		),
		array(
			'name'     => __( 'Brick margin', 'apollo13-framework' ),
			'id'       => 'brick_margin',
			'default'  => '10px',
			'unit'     => 'px',
			'min'      => 0,
			'max'      => 100,
			'type'     => 'slider',
			'required' => array( 'theme', '=', 'bricks' ),
		),
		array(
			'name'     => __( 'Choose brick proportion', 'apollo13-framework' ),
			'description' => __( 'Works only for images. If you switch theme option "Display thumbs instead of video", then for videos that you will upload image it will also work.', 'apollo13-framework' ),
			'id'       => 'bricks_proportions_size',
			'default'  => '0',
			'options' => array(
				'0'    => __( 'Original size', 'apollo13-framework' ),
				'1/1'  => __( '1:1', 'apollo13-framework' ),
				'2/3'  => __( '2:3', 'apollo13-framework' ),
				'3/2'  => __( '3:2', 'apollo13-framework' ),
				'3/4'  => __( '3:4', 'apollo13-framework' ),
				'4/3'  => __( '4:3', 'apollo13-framework' ),
				'9/16' => __( '9:16', 'apollo13-framework' ),
				'16/9' => __( '16:9', 'apollo13-framework' ),
			),
			'type'     => 'select',
			'required' => array( 'theme', '=', 'bricks' ),
		),
		array(
			'id'       => 'bricks_lightbox',
			'type'     => 'radio',
			'name'     => __( 'Open bricks to lightbox', 'apollo13-framework' ),
			'options'  => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'default'  => 'on',
			'required' => array( 'theme', '=', 'bricks' ),
		),
		array(
			'name'        => __( 'Color of cover', 'apollo13-framework' ),
			'description' => __( 'Leave empty to not set any background', 'apollo13-framework' ),
			'id'          => 'slide_cover_color',
			'default'     => 'rgba(0,0,0, 0.7)',
			'type'        => 'color',
			'required'    => array( 'theme', '=', 'bricks' ),
		),
		array(
			'name'     => __( 'Hover effect', 'apollo13-framework' ),
			'id'       => 'bricks_hover',
			'default'  => 'cross',
			'options'  => array(
				'cross'  => __( 'Show cross', 'apollo13-framework' ),
				'drop'   => __( 'Drop', 'apollo13-framework' ),
				'shift'  => __( 'Shift', 'apollo13-framework' ),
				'pop'    => __( 'Pop', 'apollo13-framework' ),
				'border' => __( 'Border', 'apollo13-framework' ),
				'none'   => __( 'None', 'apollo13-framework' ),
			),
			'type'     => 'select',
			'required' => array( 'theme', '=', 'bricks' ),
		),
		array(
			'id'       => 'bricks_title_position',
			'type'     => 'select',
			'name'     => __( 'Texts position', 'apollo13-framework' ),
			'options'  => array(
				'top_left'      => __( 'Top left', 'apollo13-framework' ),
				'top_center'    => __( 'Top center', 'apollo13-framework' ),
				'top_right'     => __( 'Top right', 'apollo13-framework' ),
				'mid_left'      => __( 'Middle left', 'apollo13-framework' ),
				'mid_center'    => __( 'Middle center', 'apollo13-framework' ),
				'mid_right'     => __( 'Middle right', 'apollo13-framework' ),
				'bottom_left'   => __( 'Bottom left', 'apollo13-framework' ),
				'bottom_center' => __( 'Bottom center', 'apollo13-framework' ),
				'bottom_right'  => __( 'Bottom right', 'apollo13-framework' ),
			),
			'default'  => 'top_left',
			'required' => array( 'theme', '=', 'bricks' ),
		),
		array(
			'id'       => 'bricks_overlay_cover',
			'type'     => 'radio',
			'name'     => __( 'Show cover when not hovering', 'apollo13-framework' ),
			'options'  => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'default'  => 'on',
			'required' => array( 'theme', '=', 'bricks' ),
		),
		array(
			'id'       => 'bricks_overlay_cover_hover',
			'type'     => 'radio',
			'name'     => __( 'Show cover when hovering', 'apollo13-framework' ),
			'options'  => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'default'  => 'off',
			'required' => array( 'theme', '=', 'bricks' ),
		),
		array(
			'id'          => 'bricks_overlay_gradient',
			'type'        => 'radio',
			'name'        => __( 'Show gradient when not hovering', 'apollo13-framework' ),
			'description' => __( 'Its main function is to make texts more visible', 'apollo13-framework' ),
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'default'     => 'on',
			'required'    => array( 'theme', '=', 'bricks' ),
		),
		array(
			'id'          => 'bricks_overlay_gradient_hover',
			'type'        => 'radio',
			'name'        => __( 'Show gradient when hovering', 'apollo13-framework' ),
			'description' => __( 'Its main function is to make texts more visible', 'apollo13-framework' ),
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'default'     => 'off',
			'required'    => array( 'theme', '=', 'bricks' ),
		),
		array(
			'id'       => 'bricks_overlay_texts',
			'type'     => 'radio',
			'name'     => __( 'Show texts when not hovering', 'apollo13-framework' ),
			'options'  => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'default'  => 'on',
			'required' => array(
				array( 'theme', '=', 'bricks' ),
				array( 'enable_desc', '=', 'on' )
			),
		),
		array(
			'id'       => 'bricks_overlay_texts_hover',
			'type'     => 'radio',
			'name'     => __( 'Show texts when hovering', 'apollo13-framework' ),
			'options'  => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'default'  => 'on',
			'required' => array(
				array( 'theme', '=', 'bricks' ),
				array( 'enable_desc', '=', 'on' )
			),
		),
		array(
			'name'        => __( 'Fit images', 'apollo13-framework' ),
			'description' => __( 'How will images fit area. <strong>Fit when needed</strong> is best for small images, that should not be stretched to bigger sizes, only to smaller(to keep them visible).', 'apollo13-framework' ),
			'id'          => 'fit_variant',
			'default'     => '0',
			'options'     => array(
				'0' => __( 'Fit always', 'apollo13-framework' ),
				'1' => __( 'Fit landscape', 'apollo13-framework' ),
				'2' => __( 'Fit portrait', 'apollo13-framework' ),
				'3' => __( 'Fit when needed', 'apollo13-framework' ),
				'4' => __( 'Cover whole screen', 'apollo13-framework' ),
			),
			'type'        => 'select',
			'required'    => array( 'theme', '=', 'slider' ),
		),
		array(
			'name'          => __( 'Autoplay', 'apollo13-framework' ),
			'description'   => __( 'If autoplay is on, slider items will start sliding on page load', 'apollo13-framework' ),
			'id'            => 'autoplay',
			'default'       => 'G',
			'global_value'  => 'G',
			'parent_option' => 'album_slider_autoplay',
			'options'       => array(
				'G'   => __( 'Global settings', 'apollo13-framework' ),
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'type'          => 'select',
			'required'      => array( 'theme', '=', 'slider' ),
		),
		array(
			'name'          => __( 'Transition type', 'apollo13-framework' ),
			'description'   => __( 'Animation between slides.', 'apollo13-framework' ),
			'id'            => 'transition',
			'default'       => '-1',
			'global_value'  => '-1',
			'parent_option' => 'album_slider_transition_type',
			'options'       => array(
				'-1' => __( 'Global settings', 'apollo13-framework' ),
				'0'  => __( 'None', 'apollo13-framework' ),
				'1'  => __( 'Fade', 'apollo13-framework' ),
				'2'  => __( 'Carousel', 'apollo13-framework' ),
				'3'  => __( 'Zooming', 'apollo13-framework' ),
			),
			'type'          => 'select',
			'required'      => array( 'theme', '=', 'slider' ),
		),
		array(
			'name'        => __( 'Scale in %', 'apollo13-framework' ),
			'description' => __( 'How big zooming effect will be', 'apollo13-framework' ),
			'id'          => 'ken_scale',
			'default'     => 120,
			'unit'        => '%',
			'min'         => 100,
			'max'         => 200,
			'type'        => 'slider',
			'required'    => array(
				array( 'theme', '=', 'slider' ),
				array( 'transition', '=', '3' ),
			)
		),
		array(
			'name'        => __( 'Gradient above photos', 'apollo13-framework' ),
			'description' => __( 'Good for better readability of slide titles.', 'apollo13-framework' ),
			'id'          => 'gradient',
			'default'     => 'on',
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'type'        => 'radio',
			'required'    => array( 'theme', '=', 'slider' ),
		),
		array(
			'name'        => __( 'Color under title', 'apollo13-framework' ),
			'description' => __( 'Leave empty to not set any background', 'apollo13-framework' ),
			'id'          => 'slide_title_bg_color',
			'default'     => '',
			'type'        => 'color',
			'required'    => array(
				array( 'enable_desc', '=', 'on' ),
				array( 'theme', '=', 'slider' )
			)
		),
		array(
			'name'     => __( 'Pattern above photos', 'apollo13-framework' ),
			'id'       => 'pattern',
			'default'  => '0',
			'options'  => array(
				'0' => __( 'None', 'apollo13-framework' ),
				'1' => __( 'Type 1', 'apollo13-framework' ),
				'2' => __( 'Type 2', 'apollo13-framework' ),
				'3' => __( 'Type 3', 'apollo13-framework' ),
				'4' => __( 'Type 4', 'apollo13-framework' ),
				'5' => __( 'Type 5', 'apollo13-framework' ),
			),
			'type'     => 'select',
			'required' => array( 'theme', '=', 'slider' ),
		),
		array(
			'name'          => __( 'List of Thumbs', 'apollo13-framework' ),
			'id'            => 'thumbs',
			'default'       => 'G',
			'global_value'  => 'G',
			'parent_option' => 'album_slider_thumbs',
			'options'       => array(
				'G'   => __( 'Global settings', 'apollo13-framework' ),
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'type'          => 'select',
			'required'      => array( 'theme', '=', 'slider' ),
		),
		array(
			'name'        => __( 'Display thumbs opened', 'apollo13-framework' ),
			'description' => __( 'If thumbs are enabled, should they be open by default?', 'apollo13-framework' ),
			'id'          => 'thumbs_on_load',
			'default'     => 'off',
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'type'        => 'radio',
			'required'    => array( 'theme', '=', 'slider' ),
		),


		//scroller
		array(
			'name'     => __( 'Cell width', 'apollo13-framework' ),
			'id'       => 'scroller_cell_width',
			'default'  => '33',
			'options'  => array(
				'20' => __( '20%', 'apollo13-framework' ),
				'25' => __( '25%', 'apollo13-framework' ),
				'33' => __( '33%', 'apollo13-framework' ),
				'50' => __( '50%', 'apollo13-framework' ),
				'66' => __( '66%', 'apollo13-framework' ),
				'75' => __( '75%', 'apollo13-framework' ),
				'90' => __( '90%', 'apollo13-framework' ),
			),
			'type'     => 'select',
			'paid' => 1,
			'required'    => array(
				array( 'theme', '!=', 'slider' ),
				array( 'theme', '!=', 'bricks' ),
			)
		),
		array(
			'name'     => __( 'Cell width on mobile', 'apollo13-framework' ),
			'description' => __( 'Will switch on devices with width less then 600px.', 'apollo13-framework' ),
			'id'       => 'scroller_cell_width_mobile',
			'default'  => '75',
			'options'  => array(
				'20' => __( '20%', 'apollo13-framework' ),
				'25' => __( '25%', 'apollo13-framework' ),
				'33' => __( '33%', 'apollo13-framework' ),
				'50' => __( '50%', 'apollo13-framework' ),
				'66' => __( '66%', 'apollo13-framework' ),
				'75' => __( '75%', 'apollo13-framework' ),
				'90' => __( '90%', 'apollo13-framework' ),
			),
			'type'     => 'select',
			'paid' => 1,
			'required'    => array(
				array( 'theme', '!=', 'slider' ),
				array( 'theme', '!=', 'bricks' ),
			)
		),
		array(
			'name'        => __( 'Effect on not active elements', 'apollo13-framework' ),
			'description' => __( 'Please use with caution! CSS transitions on filters(effects) can choke any browser. Use only on small albums(<10 images). Effects are switched off for devices with resolution lower then 1024px, as they usually don\'t have enough power to animate them.', 'apollo13-framework' ),
			'id'          => 'scroller_effect',
			'default'     => 'off',
			'options'     => array(
				'off'        => __( 'Disabled', 'apollo13-framework' ),
				'opacity'    => __( 'Opacity', 'apollo13-framework' ),
				'scale-down' => __( 'Scale down', 'apollo13-framework' ),
				'grayscale'  => __( 'Grayscale', 'apollo13-framework' ),
				'blur'       => __( 'Blur', 'apollo13-framework' ),
			),
			'type'        => 'select',
			'paid' => 1,
			'required'    => array(
				array( 'theme', '!=', 'slider' ),
				array( 'theme', '!=', 'bricks' ),
			)
		),
		array(
			'name'        => __( 'Cell margin', 'apollo13-framework' ),
			'description' => __( 'Space between cells.', 'apollo13-framework' ),
			'id'          => 'scroller_cell_margin',
			'default'     => '10px',
			'unit'        => 'px',
			'min'         => 0,
			'max'         => 100,
			'type'        => 'slider',
			'paid' => 1,
			'required'    => array(
				array( 'theme', '!=', 'slider' ),
				array( 'theme', '!=', 'bricks' ),
			)
		),
		array(
			'name'        => __( 'Cover or contain opened photos?', 'apollo13-framework' ),
			'description' => __( 'When photo is opened to full width, should it contain(whole photo visible) in cell or cover it(whole area covered by photo).', 'apollo13-framework' ),
			'id'          => 'scroller_opened_photo_behavior',
			'default'     => 'cover',
			'options'     => array(
				'cover'  => __( 'Cover', 'apollo13-framework' ),
				'contain' => __( 'Contain', 'apollo13-framework' ),
			),
			'type'        => 'radio',
			'paid' => 1,
			'required'    => array(
				array( 'theme', '!=', 'slider' ),
				array( 'theme', '!=', 'bricks' ),
			)
		),
		array(
			'name'        => __( 'Wrap around', 'apollo13-framework' ),
			'description' => __( 'At the end of cells, wrap-around to the other end for infinite scrolling.', 'apollo13-framework' ),
			'id'          => 'scroller_wrap_around',
			'default'     => 'on',
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'type'        => 'radio',
			'paid' => 1,
			'required'    => array(
				array( 'theme', '!=', 'slider' ),
				array( 'theme', '!=', 'bricks' ),
			)
		),
		array(
			'name'        => __( 'Contain', 'apollo13-framework' ),
			'description' => __( 'Contains cells to scroller element to prevent excess scroll at beginning or end. Has no effect if "Wrap around" is enabled.', 'apollo13-framework' ),
			'id'          => 'scroller_contain',
			'default'     => 'on',
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'type'        => 'radio',
			'paid' => 1,
			'required'    => array(
				array( 'theme', '!=', 'slider' ),
				array( 'theme', '!=', 'bricks' ),
				array( 'scroller_wrap_around', '=', 'off' ),
			)
		),
		array(
			'name'        => __( 'Free scroll', 'apollo13-framework' ),
			'description' => __( 'Enables content to be freely scrolled and flicked without aligning cells to an end position.', 'apollo13-framework' ),
			'id'          => 'scroller_free_scroll',
			'default'     => 'off',
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'type'        => 'radio',
			'paid' => 1,
			'required'    => array(
				array( 'theme', '!=', 'slider' ),
				array( 'theme', '!=', 'bricks' ),
			)
		),
		array(
			'name'        => __( 'Prev/Next buttons', 'apollo13-framework' ),
			'description' => __( 'Enables previous & next buttons.', 'apollo13-framework' ),
			'id'          => 'scroller_arrows',
			'default'     => 'on',
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'type'        => 'radio',
			'paid' => 1,
			'required'    => array(
				array( 'theme', '!=', 'slider' ),
				array( 'theme', '!=', 'bricks' ),
			)
		),
		array(
			'name'        => __( 'Page dots', 'apollo13-framework' ),
			'description' => __( 'Enables page dots.', 'apollo13-framework' ),
			'id'          => 'scroller_dots',
			'default'     => 'off',
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'type'        => 'radio',
			'paid' => 1,
			'required'    => array(
				array( 'theme', '!=', 'slider' ),
				array( 'theme', '!=', 'bricks' ),
			)
		),
		array(
			'name'        => __( 'Autoplay', 'apollo13-framework' ),
			'description' => __( 'Automatically advances to the next cell.', 'apollo13-framework' ),
			'id'          => 'scroller_autoplay',
			'default'     => 'off',
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'type'        => 'radio',
			'paid' => 1,
			'required'    => array(
				array( 'theme', '!=', 'slider' ),
				array( 'theme', '!=', 'bricks' ),
			)
		),
		array(
			'name'        => __( 'Autoplay time(in seconds)', 'apollo13-framework' ),
			'description' => __( 'Advance cells ever X seconds.', 'apollo13-framework' ),
			'id'          => 'scroller_autoplay_time',
			'default'     => 3,
			'step'        => 0.1,
			'unit'        => '',
			'min'         => 0.1,
			'max'         => 10,
			'type'        => 'slider',
			'paid' => 1,
			'required'    => array(
				array( 'theme', '!=', 'slider' ),
				array( 'theme', '!=', 'bricks' ),
				array( 'scroller_autoplay', '=', 'on' ),
			)
		),
		array(
			'name'        => __( 'Pause on hover', 'apollo13-framework' ),
			'description' => __( 'Auto-playing will pause when the user hovers over the scroller.', 'apollo13-framework' ),
			'id'          => 'scroller_pause_autoplay',
			'default'     => 'off',
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'type'        => 'radio',
			'paid' => 1,
			'required'    => array(
				array( 'theme', '!=', 'slider' ),
				array( 'theme', '!=', 'bricks' ),
				array( 'scroller_autoplay', '=', 'on' ),
			)
		),



		/*
		 *
		 * Tab: Album info
		 *
		 */
		array(
			'name' => __('Album info', 'apollo13-framework'),
			'type' => 'fieldset',
			'tab'   => true,
			'icon'  => 'fa fa-info-circle'
		),
		array(
			'name'        => __( 'Internet address', 'apollo13-framework' ),
			'description' => __( 'If empty it will not be displayed.', 'apollo13-framework' ),
			'id'          => 'www',
			'default'     => '',
			'placeholder' => 'http://link-to-somewhere.com',
			'type'        => 'text'
		),
		array(
			'name'        => __( 'Custom info 1', 'apollo13-framework' ),
			'description' => __( 'If empty it will not be displayed. Use pattern <strong>Field name: Field value</strong>. Colon(:) is most important to get full result.', 'apollo13-framework' ),
			'id'          => 'custom_1',
			'default'     => '',
			'placeholder' => 'Label: value',
			'type'        => 'text'
		),
		array(
			'name'        => __( 'Custom info 2', 'apollo13-framework' ),
			'description' => __( 'If empty it will not be displayed. Use pattern <strong>Field name: Field value</strong>. Colon(:) is most important to get full result.', 'apollo13-framework' ),
			'id'          => 'custom_2',
			'default'     => '',
			'placeholder' => 'Label: value',
			'type'        => 'text'
		),
		array(
			'name'        => __( 'Custom info 3', 'apollo13-framework' ),
			'description' => __( 'If empty it will not be displayed. Use pattern <strong>Field name: Field value</strong>. Colon(:) is most important to get full result.', 'apollo13-framework' ),
			'id'          => 'custom_3',
			'default'     => '',
			'placeholder' => 'Label: value',
			'type'        => 'text'
		),
		array(
			'name'        => __( 'Custom info 4', 'apollo13-framework' ),
			'description' => __( 'If empty it will not be displayed. Use pattern <strong>Field name: Field value</strong>. Colon(:) is most important to get full result.', 'apollo13-framework' ),
			'id'          => 'custom_4',
			'default'     => '',
			'placeholder' => 'Label: value',
			'type'        => 'text'
		),
		array(
			'name'        => __( 'Custom info 5', 'apollo13-framework' ),
			'description' => __( 'If empty it will not be displayed. Use pattern <strong>Field name: Field value</strong>. Colon(:) is most important to get full result.', 'apollo13-framework' ),
			'id'          => 'custom_5',
			'default'     => '',
			'placeholder' => 'Label: value',
			'type'        => 'text'
		),

		/*
		 *
		 * Tab: Photo Proofing
		 *
		 */
		array(
			'name' => __('Photo Proofing', 'apollo13-framework'),
			'type' => 'fieldset',
			'tab'   => true,
			'paid' => 1,
			'icon'  => 'fa fa-thumb-tack',
			'notice' => $apollo13framework_a13->check_for_valid_license() ?
				__( 'This option works only if album is displayed in bricks mode.', 'apollo13-framework' ) :
				apply_filters('apollo13framework_valid_license_notice_in_meta', sprintf( __( 'You have to provide valid license for theme to enable this feature. You can do it <a href="%s">here</a>.', 'apollo13-framework' ), admin_url( 'themes.php?page=apollo13_info')))
		),
		array(
			'name'        => __( 'Enable Photo Proofing', 'apollo13-framework' ),
			'description' => __( 'If enabled, then in this album visitor will be able to mark photos and add comments to them.', 'apollo13-framework' ),
			'id'          => 'proofing',
			'default'     => 'off',
			'type'        => 'radio',
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'paid' => 1,
		),
		array(
			'name'        => __( 'Manual IDs', 'apollo13-framework' ),
			'id'          => 'proofing_ids',
			'description' => __( 'If you want to add ID to each item manually then switch to "manual" mode. "Auto" mode will use IDs from Media Library. External media(like YouTube or Vimeo) can only have IDs added manually.', 'apollo13-framework' ),
			'default'     => 'auto',
			'options'     => array(
				'auto'   => __( 'Auto', 'apollo13-framework' ),
				'manual' => __( 'Manual', 'apollo13-framework' ),
			),
			'type'        => 'radio',
			'paid' => 1,
			'required'    => array( 'proofing', '=', 'on' ),
		),



		/*
		 *
		 * Tab: Header
		 *
		 */
		array(
			'name' => __('Header', 'apollo13-framework'),
			'type' => 'fieldset',
			'tab'   => true,
			'icon'  => 'fa fa-cogs'
		),
		array(
			'name'          => __( 'Hide content under header', 'apollo13-framework' ),
			'description'   => __( 'Only valid when using horizontal header.', 'apollo13-framework' ),
			'id'            => 'content_under_header',
			'global_value'  => 'G',
			'default'       => 'G',
			'parent_option' => 'album_content_under_header',
			'type'          => 'select',
			'options'       => array(
				'G'       => __( 'Global settings', 'apollo13-framework' ),
				'content' => __( 'Yes hide content', 'apollo13-framework' ),
				'off'     => __( 'Turn it off', 'apollo13-framework' ),
			),
		),
		array(
			'name'          => __( 'Header color variant', 'apollo13-framework' ),
			'description'   => __( 'Only valid when using horizontal header.', 'apollo13-framework' ),
			'id'            => 'horizontal_header_color_variant',
			'global_value'  => 'G',
			'default'       => 'G',
			'parent_option' => 'album_horizontal_header_color_variant',
			'paid'          => 1,
			'type'          => 'select',
			'options'       => array(
				'G'      => __( 'Global settings', 'apollo13-framework' ),
				'normal' => __( 'Normal', 'apollo13-framework' ),
				'light'  => __( 'Light', 'apollo13-framework' ),
				'dark'   => __( 'Dark', 'apollo13-framework' ),
			),
		),
		array(
			'name'          => __( 'Header custom sidebar', 'apollo13-framework' ),
			'description'   => __( 'Works only with vertical header. Special widgets that should be shown on this page in header.', 'apollo13-framework' ),
			'id'            => 'header_custom_sidebar',
			'global_value'  => 'G',
			'default'       => 'G',
			'parent_option' => 'header_custom_sidebar',
			'options'       => $header_sidebars,
			'paid'          => 1,
			'type'          => 'select',
		),
	);

	return $meta;
}



function apollo13framework_meta_boxes_images_manager() {
	$meta = array(
		array(
			'name' => '',
			'type' => 'fieldset'
		),
		array(
			'name'       => __( 'Multi upload', 'apollo13-framework' ),
			'id'         => 'images_n_videos',
			'type'       => 'multi-upload',
			'default'    => '[]', //empty JSON
			'media_type' => 'image,video', /* 'audio,video' */
		),
		array(
			'name'         => '',
			'type'         => 'fieldset',
			'is_prototype' => true,
			'id'           => 'mu-prototype-image',
		),
		array(
			'name'        => __( 'Tags', 'apollo13-framework' ),
			'description' => __( 'Separate tags with commas', 'apollo13-framework' ),
			'id'          => 'image_tags',
			'default'     => '',
			'type'        => 'tag_media',
		),
		array(
			'name'        => __( 'Link', 'apollo13-framework' ),
			'description' => __( 'Alternative link', 'apollo13-framework' ),
			'id'          => 'image_link',
			'default'     => '',
			'type'        => 'text',
		),
		array(
			'name'        => __( 'Product this image represents', 'apollo13-framework' ),
			'description' => __( 'If you fill this, then on image you will see "add to cart" button.', 'apollo13-framework' ),
			'id'          => 'image_product_id',
			'default'     => '',
			'type'        => 'wp_dropdown_products',
			'paid' => 1,
		),
		array(
			'name'        => __( 'Proofing ID', 'apollo13-framework' ),
			'description' => __( 'If you enabled photo proofing and manual IDs then you can set it here.', 'apollo13-framework' ),
			'id'          => 'image_proofing_id',
			'default'     => '',
			'type'        => 'text',
			'paid' => 1,
		),
		array(
			'name'    => __( 'Color under photo', 'apollo13-framework' ),
			'id'      => 'image_bg_color',
			'default' => '',
			'type'    => 'color'
		),
		array(
			'name'        => __( 'RatioX in bricks theme', 'apollo13-framework' ),
			'description' => __( 'How many bricks area should take this image.', 'apollo13-framework' ),
			'id'          => 'image_ratio_x',
			'default'     => 1,
			'unit'        => '',
			'min'         => 1,
			'max'         => 6,
			'type'        => 'slider'
		),
		array(
			'name'         => '',
			'type'         => 'fieldset',
			'is_prototype' => true,
			'id'           => 'mu-prototype-video',
		),
		array(
			'name'        => __( 'Tags', 'apollo13-framework' ),
			'description' => __( 'Separate tags with commas', 'apollo13-framework' ),
			'id'          => 'video_tags',
			'default'     => '',
			'type'        => 'tag_media',
		),
		array(
			'name'        => __( 'Autoplay video', 'apollo13-framework' ),
			'description' => __( 'Works only in slider', 'apollo13-framework' ),
			'id'          => 'video_autoplay',
			'default'     => '0',
			'options'     => array(
				'1' => __( 'On', 'apollo13-framework' ),
				'0' => __( 'Off', 'apollo13-framework' ),
			),
			'type'        => 'radio',
		),
		array(
			'name'        => __( 'Proofing ID', 'apollo13-framework' ),
			'description' => __( 'If you enabled photo proofing and manual IDs then you can set it here.', 'apollo13-framework' ),
			'id'          => 'video_proofing_id',
			'default'     => '',
			'type'        => 'text',
			'paid' => 1,
		),
		array(
			'name'        => __( 'RatioX in bricks theme', 'apollo13-framework' ),
			'description' => __( 'How many bricks area should take this video.', 'apollo13-framework' ),
			'id'          => 'video_ratio_x',
			'default'     => 1,
			'unit'        => '',
			'min'         => 1,
			'max'         => 6,
			'type'        => 'slider'
		),
		array(
			'name'         => '',
			'type'         => 'fieldset',
			'is_prototype' => true,
			'id'           => 'mu-prototype-audio',
		),
		array(
			'name'        => __( 'Tags', 'apollo13-framework' ),
			'description' => __( 'Separate tags with commas', 'apollo13-framework' ),
			'id'          => 'audio_tags',
			'default'     => '',
			'type'        => 'tag_media',
		),
		array(
			'name'    => __( 'Autoplay audio', 'apollo13-framework' ),
			'id'      => 'audio_autoplay',
			'default' => '0',
			'options' => array(
				'1' => __( 'On', 'apollo13-framework' ),
				'0' => __( 'Off', 'apollo13-framework' ),
			),
			'type'    => 'radio',
		),
		array(
			'name'        => __( 'RatioX in bricks theme', 'apollo13-framework' ),
			'description' => __( 'How many bricks area should take this audio.', 'apollo13-framework' ),
			'id'          => 'audio_ratio_x',
			'default'     => 1,
			'unit'        => '',
			'min'         => 1,
			'max'         => 6,
			'type'        => 'slider'
		),
		array(
			'name'         => '',
			'type'         => 'fieldset',
			'is_prototype' => true,
			'id'           => 'mu-prototype-videolink',
		),
		array(
			'name'        => __( 'Link to video', 'apollo13-framework' ),
			'description' => __( 'Insert here link to your  youtube/vimeo video.', 'apollo13-framework' ),
			'id'          => 'videolink_link',
			'default'     => '',
			'type'        => 'text',
		),
		array(
			'name'             => __( 'Video Thumb', 'apollo13-framework' ),
			'description'      => __( 'Displayed instead of video placeholder in some cases. If none, placeholder will be used(for youtube movies default thumbnail will show).', 'apollo13-framework' ),
			'id'               => 'videolink_poster',
			'default'          => '',
			'button_text'      => __( 'Upload Image', 'apollo13-framework' ),
			'attachment_field' => 'videolink_attachment_id',
			'type'             => 'upload'
		),
		array(
			'name'    => __( 'Attachment id', 'apollo13-framework' ),
			'id'      => 'videolink_attachment_id',
			'default' => '',
			'type'    => 'hidden'
		),
		array(
			'name'        => __( 'Tags', 'apollo13-framework' ),
			'description' => __( 'Separate tags with commas', 'apollo13-framework' ),
			'id'          => 'videolink_tags',
			'default'     => '',
			'type'        => 'tag_media',
		),
		array(
			'name'        => __( 'Autoplay video', 'apollo13-framework' ),
			'description' => __( 'Works only in slider', 'apollo13-framework' ),
			'id'          => 'videolink_autoplay',
			'default'     => '0',
			'options'     => array(
				'1' => __( 'On', 'apollo13-framework' ),
				'0' => __( 'Off', 'apollo13-framework' ),
			),
			'type'        => 'radio',
		),
		array(
			'name'        => __( 'Proofing ID', 'apollo13-framework' ),
			'description' => __( 'If you enabled photo proofing and manual IDs then you can set it here.', 'apollo13-framework' ),
			'id'          => 'videolink_proofing_id',
			'default'     => '',
			'type'        => 'text',
			'paid' => 1,
		),
		array(
			'name'        => __( 'RatioX in bricks theme', 'apollo13-framework' ),
			'description' => __( 'How many bricks area should take this video.', 'apollo13-framework' ),
			'id'          => 'videolink_ratio_x',
			'default'     => 1,
			'unit'        => '',
			'min'         => 1,
			'max'         => 6,
			'type'        => 'slider'
		),
		array(
			'name'    => __( 'Title', 'apollo13-framework' ),
			'id'      => 'videolink_title',
			'default' => '',
			'type'    => 'text'
		),
		array(
			'name'    => __( 'Description', 'apollo13-framework' ),
			'id'      => 'videolink_desc',
			'default' => '',
			'type'    => 'textarea',
		),
	);

	return $meta;
}



function apollo13framework_get_socials_array() {
	global $apollo13framework_a13;

	$tmp_arr = array();
	$socials = $apollo13framework_a13->get_social_icons_list();
	foreach ( $socials as $id => $social ) {
		array_push( $tmp_arr, array( 'name' => $social, 'id' => $id, 'type' => 'text' ) );
	}
	return $tmp_arr;
}



function apollo13framework_meta_boxes_people() {
	$meta =
		array_merge(
			array(
				/*
				 *
				 * Tab: General
				 *
				 */
				array(
					'name' => __('General', 'apollo13-framework'),
					'type' => 'fieldset',
					'tab'   => true,
					'icon'  => 'fa fa-wrench'
				),
				array(
						'name'        => __( 'Subtitle', 'apollo13-framework' ),
						'description' => __( 'You can use HTML here.', 'apollo13-framework' ),
						'id'          => 'subtitle',
						'default'     => '',
						'type'        => 'text'
				),
				array(
						'name'    => __( 'Testimonial', 'apollo13-framework' ),
						'desc'    => '',
						'id'      => 'testimonial',
						'default' => '',
						'type'    => 'textarea'
				),
				array(
						'name'        => __( 'Overlay color', 'apollo13-framework' ),
						'description' => __( 'Use valid CSS <code>color</code> property values( <code>green, #33FF99, rgb(255,128,0), rgba(222,112,12,0.5)</code> ), or get your color with color picker tool. Left empty to use default theme value.', 'apollo13-framework' ),
						'id'          => 'overlay_bg_color',
						'default'     => 'rgba(0,0,0,0.5)',
						'type'        => 'color'
				),
				array(
						'name'        => __( 'Overlay font color', 'apollo13-framework' ),
						'description' => __( 'Use valid CSS <code>color</code> property values( <code>green, #33FF99, rgb(255,128,0), rgba(222,112,12,0.5)</code> ), or get your color with color picker tool. Left empty to use default theme value.', 'apollo13-framework' ),
						'id'          => 'overlay_font_color',
						'default'     => 'rgba(255,255,255,1)',
						'type'        => 'color'
				),

				/*
				 *
				 * Tab: Socials
				 *
				 */
				array(
					'name' => __('Socials', 'apollo13-framework'),
					'type' => 'fieldset',
					'tab'   => true,
					'icon'  => 'fa fa-facebook-official'
				),
			), apollo13framework_get_socials_array()
		);

	return $meta;
}



function apollo13framework_meta_boxes_work() {
	global $apollo13framework_a13;

	$header_sidebars = array(
		'G'   => __( 'Global settings', 'apollo13-framework' ),
		'off' => __( 'Off', 'apollo13-framework' ),
	);

	$custom_sidebars = unserialize( $apollo13framework_a13->get_option( 'custom_sidebars' ) );
	$custom_sidebars = is_array($custom_sidebars)? $custom_sidebars : array($custom_sidebars);
	$sidebars_count  = count( $custom_sidebars );
	if ( is_array( $custom_sidebars ) && $sidebars_count > 0 ) {
		foreach ( $custom_sidebars as $sidebar ) {
			$header_sidebars[ $sidebar['id'] ] = $sidebar['name'];
		}
	}

	$meta = array(
		/*
		 *
		 * Tab: Works list
		 *
		 */
		array(
			'name' => __('Works list', 'apollo13-framework'),
			'type' => 'fieldset',
			'tab'   => true,
			'icon'  => 'fa fa-list'
		),
		array(
			'name'        => __( 'Alternative Link', 'apollo13-framework' ),
			'description' => __( 'If you fill this then clicking in your work on works list will not lead to single work page but to link from this field.', 'apollo13-framework' ),
			'id'          => 'alt_link',
			'default'     => '',
			'type'        => 'text',
		),
		array(
			'name'    => __( 'Subtitle', 'apollo13-framework' ),
			'id'      => 'subtitle',
			'default' => '',
			'type'    => 'text'
		),
		array(
			'name'        => __( 'Size of brick', 'apollo13-framework' ),
			'description' => __( 'How many bricks area should take this work in works list.', 'apollo13-framework' ),
			'id'          => 'brick_ratio_x',
			'default'     => 1,
			'unit'        => '',
			'min'         => 1,
			'max'         => 4,
			'type'        => 'slider'
		),
		array(
			'name'        => __( 'Cover color', 'apollo13-framework' ),
			'id'          => 'cover_color',
			'description' => __( 'Works only when titles are displayed over images in Works list.', 'apollo13-framework' ),
			'default'     => 'rgba(0,0,0, 0.7)',
			'type'        => 'color'
		),
		array(
			'name'        => __( 'Exclude from Works list page', 'apollo13-framework' ),
			'description' => __( 'If enabled, then this work wont be listed on works list page, but you can still select it for front page or in other places.', 'apollo13-framework' ),
			'id'          => 'exclude_in_works_list',
			'default'     => 'off',
			'type'        => 'radio',
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
		),

		/*
		 *
		 * Tab: Work media
		 *
		 */
		array(
			'name' => __('Work media', 'apollo13-framework'),
			'type' => 'fieldset',
			'tab'   => true,
			'icon'  => 'fa fa-th'
		),
		array(
			'name'        => __( 'Items order', 'apollo13-framework' ),
			'description' => __( 'It will display your images/videos from first to last, or another way.', 'apollo13-framework' ),
			'id'          => 'order',
			'default'     => 'ASC',
			'options'     => array(
				'ASC'    => __( 'First on list, first displayed', 'apollo13-framework' ),
				'DESC'   => __( 'First on list, last displayed', 'apollo13-framework' ),
				'random' => __( 'Random', 'apollo13-framework' ),
			),
			'type'        => 'select',
		),
		array(
			'name'        => __( 'Show title and description of work items', 'apollo13-framework' ),
			'description' => __( 'If enabled, then it will affect displaying in bricks and slider option, and also in lightbox.', 'apollo13-framework' ),
			'id'          => 'enable_desc',
			'default'     => 'off',
			'type'        => 'radio',
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
		),
		array(
			'name'    => __( 'Present media in:', 'apollo13-framework' ),
			'id'      => 'theme',
			'default' => 'bricks',
			'options' => array(
				'bricks' => __( 'Bricks', 'apollo13-framework' ),
				'slider' => __( 'Slider', 'apollo13-framework' ),
				'off' => __( 'Do not display', 'apollo13-framework' ),
			),
			'type'    => 'radio',
		),
		array(
			'name'        => __( 'Bricks columns', 'apollo13-framework' ),
			'id'          => 'brick_columns',
			'default'     => '3',
			'unit'        => '',
			'min'         => 1,
			'max'         => 6,
			'type'        => 'slider',
			'required'    => array( 'theme', '=', 'bricks' ),
		),
		array(
			'name'        => __( 'Max width of bricks content.', 'apollo13-framework' ),
			'description' => __( 'Depending on actual screen width, available space for bricks might be smaller, but newer greater then this number.', 'apollo13-framework' ),
			'id'          => 'bricks_max_width',
			'default'     => '1920px',
			'unit'        => 'px',
			'min'         => 200,
			'max'         => 2500,
			'type'        => 'slider',
			'required'    => array( 'theme', '=', 'bricks' ),
		),
		array(
			'name'     => __( 'Brick margin', 'apollo13-framework' ),
			'id'       => 'brick_margin',
			'default'  => '0px',
			'unit'     => 'px',
			'min'      => 0,
			'max'      => 100,
			'type'     => 'slider',
			'required' => array( 'theme', '=', 'bricks' ),
		),
		array(
			'name'     => __( 'Choose brick proportion', 'apollo13-framework' ),
			'description' => __( 'Works only for images. If you switch theme option "Display thumbs instead of video", then for videos that you will upload image it will also work.', 'apollo13-framework' ),
			'id'       => 'bricks_proportions_size',
			'default'  => '0',
			'options' => array(
				'0'    => __( 'Original size', 'apollo13-framework' ),
				'1/1'  => __( '1:1', 'apollo13-framework' ),
				'2/3'  => __( '2:3', 'apollo13-framework' ),
				'3/2'  => __( '3:2', 'apollo13-framework' ),
				'3/4'  => __( '3:4', 'apollo13-framework' ),
				'4/3'  => __( '4:3', 'apollo13-framework' ),
				'9/16' => __( '9:16', 'apollo13-framework' ),
				'16/9' => __( '16:9', 'apollo13-framework' ),
			),
			'type'     => 'select',
			'required' => array( 'theme', '=', 'bricks' ),
		),
		array(
			'id'       => 'bricks_lightbox',
			'type'     => 'radio',
			'name'     => __( 'Open bricks to lightbox', 'apollo13-framework' ),
			'options'  => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'default'  => 'on',
			'required' => array( 'theme', '=', 'bricks' ),
		),
		array(
			'name'        => __( 'Color of cover', 'apollo13-framework' ),
			'description' => __( 'Leave empty to not set any background', 'apollo13-framework' ),
			'id'          => 'slide_cover_color',
			'default'     => 'rgba(0,0,0, 0.7)',
			'type'        => 'color',
			'required'    => array( 'theme', '=', 'bricks' ),
		),
		array(
			'name'     => __( 'Hover effect', 'apollo13-framework' ),
			'id'       => 'bricks_hover',
			'default'  => 'cross',
			'options'  => array(
				'cross'  => __( 'Show cross', 'apollo13-framework' ),
				'drop'   => __( 'Drop', 'apollo13-framework' ),
				'shift'  => __( 'Shift', 'apollo13-framework' ),
				'pop'    => __( 'Pop', 'apollo13-framework' ),
				'border' => __( 'Border', 'apollo13-framework' ),
				'none'   => __( 'None', 'apollo13-framework' ),
			),
			'type'     => 'select',
			'required' => array( 'theme', '=', 'bricks' ),
		),
		array(
			'id'       => 'bricks_title_position',
			'type'     => 'select',
			'name'     => __( 'Texts position', 'apollo13-framework' ),
			'options'  => array(
				'top_left'      => __( 'Top left', 'apollo13-framework' ),
				'top_center'    => __( 'Top center', 'apollo13-framework' ),
				'top_right'     => __( 'Top right', 'apollo13-framework' ),
				'mid_left'      => __( 'Middle left', 'apollo13-framework' ),
				'mid_center'    => __( 'Middle center', 'apollo13-framework' ),
				'mid_right'     => __( 'Middle right', 'apollo13-framework' ),
				'bottom_left'   => __( 'Bottom left', 'apollo13-framework' ),
				'bottom_center' => __( 'Bottom center', 'apollo13-framework' ),
				'bottom_right'  => __( 'Bottom right', 'apollo13-framework' ),
			),
			'default'  => 'bottom_center',
			'required' => array( 'theme', '=', 'bricks' ),
		),
		array(
			'id'       => 'bricks_overlay_cover',
			'type'     => 'radio',
			'name'     => __( 'Show cover when not hovering', 'apollo13-framework' ),
			'options'  => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'default'  => 'off',
			'required' => array( 'theme', '=', 'bricks' ),
		),
		array(
			'id'       => 'bricks_overlay_cover_hover',
			'type'     => 'radio',
			'name'     => __( 'Show cover when hovering', 'apollo13-framework' ),
			'options'  => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'default'  => 'on',
			'required' => array( 'theme', '=', 'bricks' ),
		),
		array(
			'id'          => 'bricks_overlay_gradient',
			'type'        => 'radio',
			'name'        => __( 'Show gradient when not hovering', 'apollo13-framework' ),
			'description' => __( 'Its main function is to make texts more visible', 'apollo13-framework' ),
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'default'     => 'off',
			'required'    => array( 'theme', '=', 'bricks' ),
		),
		array(
			'id'          => 'bricks_overlay_gradient_hover',
			'type'        => 'radio',
			'name'        => __( 'Show gradient when hovering', 'apollo13-framework' ),
			'description' => __( 'Its main function is to make texts more visible', 'apollo13-framework' ),
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'default'     => 'off',
			'required'    => array( 'theme', '=', 'bricks' ),
		),
		array(
			'id'       => 'bricks_overlay_texts',
			'type'     => 'radio',
			'name'     => __( 'Show texts when not hovering', 'apollo13-framework' ),
			'options'  => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'default'  => 'off',
			'required' => array(
				array( 'theme', '=', 'bricks' ),
				array( 'enable_desc', '=', 'on' )
			),
		),
		array(
			'id'       => 'bricks_overlay_texts_hover',
			'type'     => 'radio',
			'name'     => __( 'Show texts when hovering', 'apollo13-framework' ),
			'options'  => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'default'  => 'on',
			'required' => array(
				array( 'theme', '=', 'bricks' ),
				array( 'enable_desc', '=', 'on' )
			),
		),

		array(
			'name'          => __( 'Stretch slider to be window high', 'apollo13-framework' ),
			'description'   => __( 'If there is enough space(more then 100px), slider will be stretched in height to take available space, in regards to header and title bar if they are present.', 'apollo13-framework' ),
			'id'            => 'slider_window_high',
			'default'     => 'off',
			'options'       => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'type'          => 'radio',
			'required'      => array( 'theme', '=', 'slider' ),
		),
		/* we don't hide proportion options cause they are fallback if there is not enough space for full height slider */
		array(
			'name'        => __( 'Slider - width proportion', 'apollo13-framework' ),
			'id'          => 'slider_width_proportion',
			'default'     => '16',
			'unit'        => '',
			'min'         => 1,
			'max'         => 20,
			'type'        => 'slider',
			'required'    => array( 'theme', '=', 'slider' ),
		),
		array(
			'name'        => __( 'Slider - height proportion', 'apollo13-framework' ),
			'id'          => 'slider_height_proportion',
			'default'     => '9',
			'unit'        => '',
			'min'         => 1,
			'max'         => 20,
			'type'        => 'slider',
			'required'    => array( 'theme', '=', 'slider' ),
		),
		array(
			'name'        => __( 'Fit images', 'apollo13-framework' ),
			'description' => __( 'How will images fit area. <strong>Fit when needed</strong> is best for small images, that should not be stretched to bigger sizes, only to smaller(to keep them visible).', 'apollo13-framework' ),
			'id'          => 'fit_variant',
			'default'     => '4',
			'options'     => array(
				'0' => __( 'Fit always', 'apollo13-framework' ),
				'1' => __( 'Fit landscape', 'apollo13-framework' ),
				'2' => __( 'Fit portrait', 'apollo13-framework' ),
				'3' => __( 'Fit when needed', 'apollo13-framework' ),
				'4' => __( 'Cover whole screen', 'apollo13-framework' ),
			),
			'type'        => 'select',
			'required'    => array( 'theme', '=', 'slider' ),
		),
		array(
			'name'          => __( 'Autoplay', 'apollo13-framework' ),
			'description'   => __( 'If autoplay is on, slider items will start sliding on page load', 'apollo13-framework' ),
			'id'            => 'autoplay',
			'default'       => 'G',
			'global_value'  => 'G',
			'parent_option' => 'work_slider_autoplay',
			'options'       => array(
				'G'   => __( 'Global settings', 'apollo13-framework' ),
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'type'          => 'select',
			'required'      => array( 'theme', '=', 'slider' ),
		),
		array(
			'name'          => __( 'Transition type', 'apollo13-framework' ),
			'description'   => __( 'Animation between slides.', 'apollo13-framework' ),
			'id'            => 'transition',
			'default'       => '-1',
			'global_value'  => '-1',
			'parent_option' => 'work_slider_transition_type',
			'options'       => array(
				'-1' => __( 'Global settings', 'apollo13-framework' ),
				'0'  => __( 'None', 'apollo13-framework' ),
				'1'  => __( 'Fade', 'apollo13-framework' ),
				'2'  => __( 'Carousel', 'apollo13-framework' ),
				'3'  => __( 'Zooming', 'apollo13-framework' ),
			),
			'type'          => 'select',
			'required'      => array( 'theme', '=', 'slider' ),
		),
		array(
			'name'        => __( 'Scale in %', 'apollo13-framework' ),
			'description' => __( 'How big zooming effect will be', 'apollo13-framework' ),
			'id'          => 'ken_scale',
			'default'     => 120,
			'unit'        => '%',
			'min'         => 100,
			'max'         => 200,
			'type'        => 'slider',
			'required'    => array(
				array( 'theme', '=', 'slider' ),
				array( 'transition', '=', '3' ),
			)
		),
		array(
			'name'        => __( 'Gradient above photos', 'apollo13-framework' ),
			'description' => __( 'Good for better readability of slide titles.', 'apollo13-framework' ),
			'id'          => 'gradient',
			'default'     => 'off',
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'type'        => 'radio',
			'required'    => array( 'theme', '=', 'slider' ),
		),
		array(
			'name'        => __( 'Color under title', 'apollo13-framework' ),
			'description' => __( 'Leave empty to not set any background', 'apollo13-framework' ),
			'id'          => 'slide_title_bg_color',
			'default'     => '',
			'type'        => 'color',
			'required'    => array(
				array( 'enable_desc', '=', 'on' ),
				array( 'theme', '=', 'slider' )
			)
		),
		array(
			'name'     => __( 'Pattern above photos', 'apollo13-framework' ),
			'id'       => 'pattern',
			'default'  => '0',
			'options'  => array(
				'0' => __( 'None', 'apollo13-framework' ),
				'1' => __( 'Type 1', 'apollo13-framework' ),
				'2' => __( 'Type 2', 'apollo13-framework' ),
				'3' => __( 'Type 3', 'apollo13-framework' ),
				'4' => __( 'Type 4', 'apollo13-framework' ),
				'5' => __( 'Type 5', 'apollo13-framework' ),
			),
			'type'     => 'select',
			'required' => array( 'theme', '=', 'slider' ),
		),
		array(
			'name'          => __( 'List of Thumbs', 'apollo13-framework' ),
			'id'            => 'thumbs',
			'default'       => 'G',
			'global_value'  => 'G',
			'parent_option' => 'work_slider_thumbs',
			'options'       => array(
				'G'   => __( 'Global settings', 'apollo13-framework' ),
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'type'          => 'select',
			'required'      => array( 'theme', '=', 'slider' ),
		),
		array(
			'name'        => __( 'Display thumbs opened', 'apollo13-framework' ),
			'description' => __( 'If thumbs are enabled, should they be open by default?', 'apollo13-framework' ),
			'id'          => 'thumbs_on_load',
			'default'     => 'off',
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'type'        => 'radio',
			'required'    => array( 'theme', '=', 'slider' ),
		),
		array(
			'name'     => __( 'Slider background color', 'apollo13-framework' ),
			'id'       => 'slider_bg_color',
			'default'  => '',
			'type'     => 'color',
			'required'      => array( 'theme', '=', 'slider' ),
		),
		array(
			'name'     => __( 'Media top margin', 'apollo13-framework' ),
			'id'       => 'media_margin_top',
			'default'  => '0px',
			'unit'     => 'px',
			'min'      => 0,
			'max'      => 100,
			'type'     => 'slider',
			'required' => array( 'theme', '!=', 'off' ),
		),
		array(
			'name'     => __( 'Media bottom margin', 'apollo13-framework' ),
			'id'       => 'media_margin_bottom',
			'default'  => '0px',
			'unit'     => 'px',
			'min'      => 0,
			'max'      => 100,
			'type'     => 'slider',
			'required' => array( 'theme', '!=', 'off' ),
		),

		/*
		 *
		 * Tab: Work info
		 *
		 */
		array(
			'name' => __('Work info', 'apollo13-framework'),
			'type' => 'fieldset',
			'tab'   => true,
			'icon'  => 'fa fa-info-circle'
		),
		array(
			'name'        => __( 'Internet address', 'apollo13-framework' ),
			'description' => __( 'If empty it will not be displayed.', 'apollo13-framework' ),
			'id'          => 'www',
			'default'     => '',
			'placeholder' => 'http://link-to-somewhere.com',
			'type'        => 'text'
		),
		array(
			'name'        => __( 'Custom info 1', 'apollo13-framework' ),
			'description' => __( 'If empty it will not be displayed. Use pattern <strong>Field name: Field value</strong>. Colon(:) is most important to get full result.', 'apollo13-framework' ),
			'id'          => 'custom_1',
			'default'     => '',
			'placeholder' => 'Label: value',
			'type'        => 'text'
		),
		array(
			'name'        => __( 'Custom info 2', 'apollo13-framework' ),
			'description' => __( 'If empty it will not be displayed. Use pattern <strong>Field name: Field value</strong>. Colon(:) is most important to get full result.', 'apollo13-framework' ),
			'id'          => 'custom_2',
			'default'     => '',
			'placeholder' => 'Label: value',
			'type'        => 'text'
		),
		array(
			'name'        => __( 'Custom info 3', 'apollo13-framework' ),
			'description' => __( 'If empty it will not be displayed. Use pattern <strong>Field name: Field value</strong>. Colon(:) is most important to get full result.', 'apollo13-framework' ),
			'id'          => 'custom_3',
			'default'     => '',
			'placeholder' => 'Label: value',
			'type'        => 'text'
		),
		array(
			'name'        => __( 'Custom info 4', 'apollo13-framework' ),
			'description' => __( 'If empty it will not be displayed. Use pattern <strong>Field name: Field value</strong>. Colon(:) is most important to get full result.', 'apollo13-framework' ),
			'id'          => 'custom_4',
			'default'     => '',
			'placeholder' => 'Label: value',
			'type'        => 'text'
		),
		array(
			'name'        => __( 'Custom info 5', 'apollo13-framework' ),
			'description' => __( 'If empty it will not be displayed. Use pattern <strong>Field name: Field value</strong>. Colon(:) is most important to get full result.', 'apollo13-framework' ),
			'id'          => 'custom_5',
			'default'     => '',
			'placeholder' => 'Label: value',
			'type'        => 'text'
		),

		/*
		 *
		 * Tab: Layout
		 *
		 */
		array(
			'name' => __('Layout', 'apollo13-framework'),
			'type' => 'fieldset',
			'tab'   => true,
			'icon'  => 'fa fa-wrench'
		),
		array(
			'name'          => __( 'Content Layout', 'apollo13-framework' ),
			'id'            => 'content_layout',
			'default'       => 'global',
			'global_value'  => 'global',
			'parent_option' => 'work_content_layout',
			'type'          => 'select',
			'options'       => array(
				'global'        => __( 'Global settings', 'apollo13-framework' ),
				'center'        => __( 'Center fixed width', 'apollo13-framework' ),
				'left'          => __( 'Left fixed width', 'apollo13-framework' ),
				'left_padding'  => __( 'Left fixed width + padding', 'apollo13-framework' ),
				'right'         => __( 'Right fixed width', 'apollo13-framework' ),
				'right_padding' => __( 'Right fixed width + padding', 'apollo13-framework' ),
				'full_fixed'    => __( 'Full width + fixed content', 'apollo13-framework' ),
				'full_padding'  => __( 'Full width + padding', 'apollo13-framework' ),
				'full'          => __( 'Full width', 'apollo13-framework' ),
			),
		),
		array(
			'name'        => __( 'Content top/bottom padding', 'apollo13-framework' ),
			'description' => __( 'Enable or disable top and bottom padding of content. It is helpful in achieving some neat layout effects:-).', 'apollo13-framework' ),
			'id'          => 'content_padding',
			'default'     => 'both',
			'type'        => 'select',
			'options'     => array(
				'both'   => __( 'Both on', 'apollo13-framework' ),
				'top'    => __( 'Only top', 'apollo13-framework' ),
				'bottom' => __( 'Only bottom', 'apollo13-framework' ),
				'off'    => __( 'Both off', 'apollo13-framework' ),
			),
		),
		array(
			'name'        => __( 'Content side padding', 'apollo13-framework' ),
			'description' => __( 'It is helpful in achieving some neat layout effects:-).', 'apollo13-framework' ),
			'id'          => 'content_side_padding',
			'default'     => 'both',
			'type'        => 'radio',
			'options'     => array(
				'both'   => __( 'Both on', 'apollo13-framework' ),
				'off'    => __( 'Both off', 'apollo13-framework' ),
			),
		),

		/*
		 *
		 * Tab: Header
		 *
		 */
		array(
			'name' => __('Header', 'apollo13-framework'),
			'type' => 'fieldset',
			'tab'   => true,
			'icon'  => 'fa fa-cogs'
		),
		array(
			'name'          => __( 'Hide content under header', 'apollo13-framework' ),
			'description'   => __( 'Only valid when using horizontal header.', 'apollo13-framework' ),
			'id'            => 'content_under_header',
			'global_value'  => 'G',
			'default'       => 'G',
			'parent_option' => 'work_content_under_header',
			'type'          => 'select',
			'options'       => array(
				'G'       => __( 'Global settings', 'apollo13-framework' ),
				'content' => __( 'Yes hide content', 'apollo13-framework' ),
				'title'   => __( 'Yes hide content and add top padding to outside title bar.', 'apollo13-framework' ),
				'off'     => __( 'Turn it off', 'apollo13-framework' ),
			),
		),
		array(
			'name'          => __( 'Header color variant', 'apollo13-framework' ),
			'description'   => __( 'Only valid when using horizontal header.', 'apollo13-framework' ),
			'id'            => 'horizontal_header_color_variant',
			'global_value'  => 'G',
			'default'       => 'G',
			'parent_option' => 'work_horizontal_header_color_variant',
			'paid'          => 1,
			'type'          => 'select',
			'options'       => array(
				'G'      => __( 'Global settings', 'apollo13-framework' ),
				'normal' => __( 'Normal', 'apollo13-framework' ),
				'light'  => __( 'Light', 'apollo13-framework' ),
				'dark'   => __( 'Dark', 'apollo13-framework' ),
			),
		),
		array(
			'name'          => __( 'Header custom sidebar', 'apollo13-framework' ),
			'description'   => __( 'Works only with vertical header. Special widgets that should be shown on this page in header.', 'apollo13-framework' ),
			'id'            => 'header_custom_sidebar',
			'global_value'  => 'G',
			'default'       => 'G',
			'parent_option' => 'header_custom_sidebar',
			'options'       => $header_sidebars,
			'paid'          => 1,
			'type'          => 'select',
		),

		/*
		 *
		 * Tab: Title bar
		 *
		 */
		array(
			'name' => __('Title bar', 'apollo13-framework'),
			'type' => 'fieldset',
			'tab'   => true,
			'icon'  => 'fa fa-text-width'
		),
		array(
			'name'        => __( 'Title bar look', 'apollo13-framework' ),
			'description' => __( 'You can use global settings or overwrite them here', 'apollo13-framework' ),
			'id'          => 'title_bar_settings',
			'default'     => 'global',
			'type'        => 'radio',
			'options'     => array(
				'global' => __( 'Global settings', 'apollo13-framework' ),
				'custom' => __( 'Use custom settings', 'apollo13-framework' ),
				'off'    => __( 'Turn it off', 'apollo13-framework' ),
			),
		),
		array(
			'name'        => __( 'Position', 'apollo13-framework' ),
			'id'          => 'title_bar_position',
			'default'     => 'outside',
			'type'        => 'hidden',//no switching in options, but we leave it as option so it will be future ready, and to not make exceptions for Works
			'options'     => array(
				'outside' => __( 'Before content', 'apollo13-framework' ),
				'inside'  => __( 'Inside content', 'apollo13-framework' ),
			),
			'description' => __( 'To set background image for "Before content" option, use <strong>featured image</strong>.', 'apollo13-framework' ),
			'required'    => array( 'title_bar_settings', '=', 'custom' ),
		),
		array(
			'name'        => __( 'Variant', 'apollo13-framework' ),
			'description' => '',
			'id'          => 'title_bar_variant',
			'default'     => 'classic',
			'options'     => array(
				'classic'  => __( 'Classic(to side)', 'apollo13-framework' ),
				'centered' => __( 'Centered', 'apollo13-framework' ),
			),
			'type'        => 'radio',
			'required'    => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
			)
		),
		array(
			'name'        => __( 'Width', 'apollo13-framework' ),
			'description' => '',
			'id'          => 'title_bar_width',
			'default'     => 'full',
			'options'     => array(
				'full'  => __( 'Full', 'apollo13-framework' ),
				'boxed' => __( 'Boxed', 'apollo13-framework' ),
			),
			'type'        => 'radio',
			'required'    => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
			)
		),
		array(
			'name'     => __( 'How to fit background image', 'apollo13-framework' ),
			'id'       => 'title_bar_image_fit',
			'default'  => 'repeat',
			'options'  => array(
				'cover'    => __( 'Cover', 'apollo13-framework' ),
				'contain'  => __( 'Contain', 'apollo13-framework' ),
				'fitV'     => __( 'Fit Vertically', 'apollo13-framework' ),
				'fitH'     => __( 'Fit Horizontally', 'apollo13-framework' ),
				'center'   => __( 'Just center', 'apollo13-framework' ),
				'repeat'   => __( 'Repeat', 'apollo13-framework' ),
				'repeat-x' => __( 'Repeat X', 'apollo13-framework' ),
				'repeat-y' => __( 'Repeat Y', 'apollo13-framework' ),
			),
			'type'     => 'select',
			'required' => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
			)
		),
		array(
			'name'        => __( 'Enable parallax?', 'apollo13-framework' ),
			'description' => '',
			'id'          => 'title_bar_parallax',
			'default'     => 'off',
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'type'        => 'radio',
			'required'    => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
			)
		),
		array(
			'name'        => __( 'Parallax type', 'apollo13-framework' ),
			'description' => __( 'It defines how image will scroll in background while page is scrolled down.', 'apollo13-framework' ),
			'id'          => 'title_bar_parallax_type',
			'default'     => 'tb',
			'options'     => array(
				"tb"   => __( 'top to bottom', 'apollo13-framework' ),
				"bt"   => __( 'bottom to top', 'apollo13-framework' ),
				"lr"   => __( 'left to right', 'apollo13-framework' ),
				"rl"   => __( 'right to left', 'apollo13-framework' ),
				"tlbr" => __( 'top-left to bottom-right', 'apollo13-framework' ),
				"trbl" => __( 'top-right to bottom-left', 'apollo13-framework' ),
				"bltr" => __( 'bottom-left to top-right', 'apollo13-framework' ),
				"brtl" => __( 'bottom-right to top-left', 'apollo13-framework' ),
			),
			'type'        => 'select',
			'required'    => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
				array( 'title_bar_parallax', '=', 'on' ),
			)
		),
		array(
			'name'        => __( 'Parallax speed', 'apollo13-framework' ),
			'description' => __( 'It will be only used for background that are repeated. If background is set to not repeat this value will be ignored.', 'apollo13-framework' ),
			'id'          => 'title_bar_parallax_speed',
			'default'     => '1.00',
			'type'        => 'text',
			'required'    => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
				array( 'title_bar_parallax', '=', 'on' ),
			)
		),
		array(
			'name'        => __( 'Overlay color', 'apollo13-framework' ),
			'description' => __( 'It will be put above image(if used)', 'apollo13-framework' ),
			'id'          => 'title_bar_bg_color',
			'default'     => '',
			'type'        => 'color',
			'required'    => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
			)
		),
		array(
			'name'     => __( 'Titles color', 'apollo13-framework' ),
			'id'       => 'title_bar_title_color',
			'default'  => '',
			'type'     => 'color',
			'required' => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
			)
		),
		array(
			'name'        => __( 'Second elements color', 'apollo13-framework' ),
			'description' => __( 'Used in breadcrumbs.', 'apollo13-framework' ),
			'id'          => 'title_bar_color_1',
			'default'     => '',
			'type'        => 'color',
			'required'    => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
			)
		),
		array(
			'name'        => __( 'Space in top and bottom', 'apollo13-framework' ),
			'description' => '',
			'id'          => 'title_bar_space_width',
			'default'     => '40px',
			'unit'        => 'px',
			'min'         => 0,
			'max'         => 600,
			'type'        => 'slider',
			'required'    => array(
				array( 'title_bar_settings', '=', 'custom' ),
				array( 'title_bar_position', '!=', 'inside' ),
			)
		),
		array(
			'name'        => __( 'Breadcrumbs', 'apollo13-framework' ),
			'description' => '',
			'id'          => 'breadcrumbs',
			'default'     => 'on',
			'type'        => 'radio',
			'options'     => array(
				'on'  => __( 'Enable', 'apollo13-framework' ),
				'off' => __( 'Disable', 'apollo13-framework' ),
			),
			'required'    => array( 'title_bar_settings', '=', 'custom' ),
		),

		/*
		 *
		 * Tab: Content
		 *
		 */
		array(
			'name' => __('Content', 'apollo13-framework'),
			'type' => 'fieldset',
			'tab'   => true,
			'icon'  => 'fa fa-align-left'
		),
		array(
			'name'          => __( 'Categories in content', 'apollo13-framework' ),
			'id'            => 'content_categories',
			'default'       => 'G',
			'global_value'  => 'G',
			'parent_option' => 'work_content_categories',
			'type'          => 'radio',
			'options'       => array(
				'G'   => __( 'Global settings', 'apollo13-framework' ),
				'on'  => __( 'On', 'apollo13-framework' ),
				'off' => __( 'Off', 'apollo13-framework' ),
			),
		),

		/*
		 *
		 * Tab: Page background
		 *
		 */
		array(
			'name' => __('Page background', 'apollo13-framework'),
			'type' => 'fieldset',
			'tab'   => true,
			'icon'  => 'fa fa-picture-o'
		),
		array(
			'name'        => __( 'Page background', 'apollo13-framework' ),
			'description' => __( 'You can use global settings or overwrite them here', 'apollo13-framework' ),
			'id'          => 'page_bg_settings',
			'default'     => 'global',
			'type'        => 'radio',
			'options'     => array(
				'global' => __( 'Global settings', 'apollo13-framework' ),
				'custom' => __( 'Use custom settings', 'apollo13-framework' ),
			),
		),
		array(
			'name'        => __( 'Page Background image file', 'apollo13-framework' ),
			'id'          => 'page_image',
			'default'     => '',
			'button_text' => __( 'Upload Image', 'apollo13-framework' ),
			'type'        => 'upload',
			'required'    => array( 'page_bg_settings', '=', 'custom' ),
		),
		array(
			'name'     => __( 'How to fit background image', 'apollo13-framework' ),
			'id'       => 'page_image_fit',
			'default'  => 'cover',
			'options'  => array(
				'cover'    => __( 'Cover', 'apollo13-framework' ),
				'contain'  => __( 'Contain', 'apollo13-framework' ),
				'fitV'     => __( 'Fit Vertically', 'apollo13-framework' ),
				'fitH'     => __( 'Fit Horizontally', 'apollo13-framework' ),
				'center'   => __( 'Just center', 'apollo13-framework' ),
				'repeat'   => __( 'Repeat', 'apollo13-framework' ),
				'repeat-x' => __( 'Repeat X', 'apollo13-framework' ),
				'repeat-y' => __( 'Repeat Y', 'apollo13-framework' ),
			),
			'type'     => 'select',
			'required' => array( 'page_bg_settings', '=', 'custom' ),
		),
		array(
			'name'     => __( 'Page Background color', 'apollo13-framework' ),
			'id'       => 'page_bg_color',
			'default'  => '',
			'type'     => 'color',
			'required' => array( 'page_bg_settings', '=', 'custom' ),
		),
	);

	return $meta;
}
