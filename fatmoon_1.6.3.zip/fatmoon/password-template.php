<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly


global $apollo13framework_a13, $wp_query, $post;


//custom template
if($apollo13framework_a13->get_option( 'page_password_template_type' ) === 'custom' ){
	$page = $apollo13framework_a13->get_option( 'page_password_template' );

	//save original query
	$original_query = $wp_query;
	//reset
	$wp_query = null;

	//make query
	$wp_query = new WP_Query( array('page_id' => $page ) );

	//brutal change of query (fight WordPress SEO plugin)
	$GLOBALS['wp_the_query'] = $GLOBALS['wp_query'];

	//add password form to content
	add_filter( 'the_content', 'apollo13framework_add_password_form_to_template' );

	//show
	apollo13framework_page_like_content();

	//return old query
	$wp_query = null;
	$wp_query = $original_query;

	// Reset Post Data
	wp_reset_postdata();

	return;
}

//default template
else{
	define('A13FRAMEWORK_PASSWORD_PROTECTED', true); //to get proper class in body

	$title = '<span class="fa fa-lock emblem"></span>' . esc_html__( 'This content is password protected.', 'apollo13-framework' )
	         .'<br />'
	         .esc_html__( 'To view it please enter your password below:', 'apollo13-framework' );

	get_header();

	apollo13framework_title_bar( 'outside', $title );

	echo apollo13framework_password_form();

	get_footer();
}