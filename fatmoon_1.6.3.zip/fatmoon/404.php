<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly



global $apollo13framework_a13, $wp_query;

//custom template
$custom_404_page = $apollo13framework_a13->get_option( 'page_404_template' );
if($apollo13framework_a13->get_option( 'page_404_template_type' ) === 'custom' && $custom_404_page !== ''&& $custom_404_page !== '0'){
	//save original query
	$original_query = $wp_query;
	//reset
	$wp_query = null;

	//make query
	$wp_query = new WP_Query( array('page_id' => $custom_404_page ) );

	//brutal change of query (fight WordPress SEO plugin)
	$GLOBALS['wp_the_query'] = $GLOBALS['wp_query'];

	//show
	apollo13framework_page_like_content();

	//return old query
	$wp_query = null;
	$wp_query = $original_query;

	// Reset Post Data
	wp_reset_postdata();

	return;
}

//default template
else{
	define( 'A13FRAMEWORK_NO_RESULTS', true );
	get_header();

	$title = '<span class="emblem">404</span>'.esc_html__('The page you are looking for can\'t be found!', 'apollo13-framework');
	$subtitle = sprintf(
		esc_html__( 'Go to our %1$s or go back to %2$s', 'apollo13-framework' ),
		'<a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'home page', 'apollo13-framework' ) . '</a>',
		'<a href="javascript:history.go(-1)">' . esc_html__( 'previous page', 'apollo13-framework' ) . '</a>'
	);

	apollo13framework_title_bar( 'outside', $title, $subtitle );

	get_footer();
}
