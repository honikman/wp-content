<?php
/**
 * The Template for displaying all single posts.
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
} // Exit if accessed directly


if(post_password_required()){
    echo get_the_content();
}
else{
    get_header();

    the_post();
    apollo13framework_title_bar();
    ?>

    <article id="content" class="clearfix">
        <div class="content-limiter">
            <div id="col-mask">

                <div id="post-<?php the_ID(); ?>" <?php post_class('content-box'); ?>>
                    <div class="formatter">
                        <?php apollo13framework_title_bar( 'inside' ); ?>
                        <div class="real-content">
                            <?php the_content(); ?>
                            <div class="clear"></div>
                            <?php
                            //no need for wp_link_pages, cause the_content takes care of it
                            
                            apollo13framework_under_post_content();
                            ?>

                        </div>

                        <?php apollo13framework_posts_navigation(); ?>

                        <?php apollo13framework_author_info(); ?>

                        <?php
                        // If comments are open or we have at least one comment, load up the comment template.
                        if ( comments_open() || get_comments_number() ) :
                            comments_template( '', true );
                        endif;
                        ?>
                    </div>
                </div>

                <?php get_sidebar(); ?>
            </div>
        </div>
    </article>
    <?php get_footer(); ?>
<?php }//end of if password_protected ?>

