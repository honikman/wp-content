<?php
/**
 * Used in empty archives and no search results page
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
} // Exit if accessed directly

    global $wp_query, $post, $apollo13framework_a13;
?>

<p><span class="info-404"><?php printf( esc_html__('%s or use Site Map below:', 'apollo13-framework' ), '<a href="javascript:history.go(-1)">'.esc_html__('Go back', 'apollo13-framework').'</a>' ); ?></span></p>

<div class="left50">
    <?php
    if ( has_nav_menu( 'header-menu' ) ){
        echo '<h3>'.esc_html__( 'Main navigation', 'apollo13-framework' ).'</h3>';
        wp_nav_menu( array(
                'container'       => false,
                'link_before'     => '',
                'link_after'      => '',
                'menu_class'      => 'styled in-site-map',
                'theme_location'  => 'header-menu' )
        );
    }
    ?>

    <h3><?php esc_html_e( 'Categories', 'apollo13-framework' ); ?></h3>
    <ul class="styled">
        <?php wp_list_categories('title_li='); ?>
    </ul>
</div>

<div class="right50">
    <h3><?php esc_html_e( 'Pages', 'apollo13-framework' ); ?></h3>
    <ul class="styled">
        <?php wp_list_pages('title_li='); ?>
    </ul>
    <?php
        /* List albums */
        $original_query = $wp_query;
        $original_post = $post;

        $args = array(
            'posts_per_page'      => -1,
            'offset'              => -1,
            'post_type'           => A13FRAMEWORK_CUSTOM_POST_TYPE_ALBUM,
            'post_status'         => 'publish',
            'ignore_sticky_posts' => true,
        );

        //make query for albums
        $wp_query = new WP_Query( $args );

        if ($wp_query->have_posts()) :
            echo '<h3>'.esc_html__( 'Albums', 'apollo13-framework' ).'</h3>';
            echo '<ul class="styled">';

            while ( have_posts() ) :
                the_post();
                echo '<li><a href="'. get_permalink() . '">' . get_the_title() . '</a></li>';
            endwhile;

            echo '</ul>';
        endif;

        //restore previous query
        $wp_query = $original_query;
        $post = $original_post;
        wp_reset_postdata();
    ?>
</div>

<div class="clear"></div>